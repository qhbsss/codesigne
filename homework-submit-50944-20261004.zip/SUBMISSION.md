# 50944分 Phase One提交包

上传此ZIP到Phase One入口，保持本人真实学号与显示名一致。ZIP没有外层目录，hardware.json、programs/M1_P1.asm、programs/M2_D1.asm、local-grade.json均位于规定位置，原始grade报告未编辑。

本地完整实验分数50944.15172864169，eligible=true；P1=374249周期/18.097779683 W，D1=41552周期/17.463376855 W，面积23.36637760512 mm²。尚未上传服务端或取得回执，服务端验证分以实际结果为准。

解压后可运行python -m project.verify_artifacts校验源码、硬件、ASM、baseline与原始完整报告一致并重生成程序；依赖Python 3.12与numpy==2.3.5。

agent-trace包含早期原始JSONL以及本轮通过Codex read_thread接口导出的全部可读历史页。导出范围、截断信息与文件哈希见agent-trace/README.md和snapshot-index.json。最终提交前如需要完整底层原始事件日志，请从客户端保留/导出原始会话；本包如实保留可读快照，不伪造缺失信息。
