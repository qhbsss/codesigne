# Transformer codesign迭代记录

早期完整迭代见iteration-log-early.md；本轮分析见../reports/optimization-analysis.md。所有分数均区分本地实验分与服务端验证分，未修改评分器与原始报告。

| 阶段 | 合格完整本地分数 | P1周期 | D1周期 | 说明 |
|---|---:|---:|---:|---|
| 早期 | 28885.37935367514 | 680994 | 71030 | 早期原始会话及记录随包保留 |
| 中期 | 30394.215569735643 | 611770 | 71412 | 原始完整报告reports/history-30394-local-grade.json |
| 中期 | 34931.267616664205 | 528117 | 62630 | 原始完整报告reports/history-34931-local-grade.json |
| 快速但超功耗 | 无有效分数 | 371018 | 41552 | P1峰值20.332041 W，不合格，保留原始报告 |
| 最终 | 50944.15172864169 | 374249 | 41552 | K/V分批搬运后，P1峰值18.097780 W，全部门槛通过 |

最终源码来自提交eab9d6e780b95a644bf55a71f1f2e33ece75161b，额外种子19通过P1/D1功能与竞态检查。python -m project.build_programs重生成两份ASM，python -m project.verify_artifacts核对完整provenance与逐字节一致性。
