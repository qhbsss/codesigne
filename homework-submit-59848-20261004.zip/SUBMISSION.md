# 59848.67432397 分阶段性提交包

ZIP 没有外层目录，hardware.json、programs/M1_P1.asm、programs/M2_D1.asm、local-grade.json 位于规定位置。
原始完整公共评分报告未编辑；eligible=true，官方 score=null，尚无服务端验证回执。
八万分目标尚未达到。

解压后运行 `OPENBLAS_NUM_THREADS=1 python -m project.verify_artifacts` 验证 provenance 和逐字节重生成。
按 ASSIGNMENT.md 的规则，中间提交可以不含 agent trace；截止前的最终提交须附完整 agent trace。
