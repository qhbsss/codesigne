# Phase Two macOS ARM64 executable

Model phase-two-compact-v2, contract phase-two-static-v1. Tested on Apple Silicon macOS 27.0; other OS/architectures and older macOS are not guaranteed. Build Rust source for your own machine.

SHA-256: 77199be74ff51cc206e032560455460a0f4648f6d7a73f06cded64ee3d33c902
