# Phase Two 5005 local result: material map

This directory is included at `materials/0/phase-two-submission-materials-5005-20261015/` in the submission ZIP. The ZIP root contains the five **final** `programs/{w-p,a-p,w-d1,w-d16,w-d4l}.jsonl` files and the unedited parallel self-test outputs under `selftest/`. The public seed-7 local self-test is complete and scores **5005.553991528984**. This is not a private-seed server result.

## Contents

- `hardware.json`: shared final hardware extracted from all five final program headers.
- `selection/screen-spec.json`, `base-solution.json`, and `screen/{progress,screen}.json`: original SHA-pinned five-case mathematical screen. Its 2026-10-14 20:33 UTC result predicts **5494.446815841853**, above the 5000 gate. `selection/source-programs/` contains the five old-hardware inputs used for screening and retargeting; these are **not** the submitted programs.
- `selection/retarget-spec.json` and `selection/materialized/{source-spec,portfolio,manifest}.json`: original retarget inputs and the five final program hashes. Final JSONL generation followed the model screen at 20:38 UTC.
- `selection/direct-grade/result.json`: original independent direct evaluator result, seed **7**, status `complete`, with numerical and power checks passed and a five-case score of **5005.553991528983** at 20:58 UTC.
- ZIP root `selftest/grade.json`, `selftest/contract/result.json`, `selftest/workers/summary.json`, and five `selftest/workers/<case>/evaluation/result.json` files: complete, unedited parallel self-test results for the exact submitted program hashes. The root `programs/` files are the self-test's copied final programs.
- `phase-two-model/`: model documents, equations, Python model and generation code, tests, specifications and reports; historical `runs/` are excluded.
- `phase-two-starter/`: public simulator documents, Rust source and tests, Cargo lockfile and Python tools; build outputs and historical runs are excluded.
- `process/`: seven selected, redacted native Codex event JSONL exports, their exporter and provenance. The export is a frozen prefix through **2026-10-15 13:05 UTC**; later packaging work and unavailable sessions are absent. See `process/README.md` for redaction and scope. The materials include model/generator code and event records, but do not include a complete executable multi-agent orchestration framework.
- `phase-one/homework-submit-64214-20261009.zip`: previous Phase One submission retained as supplied material.

`selection/grading-command.txt` records the actual self-test command and reproduction commands. `selection/host-environment.txt` records the host observed when these materials were assembled, distinct from the original grade run.

## Verification and reproduction

Before extraction, run `python3 verify_archive.py SUBMISSION.zip` from this directory, or use the copy of `verify_archive.py` inside the extracted archive with a path to the ZIP. This checks archive safety and limits, source and program hashes, the model gate, five complete self-test cases, correctness and power reports, cycles, and the score calculation. It does not run the evaluator.

From an extracted submission ZIP root, reproduce the final programs with:

```sh
python3 materials/0/phase-two-submission-materials-5005-20261015/reproduce_candidate.py NEW_PROGRAM_DIR --zip-programs programs
```

`NEW_PROGRAM_DIR` must not exist. The script recomputes the included approximate model's five-case prediction and requires at least 5000 before writing any JSONL. It then retargets the archived source programs and checks every generated hash against the original manifest and, with `--zip-programs`, against the ZIP's final programs. It never invokes the evaluator. See `selection/grading-command.txt` to build the supplied Rust source and rerun the public seed-7 self-test.

The starter README records a 2026-10-12 12:00 Beijing-time deadline. No current portal status or private score is claimed here.
