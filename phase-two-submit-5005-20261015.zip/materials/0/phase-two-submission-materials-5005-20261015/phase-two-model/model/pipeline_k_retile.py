"""Retile strict two-panel pipelined GEMM groups without changing HBM data."""

import copy
import math

from .ksplit_screen import _end


def retile_group(group, panel_k):
    """Return a K-retiled group and tile count, or the unchanged group and zero."""
    if not 16 <= panel_k < 64 or group["sh_kib"] or len(group["commands"]) % 10:
        return group, 0
    commands = group["commands"]
    tasks = []
    for pos in range(0, len(commands), 10):
        block = commands[pos:pos + 10]
        fill, a0, b0, wait0, a1, b1, mma0, wait1, mma1, store = block
        ia0, ib0, ia1, ib1 = (item.get("instruction", {}) for item in (a0, b0, a1, b1))
        im0, im1 = (item.get("instruction", {}) for item in (mma0, mma1))
        if (fill.get("command") != "run" or
                fill.get("instruction", {}).get("op") != "fill" or
                store.get("command") != "run" or
                store.get("instruction", {}).get("op") != "store" or
                any(item.get("command") != "async" for item in (a0, b0, a1, b1)) or
                wait0 != {"command": "wait", "tokens": [a0["token"], b0["token"]]} or
                wait1 != {"command": "wait", "tokens": [a1["token"], b1["token"]]} or
                (ia0.get("op"), ib0.get("op"), ia1.get("op"), ib1.get("op")) !=
                ("load", "load", "load", "load") or
                mma0.get("command") != "run" or mma1.get("command") != "run" or
                (im0.get("op"), im1.get("op")) != ("mma", "mma") or
                (im0["m"], im0["n"], im0["k"]) != (1, 32, 64) or
                (im1["m"], im1["n"], im1["k"]) != (1, 32, 64) or
                (im0["a"], im0["b"], im0["c"]) !=
                (ia0["local"]["base"], ib0["local"]["base"], fill["instruction"]["dst"]) or
                (im1["a"], im1["b"], im1["c"]) !=
                (ia1["local"]["base"], ib1["local"]["base"], im0["c"]) or
                ia0["global"]["rows"] != 1 or ia1["global"]["rows"] != 1 or
                ia0["global"]["cols"] != 64 or ia1["global"]["cols"] != 64 or
                ib0["global"]["rows"] != 64 or ib1["global"]["rows"] != 64 or
                ib0["global"]["cols"] != 32 or ib1["global"]["cols"] != 32 or
                ia0["global"]["col_stride"] != 1 or ia1["global"]["col_stride"] != 1 or
                ib0["global"]["col_stride"] != 1 or ib1["global"]["col_stride"] != 1 or
                ia1["global"]["base"] != ia0["global"]["base"] + 64 or
                ib1["global"]["base"] != ib0["global"]["base"] + 64 * ib0["global"]["row_stride"] or
                ia1["global"]["row_stride"] != ia0["global"]["row_stride"] or
                ib1["global"]["row_stride"] != ib0["global"]["row_stride"] or
                store["instruction"]["local"]["base"] != im0["c"]):
            return group, 0
        tasks.append(block)

    output = []
    next_token = 1
    accumulator = tasks[0][6]["instruction"]["c"]
    a_bases = (accumulator + 32, accumulator + 32 + panel_k + panel_k * 32)
    b_bases = (a_bases[0] + panel_k, a_bases[1] + panel_k)
    for block in tasks:
        fill, a0, b0, _, _, _, mma0, _, _, store = block
        if mma0["instruction"]["c"] != accumulator:
            return group, 0
        output.append(copy.deepcopy(fill))
        chunks = [(offset, min(panel_k, 128 - offset))
                  for offset in range(0, 128, panel_k)]
        tokens = []
        for index, (offset, length) in enumerate(chunks):
            buffer = index % 2
            ia = copy.deepcopy(a0["instruction"])
            ib = copy.deepcopy(b0["instruction"])
            ia["global"]["base"] += offset
            ia["global"]["cols"] = length
            ia["local"].update(base=a_bases[buffer], cols=length, row_stride=length)
            ib["global"]["base"] += offset * ib["global"]["row_stride"]
            ib["global"]["rows"] = length
            ib["local"].update(base=b_bases[buffer], rows=length)
            left, right = next_token, next_token + 1
            next_token += 2
            loads = [{"command": "async", "token": left, "instruction": ia},
                     {"command": "async", "token": right, "instruction": ib}]
            if index == 0:
                output.extend(loads)
                output.append({"command": "wait", "tokens": [left, right]})
            else:
                output.extend(loads)
                previous = chunks[index - 1][1]
                mma = copy.deepcopy(mma0["instruction"])
                mma.update(a=a_bases[(index - 1) % 2], b=b_bases[(index - 1) % 2],
                           c=accumulator, k=previous)
                output.append({"command": "run", "instruction": mma})
                output.append({"command": "wait", "tokens": [left, right]})
        final_mma = copy.deepcopy(mma0["instruction"])
        final_mma.update(a=a_bases[(len(chunks) - 1) % 2],
                         b=b_bases[(len(chunks) - 1) % 2],
                         c=accumulator, k=chunks[-1][1])
        output.append({"command": "run", "instruction": final_mma})
        output.append(copy.deepcopy(store))
    words = max((_end(command["instruction"]) for command in output
                 if "instruction" in command), default=1)
    return dict(group, rf_kib=math.ceil(words / 256), commands=output), len(tasks)
