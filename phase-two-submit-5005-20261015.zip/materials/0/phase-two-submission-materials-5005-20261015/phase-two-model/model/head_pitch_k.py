"""Separate decode K heads in HBM to vary their channel starting points."""

import argparse
import copy
import json
import math
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

from .estimate import estimate_program, estimate_wave, program_records
from .hardware import area, validate
from .tool import SCORE_CASES, STARTER, sha, write


def _rewrite_wave(record, targets, stride, head_width, pitch):
    rewritten = copy.deepcopy(record)
    changed = split_commands = 0
    for group in rewritten["groups"]:
        commands = group["commands"]
        next_token = 1 + max((item["token"] for item in commands
                              if item["command"] == "async"), default=0)
        aliases = {}
        output = []
        for item in commands:
            instruction = item.get("instruction", {})
            if instruction.get("tensor") in targets and instruction.get("op") in (
                    "load", "store", "load_shared", "store_shared"):
                view = instruction["global"]
                if view["col_stride"] != 1 or (view["rows"] > 1 and
                                               view["row_stride"] != stride):
                    raise ValueError("unexpected K view")
                start_row, col = divmod(view["base"], stride)
                if col + view["cols"] > stride:
                    raise ValueError("K view crosses context row")
                current = 0
                tokens = []
                while current < view["rows"]:
                    physical_row = start_row + current
                    head, feature = divmod(physical_row, head_width)
                    count = min(view["rows"] - current, head_width - feature)
                    fragment = copy.deepcopy(item)
                    fragment_view = fragment["instruction"]["global"]
                    fragment_view["base"] = head * pitch + feature * stride + col
                    fragment_view["rows"] = count
                    local_view = fragment["instruction"]["local"]
                    local_view["base"] = instruction["local"]["base"] + \
                        current * instruction["local"]["row_stride"]
                    local_view["rows"] = count
                    if item["command"] == "async":
                        if current:
                            fragment["token"] = next_token
                            next_token += 1
                        tokens.append(fragment["token"])
                    output.append(fragment)
                    current += count
                    split_commands += 1
                if tokens:
                    aliases[item["token"]] = tokens
                changed += 1
            elif item["command"] == "wait":
                replacement = copy.deepcopy(item)
                replacement["tokens"] = [replacement_token for token in item["tokens"]
                                         for replacement_token in aliases.get(token, [token])]
                output.append(replacement)
            else:
                output.append(item)
        group["commands"] = output
    return rewritten, changed, split_commands


def transform(source, hardware, extra_words, baseline_cycles=None, output=None):
    records = program_records(source)
    header = next(records)
    if not header["decode"] or extra_words < 16 or extra_words % 16:
        raise ValueError("decode K head pitch requires positive cache-line padding")
    shape = header["shape"]
    stride = math.ceil((shape["history"] + shape["steps"]) / 16) * 16
    head_width = shape["d"] // shape["heads"]
    pitch = head_width * stride + extra_words
    old_size = header["batch"] * shape["d"] * stride
    new_size = header["batch"] * shape["heads"] * pitch
    allocations = []
    targets = set()
    cache = {}
    changed_waves = changed_dma = fragments = allocation_count = delta = 0
    writer = Path(output).open("x") if output is not None else None
    try:
        if writer:
            writer.write(json.dumps(dict(header, hardware=hardware), separators=(",", ":")) + "\n")
        for record in records:
            kind = record["record"]
            if kind in ("input", "alloc"):
                index = len(allocations)
                allocations.append(record["len"])
                if kind == "alloc" and record["len"] == old_size:
                    targets.add(index)
                    allocation_count += 1
                    record = dict(record, len=new_size)
            elif kind == "release":
                if record["tensor"] != len(allocations) - 1:
                    raise ValueError("unexpected tensor stack")
                targets.discard(record["tensor"])
                allocations.pop()
            elif kind == "wave" and targets:
                rewritten, changed, split = _rewrite_wave(
                    record, targets, stride, head_width, pitch)
                if changed:
                    changed_waves += 1
                    changed_dma += changed
                    fragments += split
                    if baseline_cycles is not None:
                        delta += estimate_wave(rewritten["groups"], hardware, cache) - \
                                 estimate_wave(record["groups"], hardware, cache)
                    record = rewritten
            if writer:
                writer.write(json.dumps(record, separators=(",", ":")) + "\n")
    finally:
        if writer:
            writer.close()
    if allocation_count != shape["layers"] or not changed_waves:
        raise ValueError("K allocation or DMA waves missing")
    return {"head_extra_words": extra_words, "old_stride": stride,
            "head_pitch": pitch, "target_allocations": allocation_count,
            "changed_waves": changed_waves, "changed_dma": changed_dma,
            "fragments": fragments, "cycle_delta": delta,
            "predicted_cycles": baseline_cycles + delta if baseline_cycles is not None else None}


def screen(base_dir, extra_words, output):
    base_dir, output = Path(base_dir), Path(output)
    manifest = json.loads((base_dir / "manifest.json").read_text())
    hardware = manifest["hardware"]
    validate(hardware)
    cycles = dict(manifest["model_cycles"])
    result = {"source_manifest_sha256": sha(base_dir / "manifest.json"),
              "hardware": hardware, "head_extra_words": extra_words,
              "baseline_cycles": cycles.copy(), "predicted_cycles": cycles,
              "cases": {}, "candidate_program_generated": False,
              "official_score": None}
    output.parent.mkdir(parents=True, exist_ok=True)
    for case in ("w-d1", "w-d16", "w-d4l"):
        source = base_dir / "programs" / f"{case}.jsonl"
        if sha(source) != manifest["programs"][case]["program_sha256"]:
            raise ValueError(f"source changed: {case}")
        row = transform(source, hardware, extra_words, cycles[case])
        result["cases"][case] = row
        cycles[case] = row["predicted_cycles"]
        write(output, result)
        print(case, row, flush=True)
    score = 1000 * math.exp(sum(weight * math.log(reference / cycles[case])
        for case, (reference, weight) in SCORE_CASES.items()))
    result["conditional_predicted_score"] = score
    result["meets_grade_gate"] = score >= 5000
    write(output, result)
    print("five-case score", score, flush=True)
    return result


def materialize(base_dir, screen_path, output):
    base_dir, screen_path, output = map(Path, (base_dir, screen_path, output))
    base = json.loads((base_dir / "manifest.json").read_text())
    screen_result = json.loads(screen_path.read_text())
    if (screen_result["source_manifest_sha256"] != sha(base_dir / "manifest.json") or
            screen_result["conditional_predicted_score"] < 5000):
        raise ValueError("source changed or five-case model gate not passed")
    hardware = base["hardware"]
    output.mkdir(parents=True, exist_ok=False)
    programs = output / "programs"
    programs.mkdir()
    hashes = {}
    for case in SCORE_CASES:
        source = base_dir / "programs" / f"{case}.jsonl"
        if sha(source) != base["programs"][case]["program_sha256"]:
            raise ValueError(f"source changed: {case}")
        destination = programs / f"{case}.jsonl"
        if case in screen_result["cases"]:
            with tempfile.TemporaryDirectory(prefix=f"phase-two-headk-{case}-") as temp:
                expanded = Path(temp) / "expanded.jsonl"
                transform(source, hardware, screen_result["head_extra_words"], output=expanded)
                subprocess.run([sys.executable, str(STARTER / "tools/compact_program.py"),
                                str(expanded), str(destination)], check=True)
        else:
            shutil.copyfile(source, destination)
        hashes[case] = sha(destination)
    exact = {case: estimate_program(programs / f"{case}.jsonl")["cycles"]
             for case in SCORE_CASES}
    score = 1000 * math.exp(sum(weight * math.log(reference / exact[case])
        for case, (reference, weight) in SCORE_CASES.items()))
    result = {"hardware": hardware, "area_au": area(hardware),
              "screen_sha256": sha(screen_path), "head_extra_words": screen_result["head_extra_words"],
              "program_sha256": hashes, "exact_model_cycles": exact,
              "exact_model_score": score, "grade_allowed": score >= 5000,
              "official_score": None}
    write(output / "manifest.json", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="mode", required=True)
    first = sub.add_parser("screen")
    first.add_argument("base_dir", type=Path)
    first.add_argument("extra_words", type=int)
    first.add_argument("output", type=Path)
    second = sub.add_parser("materialize")
    second.add_argument("base_dir", type=Path)
    second.add_argument("screen", type=Path)
    second.add_argument("output", type=Path)
    args = parser.parse_args()
    if args.mode == "screen":
        screen(args.base_dir, args.extra_words, args.output)
    else:
        print(json.dumps(materialize(args.base_dir, args.screen, args.output), indent=2))


if __name__ == "__main__":
    main()
