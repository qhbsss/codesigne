"""Keep two groups per SM while sharing B through K32 GEMM panels."""

import copy
import json
import math
from collections import defaultdict
from pathlib import Path

from .cross_group_b_screen import _safe_groups, _shift_epilogue, _tiles
from .estimate import estimate_wave, program_records, validate_wave_capacity
from .reuse_b_within import _renumber
from .tool import SCORE_CASES, sha, write


def _pair_k32(left, right):
    if left["signature"] != right["signature"] or left["fill"]["len"] != 2048:
        raise ValueError("K32 pair shape changed")
    output_words = 2048
    b_base, a0_base, a1_base = 4096, 6144, 7168
    commands = [copy.deepcopy(left["source"][0])]
    other_fill = copy.deepcopy(right["source"][0])
    other_fill["instruction"]["dst"] = output_words
    commands.append(other_fill)
    token = 0

    def async_load(instruction):
        nonlocal token
        token += 1
        commands.append({"command": "async", "token": token,
                         "instruction": instruction})
        return token

    for left_chunk, right_chunk in zip(left["chunks"], right["chunks"]):
        a0, b0, b1, mma0 = (item["instruction"] for item in left_chunk)
        a1, _, _, mma1 = (item["instruction"] for item in right_chunk)
        if (mma0["m"], mma0["n"], mma0["k"], mma0["a"], mma0["b"], mma0["c"]) != \
           (32, 64, 64, 2048, 4096, 0):
            raise ValueError("K32 pair requires m32 n64 k64 standard RF layout")
        if (a0["global"]["cols"] != 64 or a1["global"]["cols"] != 64 or
                b0["global"]["rows"] != 32 or b1["global"]["rows"] != 32 or
                a0["global"]["col_stride"] != 1 or a1["global"]["col_stride"] != 1):
            raise ValueError("K32 split views differ from expected layout")
        for half, b in enumerate((b0, b1)):
            tokens = []
            for original, destination in ((a0, a0_base), (a1, a1_base)):
                load = copy.deepcopy(original)
                load["global"]["base"] += half * 32
                load["global"]["cols"] = 32
                load["local"].update(base=destination, cols=32, row_stride=32)
                tokens.append(async_load(load))
            weight = copy.deepcopy(b)
            weight["local"]["base"] = b_base
            tokens.append(async_load(weight))
            commands.append({"command": "wait", "tokens": tokens})
            first = copy.deepcopy(mma0)
            first.update(a=a0_base, b=b_base, c=0, k=32)
            second = copy.deepcopy(mma1)
            second.update(a=a1_base, b=b_base, c=output_words, k=32)
            commands.extend(({"command": "run", "instruction": first},
                             {"command": "run", "instruction": second}))
    commands.extend(copy.deepcopy(left["epilogue"]))
    commands.append(copy.deepcopy(left["source"][-1]))
    commands.extend(_shift_epilogue(item, output_words, output_words)
                    for item in right["epilogue"])
    commands.append(_shift_epilogue(right["source"][-1], output_words, output_words))
    return commands


def _combine_pair(first, second):
    if first["sm"] != second["sm"] or first["sh_kib"] or second["sh_kib"]:
        return None, 0
    if not _safe_groups((first, second)):
        return None, 0
    left, right = _tiles(first), _tiles(second)
    if left is None or right is None:
        return None, 0
    lookup = defaultdict(list)
    for index, entry in enumerate(right):
        lookup[entry["signature"]].append(index)
    tasks = []
    used = set()
    pairs = 0
    for entry in left:
        choices = lookup[entry["signature"]]
        if choices:
            index = choices.pop(0)
            try:
                commands = _pair_k32(entry, right[index])
            except ValueError:
                tasks.append(copy.deepcopy(entry["source"]))
                continue
            used.add(index)
            tasks.append(commands)
            pairs += 1
        else:
            tasks.append(copy.deepcopy(entry["source"]))
    if not pairs:
        return None, 0
    tasks.extend(copy.deepcopy(entry["source"]) for index, entry in enumerate(right)
                 if index not in used)
    slots = [[], []]
    for index, task in enumerate(tasks):
        slots[index % 2].extend(task)
    return [{"sm": first["sm"], "rf_kib": 32, "sh_kib": 0,
             "commands": _renumber(commands)} for commands in slots], pairs


def transform_wave(record, hardware):
    by_sm = defaultdict(list)
    for group in record["groups"]:
        by_sm[group["sm"]].append(group)
    output = []
    paired = 0
    for sm in sorted(by_sm):
        groups = by_sm[sm]
        if len(groups) != 2:
            output.extend(groups)
            continue
        merged, count = _combine_pair(*groups)
        if merged is None:
            output.extend(groups)
        else:
            output.extend(merged)
            paired += count
    if not paired:
        return None, 0
    validate_wave_capacity(output, hardware)
    return {"record": "wave", "groups": output}, paired


def screen(source, manifest_path, case, output):
    source, manifest_path, output = map(Path, (source, manifest_path, output))
    manifest = json.loads(manifest_path.read_text())
    if sha(source) != manifest["program_sha256"][case]:
        raise ValueError("source changed")
    hardware = manifest["hardware"]
    records = program_records(source)
    if next(records)["hardware"] != hardware:
        raise ValueError("hardware changed")
    cache = {}
    waves = changed = pairs = delta = 0
    choices = []
    for record in records:
        if record["record"] != "wave":
            continue
        try:
            candidate, count = transform_wave(record, hardware)
        except ValueError:
            candidate, count = None, 0
        if candidate is not None:
            before = estimate_wave(record["groups"], hardware, cache)
            after = estimate_wave(candidate["groups"], hardware, cache)
            if after < before:
                changed += 1
                pairs += count
                delta += after - before
                choices.append({"wave": waves, "paired_tiles": count,
                                "old_cycles": before, "new_cycles": after})
        waves += 1
        if waves % 4 == 0:
            write(output, {"case": case, "waves_seen": waves, "changed_waves": changed,
                           "paired_tiles": pairs, "cycle_delta": delta,
                           "choices": choices, "complete": False})
    cycles = dict(manifest["exact_model_cycles"])
    cycles[case] += delta
    score = 1000 * math.exp(sum(weight * math.log(reference / cycles[name])
                                for name, (reference, weight) in SCORE_CASES.items()))
    result = {"case": case, "source_sha256": sha(source),
              "manifest_sha256": sha(manifest_path), "waves_seen": waves,
              "changed_waves": changed, "paired_tiles": pairs,
              "cycle_delta": delta, "choices": choices,
              "five_case_model_cycles": cycles, "five_case_model_score": score,
              "meets_grade_gate": score >= 5000, "complete": True,
              "candidate_program_generated": False, "official_score": None}
    write(output, result)
    return result


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("manifest", type=Path)
    parser.add_argument("case")
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    value = screen(args.source, args.manifest, args.case, args.output)
    print(json.dumps({key: value[key] for key in
          ("changed_waves", "paired_tiles", "cycle_delta", "five_case_model_score")}, indent=2))
