"""Model direct QKV GEMM writes into the transposed decode K buffer.

The rewrite is accepted only when the intervening copy and transpose cover
exactly the K slice and every GEMM output element has one matching destination.
It first prices affected waves in memory; no program is emitted by screen().
"""

import argparse
import copy
import json
import math
import subprocess
import sys
import tempfile
from collections import defaultdict, deque
from pathlib import Path

from .estimate import estimate_program, estimate_wave, program_records, validate_wave_capacity
from .tool import SCORE_CASES, STARTER, sha, write


def _pairs(wave):
    pairs = []
    for group in wave["groups"]:
        pending = None
        for command in group["commands"]:
            instruction = command.get("instruction", {})
            op = instruction.get("op")
            if op == "load":
                if pending is not None:
                    return None
                pending = instruction
            elif op == "store":
                if pending is None:
                    return None
                pairs.append((pending, instruction))
                pending = None
            elif op is not None:
                return None
        if pending is not None:
            return None
    return pairs or None


def _mapping(copy_wave, transpose_wave):
    copies = _pairs(copy_wave)
    transposes = _pairs(transpose_wave)
    if not copies or not transposes or len(copies) != len(transposes):
        return None
    qkv = copies[0][0]["tensor"]
    intermediate = copies[0][1]["tensor"]
    key = transposes[0][1]["tensor"]
    width = copies[0][0]["global"]["cols"]
    qkv_stride = copies[0][0]["global"]["row_stride"]
    key_stride = transposes[0][1]["global"]["row_stride"]
    trans_by_source = {}
    for load, store in transposes:
        lv, sv = load["global"], store["global"]
        if (load["tensor"] != intermediate or store["tensor"] != key or
                lv["rows"] != 1 or lv["cols"] != width or
                sv["rows"] != width or sv["cols"] != 1 or
                sv["row_stride"] != key_stride or
                load["local"]["base"] != store["local"]["base"]):
            return None
        if lv["base"] in trans_by_source:
            return None
        trans_by_source[lv["base"]] = sv["base"]
    destinations = {}
    for load, store in copies:
        lv, sv = load["global"], store["global"]
        if (load["tensor"] != qkv or store["tensor"] != intermediate or
                lv["rows"] != 1 or lv["cols"] != width or
                lv["row_stride"] != qkv_stride or
                sv["rows"] != 1 or sv["cols"] != width or
                load["local"]["base"] != store["local"]["base"] or
                sv["base"] not in trans_by_source or lv["base"] in destinations):
            return None
        destinations[lv["base"]] = (trans_by_source[sv["base"]], sv["base"])
    if (len(destinations) != len(trans_by_source) or
            len({address % qkv_stride for address in destinations}) != 1):
        return None
    return qkv, intermediate, key, width, qkv_stride, key_stride, destinations


def _rewrite(window, mode, hardware):
    """Return changed preceding waves, or None when address proof fails."""
    if len(window) < 3 or mode not in ("run", "async"):
        return None
    metadata = _mapping(window[-2][1], window[-1][1])
    if metadata is None:
        return None
    qkv, original_key, key, width, qkv_stride, key_stride, destinations = metadata
    k_offset = next(iter(destinations)) % qkv_stride
    changed = {}
    coverage = defaultdict(list)
    stores_replaced = 0
    for wave_index, wave in window[:-2]:
        if not any(command.get("instruction", {}).get("op") == "mma"
                   for group in wave["groups"] for command in group["commands"]):
            continue
        modified = copy.deepcopy(wave)
        any_store = False
        for group in modified["groups"]:
            next_token = 1 + max((item.get("token", 0) for item in group["commands"]), default=0)
            commands = []
            for command in group["commands"]:
                instruction = command.get("instruction", {})
                if instruction.get("op") != "store" or instruction.get("tensor") != qkv:
                    commands.append(command)
                    continue
                gv, lv = instruction["global"], instruction["local"]
                start = gv["base"] % qkv_stride - k_offset
                if start < 0 or start >= width:
                    commands.append(command)
                    continue
                m, n = gv["rows"], gv["cols"]
                if (start + n > width or gv["row_stride"] != qkv_stride or
                        gv["col_stride"] != 1 or lv["rows"] != m or
                        lv["cols"] != n or lv["row_stride"] != n or
                        lv["col_stride"] != 1 or command["command"] != "run"):
                    return None
                tokens = []
                source_bases = [gv["base"] + row * qkv_stride - start
                                for row in range(m)]
                if any(source_base not in destinations for source_base in source_bases):
                    return None
                original_bases = [destinations[source_base][1] + start
                                  for source_base in source_bases]
                original_step = (original_bases[1] - original_bases[0]
                                 if m > 1 else n)
                if (original_step < n or any(address != original_bases[0] + row * original_step
                                             for row, address in enumerate(original_bases))):
                    return None
                original_store = copy.deepcopy(command)
                original_store["instruction"]["tensor"] = original_key
                original_store["instruction"]["global"] = {
                    "base": original_bases[0], "rows": m, "cols": n,
                    "row_stride": original_step, "col_stride": 1}
                commands.append(original_store)
                for row in range(m):
                    source_base = source_bases[row]
                    coverage[source_base].append((start, start + n))
                    updated = copy.deepcopy(command)
                    updated["instruction"]["tensor"] = key
                    updated["instruction"]["global"] = {
                        "base": destinations[source_base][0] + start * key_stride,
                        "rows": n, "cols": 1, "row_stride": key_stride,
                        "col_stride": 1}
                    updated["instruction"]["local"] = {
                        "base": lv["base"] + row * n,
                        "rows": n, "cols": 1, "row_stride": 1,
                        "col_stride": 1}
                    if mode == "async":
                        updated["command"] = "async"
                        updated["token"] = next_token
                        next_token += 1
                        tokens.append(updated["token"])
                    commands.append(updated)
                    if mode == "async" and len(tokens) == hardware["dma_engines"] * (1 + hardware["dma_depth"]):
                        commands.append({"command": "wait", "tokens": tokens})
                        tokens = []
                if tokens:
                    commands.append({"command": "wait", "tokens": tokens})
                stores_replaced += 1
                any_store = True
            group["commands"] = commands
        if any_store:
            validate_wave_capacity(modified["groups"], hardware)
            changed[wave_index] = modified
    if not changed or set(coverage) != set(destinations):
        return None
    for intervals in coverage.values():
        cursor = 0
        for start, end in sorted(intervals):
            if start != cursor:
                return None
            cursor = end
        if cursor != width:
            return None
    return changed, stores_replaced


def screen_case(source, hardware, base_cycles, output):
    records = program_records(source)
    header = next(records)
    if not header["decode"] or header["hardware"] != hardware:
        raise ValueError("decode source must use target hardware")
    recent = deque(maxlen=4)
    cache = {}
    stages = []
    wave_index = 0
    for record in records:
        if record["record"] != "wave":
            recent.clear()
            continue
        recent.append((wave_index, record))
        candidates = []
        for mode in ("run", "async"):
            rewritten = _rewrite(list(recent), mode, hardware)
            if rewritten is None:
                continue
            changed, stores = rewritten
            old = sum(estimate_wave(original["groups"], hardware, cache)
                      for index, original in recent if index in changed)
            old += sum(estimate_wave(original["groups"], hardware, cache)
                       for _, original in list(recent)[-2:])
            new = sum(estimate_wave(wave["groups"], hardware, cache)
                      for wave in changed.values())
            candidates.append({"mode": mode, "delta_cycles": new - old,
                               "stores_replaced": stores,
                               "qkv_waves": sorted(changed),
                               "copy_wave": recent[-2][0],
                               "transpose_wave": wave_index})
        if candidates:
            selected = min(candidates, key=lambda row: row["delta_cycles"])
            stages.append({"candidates": candidates,
                           "selected": selected if selected["delta_cycles"] < 0 else None})
        wave_index += 1
    selected = [stage["selected"] for stage in stages if stage["selected"]]
    cycles = base_cycles + sum(row["delta_cycles"] for row in selected)
    result = {"source_sha256": sha(source), "hardware": hardware,
              "base_cycles": base_cycles, "predicted_cycles": cycles,
              "candidate_stages": len(stages), "selected_stages": len(selected),
              "stages": stages, "candidate_program_generated": False,
              "numerical_correctness": "not_checked", "official_score": None}
    write(output, result)
    return result


def materialize(source, screen_path, base_manifest, case, output):
    source, screen_path, base_manifest, output = map(Path,
        (source, screen_path, base_manifest, output))
    screen = json.loads(screen_path.read_text())
    base = json.loads(base_manifest.read_text())
    if (screen["source_sha256"] != sha(source) or
            screen["hardware"] != base["hardware"] or
            screen["base_cycles"] != base["exact_model_cycles"][case]):
        raise ValueError("source or shared hardware changed")
    cycles = dict(base["exact_model_cycles"])
    cycles[case] = screen["predicted_cycles"]
    score = 1000 * math.exp(sum(weight * math.log(reference / cycles[name])
        for name, (reference, weight) in SCORE_CASES.items()))
    if score < 5000 or not screen["selected_stages"]:
        raise ValueError("five-case model gate or stage selection failed")
    choices = {stage["selected"]["transpose_wave"]: stage["selected"]
               for stage in screen["stages"] if stage["selected"]}
    output.mkdir(parents=True, exist_ok=False)
    destination = output / f"{case}.jsonl"
    with tempfile.TemporaryDirectory(prefix=f"fuse-k-output-{case}-") as temporary:
        expanded = Path(temporary) / "expanded.jsonl"
        records = program_records(source)
        header = next(records)
        pending = []
        used = set()
        wave_index = 0
        with expanded.open("x") as writer:
            writer.write(json.dumps(header, separators=(",", ":")) + "\n")

            def emit(item):
                if item is not None:
                    writer.write(json.dumps(item, separators=(",", ":")) + "\n")

            for record in records:
                if record["record"] != "wave":
                    for _, item in pending:
                        emit(item)
                    pending.clear()
                    emit(record)
                    continue
                pending.append((wave_index, record))
                while len(pending) > 4:
                    _, item = pending.pop(0)
                    emit(item)
                if wave_index in choices:
                    choice = choices[wave_index]
                    rewritten = _rewrite(pending, choice["mode"], header["hardware"])
                    if rewritten is None:
                        raise ValueError(f"stage changed at wave {wave_index}")
                    changes, count = rewritten
                    if sorted(changes) != choice["qkv_waves"] or count != choice["stores_replaced"]:
                        raise ValueError(f"stage proof changed at wave {wave_index}")
                    pending = [(index, changes.get(index, item)
                                if index not in (choice["copy_wave"], choice["transpose_wave"])
                                else None) for index, item in pending]
                    used.add(wave_index)
                wave_index += 1
            for _, item in pending:
                emit(item)
        if used != set(choices):
            raise ValueError("not all selected stages were materialized")
        subprocess.run([sys.executable, str(STARTER / "tools/compact_program.py"),
                        str(expanded), str(destination)], check=True)
    exact = estimate_program(destination)["cycles"]
    if exact != screen["predicted_cycles"]:
        raise ValueError("materialized model differs from in-memory screen")
    result = {"case": case, "source_sha256": sha(source),
              "screen_sha256": sha(screen_path), "program_sha256": sha(destination),
              "exact_model_cycles": exact, "five_case_model_score": score,
              "grade_allowed": True, "official_score": None}
    write(output / "manifest.json", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="mode", required=True)
    first = sub.add_parser("screen")
    first.add_argument("source", type=Path)
    first.add_argument("hardware_manifest", type=Path)
    first.add_argument("case", choices=tuple(SCORE_CASES))
    first.add_argument("output", type=Path)
    second = sub.add_parser("materialize")
    second.add_argument("source", type=Path)
    second.add_argument("screen", type=Path)
    second.add_argument("base_manifest", type=Path)
    second.add_argument("case", choices=tuple(SCORE_CASES))
    second.add_argument("output", type=Path)
    args = parser.parse_args()
    if args.mode == "screen":
        base = json.loads(args.hardware_manifest.read_text())
        result = screen_case(args.source, base["hardware"],
                             base["exact_model_cycles"][args.case], args.output)
        print(json.dumps({key: result[key] for key in
                          ("candidate_stages", "selected_stages", "base_cycles",
                           "predicted_cycles")}, indent=2))
    else:
        print(json.dumps(materialize(args.source, args.screen,
                                      args.base_manifest, args.case, args.output), indent=2))


if __name__ == "__main__":
    main()
