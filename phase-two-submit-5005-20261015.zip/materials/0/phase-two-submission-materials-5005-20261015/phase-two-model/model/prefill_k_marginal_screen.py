"""Screen a wider prefill K-panel menu on a SHA-pinned five-case solution."""

import argparse
import json
import math
from pathlib import Path

from .joint_k_pipeline_screen import screen_case
from .tool import SCORE_CASES, sha, write


OPTIONS = ("base", "k40", "k48", "k56", "k60", "k64", "k72", "k80", "k96", "k112")


def screen(manifest_path, program_dir, output):
    manifest_path, program_dir, output = map(Path, (manifest_path, program_dir, output))
    manifest = json.loads(manifest_path.read_text())
    identity = {"source_manifest_sha256": sha(manifest_path),
                "program_sha256": {case: manifest["program_sha256"][case]
                                   for case in ("w-p", "a-p")},
                "options": OPTIONS}
    progress_path = output / "progress.json"
    output.mkdir(parents=True, exist_ok=True)
    progress = json.loads(progress_path.read_text()) if progress_path.exists() else {
        **identity, "cases": {}}
    if any(progress.get(key) != value for key, value in identity.items()):
        raise ValueError("prefill K screen checkpoint differs from inputs")
    write(progress_path, progress)
    predicted = dict(manifest["exact_model_cycles"])
    results = {}
    for case in ("w-p", "a-p"):
        source = program_dir / f"{case}.jsonl"
        if sha(source) != identity["program_sha256"][case]:
            raise ValueError(f"program SHA changed: {case}")
        result = screen_case(source, manifest["hardware"], progress_path, case, OPTIONS)
        predicted[case] += result["selected_cycles"] - result["base_cycles"]
        results[case] = result
        print(case, result, flush=True)
    score = 1000 * math.exp(sum(weight * math.log(reference / predicted[case])
                                for case, (reference, weight) in SCORE_CASES.items()))
    summary = {**identity, "cases": results, "predicted_cycles": predicted,
               "five_case_model_score": score, "meets_grade_gate": score >= 5000,
               "candidate_program_generated": False, "official_score": None}
    write(output / "screen.json", summary)
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("manifest", type=Path)
    parser.add_argument("program_dir", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    result = screen(args.manifest, args.program_dir, args.output)
    print(json.dumps({"five_case_model_score": result["five_case_model_score"],
                      "meets_grade_gate": result["meets_grade_gate"]}, indent=2))


if __name__ == "__main__":
    main()
