"""Combine in-memory transpose tile screens into one five-case model decision."""

import argparse
import json
import math
from pathlib import Path

from .hardware import area, validate
from .tool import SCORE_CASES, sha, write


def _read(path):
    return json.loads(Path(path).read_text())


def combine(manifest_path, hardware_spec_path, base_screen_path,
            grid_directories, output, hardware_name):
    manifest = _read(manifest_path)
    hardware_spec = _read(hardware_spec_path)
    base = _read(base_screen_path)
    choices = [entry["hardware"] for entry in hardware_spec["hardware_options"]
               if entry["name"] == hardware_name]
    if len(choices) != 1:
        raise ValueError("hardware choice is missing or ambiguous")
    hardware = choices[0]
    validate(hardware)
    if len(grid_directories) < 1:
        raise ValueError("at least one tile grid is required")
    sources = {entry["case"]: entry for entry in manifest["canonical"]}
    if set(sources) != {"w-d1", "w-d16", "w-d4l"}:
        raise ValueError("transpose manifest must cover the three decode cases")
    selected = {}
    cycles = dict(base["selected_predicted_cycles"])
    for case in ("w-d1", "w-d16", "w-d4l"):
        candidates = []
        shift = None
        for directory in grid_directories:
            grid = _read(Path(directory) / f"{case}.json")
            if grid["program_sha256"] != sources[case]["source_sha256"]:
                raise ValueError(f"transpose source changed: {case}")
            reference = grid.get("reference_tile")
            current_shift = (reference["reference_shift_cycles"] if reference is not None
                             else grid["reference_shift_cycles"])
            if shift is not None and shift != current_shift:
                raise ValueError(f"reference tile normalization changed: {case}")
            shift = current_shift
            candidates.extend(grid["candidates"])
            if reference is not None:
                matched = [candidate for candidate in grid["candidates"]
                           if (candidate["feature_tile"], candidate["context_tile"]) ==
                           (reference["feature_tile"], reference["context_tile"])]
                if len(matched) != 1 or matched[0]["predicted_cycles"] != cycles[case]:
                    raise ValueError(f"reference tile does not reproduce baseline: {case}")
                if (reference["selected_program_sha256"] !=
                        sources[case]["program_sha256"]):
                    raise ValueError(f"selected program identity changed: {case}")
        if not candidates:
            raise ValueError(f"no feasible transpose tile: {case}")
        best = min(candidates, key=lambda item: (item["predicted_cycles"],
                                                item["feature_tile"],
                                                item["context_tile"]))
        cycles[case] = min(cycles[case], best["predicted_cycles"])
        selected[case] = {"feature_tile": best["feature_tile"],
                          "context_tile": best["context_tile"],
                          "predicted_cycles": cycles[case],
                          "source_program_sha256": sources[case]["source_sha256"],
                          "candidate_program_generated_this_round": False,
                          "candidate_program_already_exists":
                          (best["feature_tile"], best["context_tile"]) == (128, 16),
                          "candidate_program_sha256":
                          (sources[case]["program_sha256"] if
                           (best["feature_tile"], best["context_tile"]) == (128, 16)
                           else None)}
    score = 1000 * math.exp(sum(
        weight * math.log(reference / cycles[case])
        for case, (reference, weight) in SCORE_CASES.items()))
    result = {"scope": "fixed prefill bodies, shared hardware, and declared transpose tiles",
              "hardware_name": hardware_name, "hardware": hardware,
              "area_au": area(hardware),
              "manifest_sha256": sha(manifest_path),
              "hardware_spec_sha256": sha(hardware_spec_path),
              "base_screen_sha256": sha(base_screen_path),
              "estimator_sha256": sha(Path(__file__).with_name("estimate.py")),
              "transpose_model_sha256": sha(Path(__file__).with_name("direct_k.py")),
              "selected_tiles": selected, "predicted_cycles": cycles,
              "conditional_predicted_score": score, "target_score": 5000,
              "meets_grade_gate": score >= 5000, "official_score": None,
              "numerical_correctness": "not_checked"}
    write(output, result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("manifest", type=Path)
    parser.add_argument("hardware_spec", type=Path)
    parser.add_argument("base_screen", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("hardware_name")
    parser.add_argument("grid_directories", nargs="+", type=Path)
    args = parser.parse_args()
    result = combine(args.manifest, args.hardware_spec, args.base_screen,
                     args.grid_directories, args.output, args.hardware_name)
    print(json.dumps({"conditional_predicted_score": result["conditional_predicted_score"],
                      "meets_grade_gate": result["meets_grade_gate"]}, indent=2))


if __name__ == "__main__":
    main()
