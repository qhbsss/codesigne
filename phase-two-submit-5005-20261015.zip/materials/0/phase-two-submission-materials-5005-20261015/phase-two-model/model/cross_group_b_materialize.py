"""Materialize only a complete five-case model-qualified cross-group B choice."""

import argparse
import json
import math
import subprocess
import sys
import tempfile
from collections import Counter
from pathlib import Path

from .cross_group_b_screen import transform_wave
from .estimate import estimate_program, estimate_wave, program_records
from .tool import SCORE_CASES, STARTER, sha, write


def _ops(groups):
    return Counter(command["instruction"]["op"]
                   for group in groups for command in group["commands"]
                   if "instruction" in command)


def materialize(source, manifest_path, screen_path, case, output):
    source, manifest_path, screen_path, output = map(Path,
        (source, manifest_path, screen_path, output))
    base = json.loads(manifest_path.read_text())
    screen = json.loads(screen_path.read_text())
    if (case not in SCORE_CASES or screen["case"] != case or not screen["complete"] or
            screen["source_sha256"] != sha(source) or
            screen["manifest_sha256"] != sha(manifest_path) or
            sha(source) != base["program_sha256"][case] or
            not screen["meets_grade_gate"] or screen["five_case_model_score"] < 5000):
        raise ValueError("five-case model gate or source identity failed")
    output.mkdir(parents=True, exist_ok=False)
    destination = output / f"{case}.jsonl"
    choices = {row["wave"]: row for row in screen["choices"]}
    hardware = base["hardware"]
    with tempfile.TemporaryDirectory(prefix="cross-group-b-") as temporary:
        expanded = Path(temporary) / "expanded.jsonl"
        records = program_records(source)
        header = next(records)
        if header["hardware"] != hardware:
            raise ValueError("hardware changed")
        wave = 0
        changed = 0
        removed_b_loads = 0
        with expanded.open("x") as writer:
            writer.write(json.dumps(header, separators=(",", ":")) + "\n")
            for record in records:
                if record["record"] == "wave":
                    if wave in choices:
                        replacement, pairs = transform_wave(record, hardware)
                        if replacement is None or pairs != choices[wave]["paired_tiles"]:
                            raise ValueError(f"selected wave {wave} changed")
                        old_ops, new_ops = _ops(record["groups"]), _ops(replacement["groups"])
                        if any(old_ops[op] != new_ops[op] for op in
                               ("mma", "store", "fill", "vector", "reduce")):
                            raise ValueError(f"wave {wave} changed paid compute or output stores")
                        saved = old_ops["load"] - new_ops["load"]
                        if saved <= 0:
                            raise ValueError(f"wave {wave} did not remove B loads")
                        before = estimate_wave(record["groups"], hardware)
                        after = estimate_wave(replacement["groups"], hardware)
                        if (before, after) != (choices[wave]["old_cycles"],
                                               choices[wave]["new_cycles"]):
                            raise ValueError(f"wave {wave} model receipt changed")
                        removed_b_loads += saved
                        changed += 1
                        record = replacement
                    wave += 1
                writer.write(json.dumps(record, separators=(",", ":")) + "\n")
        if wave != screen["waves_seen"] or changed != screen["changed_waves"]:
            raise ValueError("incomplete wave selection")
        subprocess.run([sys.executable, str(STARTER / "tools/compact_program.py"),
                        str(expanded), str(destination)], check=True)
    exact = estimate_program(destination)["cycles"]
    if exact != screen["five_case_model_cycles"][case]:
        raise ValueError("materialized model cycles differ from in-memory screen")
    cycles = dict(base["exact_model_cycles"])
    cycles[case] = exact
    score = 1000 * math.exp(sum(weight * math.log(reference / cycles[name])
                                for name, (reference, weight) in SCORE_CASES.items()))
    if score < 5000:
        raise ValueError("materialized five-case model score below gate")
    result = {"case": case, "source_sha256": sha(source),
              "program_sha256": sha(destination), "screen_sha256": sha(screen_path),
              "changed_waves": changed, "removed_b_loads": removed_b_loads,
              "exact_model_cycles": cycles, "exact_model_score": score,
              "grade_allowed": True, "official_score": None}
    write(output / "manifest.json", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("base_manifest", type=Path)
    parser.add_argument("screen", type=Path)
    parser.add_argument("case")
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    print(json.dumps(materialize(args.source, args.base_manifest, args.screen,
                                 args.case, args.output), indent=2))


if __name__ == "__main__":
    main()
