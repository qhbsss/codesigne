"""Materialize a model-qualified independent GEMM SM assignment."""

import argparse
import json
import math
import subprocess
import sys
import tempfile
from pathlib import Path

from .balance_sm import balance_wave
from .estimate import estimate_program, program_records
from .tool import SCORE_CASES, STARTER, sha, write


def materialize(source, screen_path, base_manifest, case, output):
    source, screen_path, base_manifest, output = map(Path,
        (source, screen_path, base_manifest, output))
    screen = json.loads(screen_path.read_text())
    base = json.loads(base_manifest.read_text())
    if screen["source_sha256"] != sha(source) or screen["hardware"] != base["hardware"]:
        raise ValueError("screen source or shared hardware changed")
    if screen["base_cycles"] != base["exact_model_cycles"][case]:
        raise ValueError("screen baseline differs from five-case portfolio")
    cycles = dict(base["exact_model_cycles"])
    cycles[case] = screen["predicted_cycles"]
    score = 1000 * math.exp(sum(weight * math.log(reference / cycles[name])
        for name, (reference, weight) in SCORE_CASES.items()))
    if score < 5000:
        raise ValueError("five-case model gate not passed")
    output.mkdir(parents=True, exist_ok=False)
    destination = output / f"{case}.jsonl"
    chosen = set(screen["changed_wave_indices"])
    with tempfile.TemporaryDirectory(prefix=f"balance-{case}-") as temporary:
        expanded = Path(temporary) / "expanded.jsonl"
        records = program_records(source)
        header = next(records)
        changed = set()
        wave_index = 0
        with expanded.open("x") as writer:
            writer.write(json.dumps(header, separators=(",", ":")) + "\n")
            for record in records:
                if record["record"] == "wave":
                    if wave_index in chosen:
                        groups = balance_wave(record["groups"], header["hardware"])
                        if groups is record["groups"]:
                            raise ValueError(f"selected wave no longer changes: {wave_index}")
                        record = {"record": "wave", "groups": groups}
                        changed.add(wave_index)
                    wave_index += 1
                writer.write(json.dumps(record, separators=(",", ":")) + "\n")
        if changed != chosen or wave_index != screen["waves"]:
            raise ValueError("wave selection changed")
        subprocess.run([sys.executable, str(STARTER / "tools/compact_program.py"),
                        str(expanded), str(destination)], check=True)
    exact = estimate_program(destination)["cycles"]
    if exact != screen["predicted_cycles"]:
        raise ValueError("materialized program and in-memory model disagree")
    result = {"case": case, "source_sha256": sha(source),
              "screen_sha256": sha(screen_path), "program_sha256": sha(destination),
              "exact_model_cycles": exact, "five_case_model_score": score,
              "grade_allowed": True, "official_score": None}
    write(output / "manifest.json", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("screen", type=Path)
    parser.add_argument("base_manifest", type=Path)
    parser.add_argument("case", choices=tuple(SCORE_CASES))
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    print(json.dumps(materialize(args.source, args.screen,
                                  args.base_manifest, args.case, args.output), indent=2))


if __name__ == "__main__":
    main()
