"""Screen and materialize parallel DMA descriptors for decode K reads."""

import argparse
import copy
import json
import math
import subprocess
import sys
import tempfile
from pathlib import Path

from .estimate import estimate_program, estimate_wave, program_records
from .hardware import area, validate
from .tool import SCORE_CASES, STARTER, sha, write


def _split_wave(record, targets, factor, min_rows=0, min_cols=0):
    rewritten = copy.deepcopy(record)
    changed = 0
    for group in rewritten["groups"]:
        commands = group["commands"]
        next_token = 1 + max((item["token"] for item in commands
                              if item["command"] == "async"), default=0)
        new_commands = []
        alias = {}
        for item in commands:
            instruction = item.get("instruction", {})
            if (item["command"] == "async" and instruction.get("op") == "load"
                    and (targets is None or instruction.get("tensor") in targets)
                    and instruction["global"]["rows"] >= max(2 * factor, min_rows)
                    and instruction["global"]["cols"] >= min_cols):
                global_view, local_view = instruction["global"], instruction["local"]
                if (global_view["rows"] != local_view["rows"] or
                        global_view["cols"] != local_view["cols"] or
                        global_view["col_stride"] != 1 or local_view["col_stride"] != 1):
                    raise ValueError("unexpected K DMA view")
                rows = global_view["rows"]
                tokens = [item["token"]]
                for part in range(factor):
                    start, end = rows * part // factor, rows * (part + 1) // factor
                    split = copy.deepcopy(item)
                    for view in ("global", "local"):
                        original = instruction[view]
                        replacement = split["instruction"][view]
                        replacement["base"] = original["base"] + start * original["row_stride"]
                        replacement["rows"] = end - start
                    if part:
                        split["token"] = next_token
                        tokens.append(next_token)
                        next_token += 1
                    new_commands.append(split)
                alias[item["token"]] = tokens
                changed += 1
            elif item["command"] == "wait":
                replacement = copy.deepcopy(item)
                replacement["tokens"] = [alias_token for token in item["tokens"]
                                         for alias_token in alias.get(token, [token])]
                new_commands.append(replacement)
            else:
                new_commands.append(item)
        group["commands"] = new_commands
    return rewritten, changed


def transform(source, factor, hardware, output=None, baseline_cycles=None):
    records = program_records(source)
    header = next(records)
    if not header["decode"]:
        raise ValueError("K splitting applies only to decode")
    shape = header["shape"]
    stride = math.ceil((shape["history"] + shape["steps"]) / 16) * 16
    # Explicitly preserve the K stride already present in the source program.
    allocations = []
    targets = set()
    changed_waves = changed_dmas = delta = 0
    cache = {}
    writer = Path(output).open("x") if output is not None else None
    try:
        if writer:
            writer.write(json.dumps(dict(header, hardware=hardware), separators=(",", ":")) + "\n")
        for record in records:
            kind = record["record"]
            if kind in ("input", "alloc"):
                index = len(allocations)
                allocations.append(record["len"])
                if kind == "alloc" and record["len"] == header["batch"] * shape["d"] * stride:
                    targets.add(index)
            elif kind == "release":
                if record["tensor"] != len(allocations) - 1:
                    raise ValueError("unexpected tensor stack")
                targets.discard(record["tensor"])
                allocations.pop()
            elif kind == "wave" and targets:
                rewritten, count = _split_wave(record, targets, factor)
                if count:
                    changed_waves += 1
                    changed_dmas += count
                    if baseline_cycles is not None:
                        delta += estimate_wave(rewritten["groups"], hardware, cache) - \
                                 estimate_wave(record["groups"], hardware, cache)
                    record = rewritten
            if writer:
                writer.write(json.dumps(record, separators=(",", ":")) + "\n")
    finally:
        if writer:
            writer.close()
    if not changed_waves:
        raise ValueError("no K DMA commands found")
    return {"factor": factor, "changed_waves": changed_waves,
            "changed_dma": changed_dmas, "cycle_delta": delta,
            "predicted_cycles": baseline_cycles + delta if baseline_cycles is not None else None}


def screen(base_dir, factors, output):
    base_dir, output = Path(base_dir), Path(output)
    manifest = json.loads((base_dir / "manifest.json").read_text())
    hardware = manifest["hardware"]
    validate(hardware)
    output.parent.mkdir(parents=True, exist_ok=True)
    document = {"source_manifest_sha256": sha(base_dir / "manifest.json"),
                "hardware": hardware, "baseline_cycles": manifest["model_cycles"],
                "factors": {}, "candidate_program_generated": False,
                "official_score": None}
    for factor in factors:
        cycles = dict(manifest["model_cycles"])
        cases = {}
        for case in ("w-d1", "w-d16", "w-d4l"):
            source = base_dir / "programs" / f"{case}.jsonl"
            if sha(source) != manifest["programs"][case]["program_sha256"]:
                raise ValueError(f"source program changed: {case}")
            result = transform(source, factor, hardware, baseline_cycles=cycles[case])
            cases[case] = result
            cycles[case] = result["predicted_cycles"]
            document["factors"][str(factor)] = {"cases": cases, "predicted_cycles": cycles}
            write(output, document)
            print(f"factor={factor} case={case} {result}", flush=True)
        score = 1000 * math.exp(sum(weight * math.log(reference / cycles[case])
            for case, (reference, weight) in SCORE_CASES.items()))
        document["factors"][str(factor)]["conditional_predicted_score"] = score
        document["factors"][str(factor)]["meets_grade_gate"] = score >= 5000
        write(output, document)
        print(f"factor={factor} score={score:.4f}", flush=True)
    return document


def materialize(base_dir, screen_path, factor, output):
    base_dir, screen_path, output = map(Path, (base_dir, screen_path, output))
    base = json.loads((base_dir / "manifest.json").read_text())
    screen_data = json.loads(screen_path.read_text())
    if screen_data["source_manifest_sha256"] != sha(base_dir / "manifest.json"):
        raise ValueError("screen source manifest changed")
    choice = screen_data["factors"][str(factor)]
    if choice["conditional_predicted_score"] < 5000:
        raise ValueError("five-case model score below grade gate")
    hardware = base["hardware"]
    output.mkdir(parents=True, exist_ok=False)
    programs = output / "programs"
    programs.mkdir()
    hashes = {}
    for case in SCORE_CASES:
        source = base_dir / "programs" / f"{case}.jsonl"
        if sha(source) != base["programs"][case]["program_sha256"]:
            raise ValueError(f"source program changed: {case}")
        destination = programs / f"{case}.jsonl"
        if case in choice["cases"]:
            with tempfile.TemporaryDirectory(prefix=f"phase-two-splitk-{case}-") as temp:
                expanded = Path(temp) / "expanded.jsonl"
                transform(source, factor, hardware, output=expanded)
                subprocess.run([sys.executable, str(STARTER / "tools/compact_program.py"),
                                str(expanded), str(destination)], check=True)
        else:
            destination.write_bytes(source.read_bytes())
        hashes[case] = sha(destination)
    exact = {case: estimate_program(programs / f"{case}.jsonl")["cycles"]
             for case in SCORE_CASES}
    score = 1000 * math.exp(sum(weight * math.log(reference / exact[case])
        for case, (reference, weight) in SCORE_CASES.items()))
    result = {"hardware": hardware, "area_au": area(hardware),
              "screen_sha256": sha(screen_path), "split_factor": factor,
              "program_sha256": hashes, "exact_model_cycles": exact,
              "exact_model_score": score, "grade_allowed": score >= 5000,
              "official_score": None}
    write(output / "manifest.json", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="mode", required=True)
    first = sub.add_parser("screen")
    first.add_argument("base_dir", type=Path)
    first.add_argument("output", type=Path)
    first.add_argument("--factors", type=int, nargs="+", default=[2, 4])
    second = sub.add_parser("materialize")
    second.add_argument("base_dir", type=Path)
    second.add_argument("screen", type=Path)
    second.add_argument("factor", type=int)
    second.add_argument("output", type=Path)
    args = parser.parse_args()
    if args.mode == "screen":
        screen(args.base_dir, args.factors, args.output)
    else:
        print(json.dumps(materialize(args.base_dir, args.screen,
                                     args.factor, args.output), indent=2))


if __name__ == "__main__":
    main()
