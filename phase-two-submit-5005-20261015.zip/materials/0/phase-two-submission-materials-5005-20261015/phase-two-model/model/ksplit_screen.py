"""Price smaller K panels and RF-tier retargeting without writing programs.

Splitting a Kp=1 MMA preserves its accumulator and K order.  Both DMA panels
are sliced over K, with their RF staging regions compacted.  All other paid
commands, including fused epilogues, are retained unchanged.
"""

import argparse
import copy
import json
import math
from collections import defaultdict
from pathlib import Path

from .estimate import estimate_wave, program_records, validate_wave_capacity
from .hardware import area, validate
from .tool import SCORE_CASES, sha, write


def _end(instruction):
    op = instruction["op"]
    if op in ("load", "store", "load_shared", "store_shared"):
        view = instruction["local"]
        return view["base"] + (view["rows"] - 1) * view["row_stride"] + (
            view["cols"] - 1) * view["col_stride"] + 1
    if op == "mma":
        return max(instruction["a"] + instruction["m"] * instruction["k"],
                   instruction["b"] + instruction["k"] * instruction["n"],
                   instruction["c"] + instruction["m"] * instruction["n"])
    if op == "mma_shared":
        return max(instruction["a"] + instruction["m"] * instruction["k"],
                   instruction["c"] + instruction["m"] * instruction["n"])
    if op == "fill":
        return instruction["dst"] + instruction["len"]
    if op == "vector":
        ends = [instruction["dst"] + instruction["len"]]
        for name in ("a", "b"):
            value = instruction[name]
            if value["kind"] == "reg":
                ends.append(value["base"] + (instruction["len"] - 1) * value["stride"] + 1)
        return max(ends)
    if op == "reduce":
        return max(instruction["src"] + instruction["len"],
                   instruction["dst"] + 1,
                   instruction["scratch"] + instruction["len"])
    if op in ("shared_read", "shared_write"):
        return instruction["local"] + instruction["shared"]["rows"] * instruction["shared"]["cols"]
    raise ValueError(f"unknown operation {op}")


def split_group(group, max_k, split_112=True):
    commands = group["commands"]
    next_token = max((c.get("token", 0) for c in commands), default=0) + 1
    output = []
    changed = 0
    pos = 0
    while pos < len(commands):
        quartet = commands[pos:pos + 4]
        if len(quartet) == 4:
            first, second, wait, mma = quartet
            a, b, op = (item.get("instruction", {}) for item in (first, second, mma))
            target_k = (min(max_k, 64 if split_112 is True else split_112)
                        if split_112 and op.get("k") == 112 else max_k)
            valid = (first["command"] == "async" and second["command"] == "async"
                     and wait == {"command": "wait", "tokens": [first["token"], second["token"]]}
                     and mma["command"] == "run"
                     and (a.get("op"), b.get("op"), op.get("op")) == ("load", "load", "mma")
                     and op["k"] > target_k
                     and a["local"]["base"] == op["a"] and b["local"]["base"] == op["b"]
                     and a["global"]["rows"] == op["m"] and a["global"]["cols"] == op["k"]
                     and b["global"]["rows"] == op["k"] and b["global"]["cols"] == op["n"]
                     and a["global"]["col_stride"] == 1
                     and a["local"]["row_stride"] == op["k"]
                     and b["local"]["row_stride"] == op["n"]
                     and op["b"] >= op["a"] + op["m"] * op["k"])
            if valid:
                compact_b = op["a"] + op["m"] * target_k
                if compact_b + target_k * op["n"] <= op["b"] + op["k"] * op["n"]:
                    for offset in range(0, op["k"], target_k):
                        length = min(target_k, op["k"] - offset)
                        aa, bb, mm = copy.deepcopy((a, b, op))
                        aa["global"]["base"] += offset * aa["global"]["col_stride"]
                        aa["global"]["cols"] = length
                        aa["local"].update(cols=length, row_stride=length)
                        bb["global"]["base"] += offset * bb["global"]["row_stride"]
                        bb["global"]["rows"] = length
                        bb["local"].update(base=compact_b, rows=length)
                        mm.update(b=compact_b, k=length)
                        left, right = next_token, next_token + 1
                        next_token += 2
                        output.extend((
                            {"command": "async", "token": left, "instruction": aa},
                            {"command": "async", "token": right, "instruction": bb},
                            {"command": "wait", "tokens": [left, right]},
                            {"command": "run", "instruction": mm},
                        ))
                    changed += 1
                    pos += 4
                    continue
        output.append(commands[pos])
        pos += 1
    if not changed:
        return group, 0
    words = max((_end(command["instruction"]) for command in output
                 if "instruction" in command), default=1)
    return dict(group, rf_kib=math.ceil(words / 256), commands=output), changed


def _independent(groups):
    """A wave may be serialized only when no group observes another's writes."""
    footprints = []
    for group in groups:
        reads = defaultdict(list)
        writes = defaultdict(list)
        for command in group["commands"]:
            instruction = command.get("instruction", {})
            operation = instruction.get("op")
            if operation not in ("load", "load_shared", "store", "store_shared"):
                continue
            view = instruction["global"]
            if view["col_stride"] != 1 or view["row_stride"] < view["cols"]:
                return False
            destination = writes if operation in ("store", "store_shared") else reads
            for row in range(view["rows"]):
                start = view["base"] + row * view["row_stride"]
                destination[instruction["tensor"]].append((start, start + view["cols"] - 1))
        for table in (reads, writes):
            for entries in table.values():
                entries.sort()
        footprints.append((reads, writes))
    if not any(writes for _, writes in footprints):
        return False
    for index, (reads, writes) in enumerate(footprints):
        for other_reads, other_writes in footprints[index + 1:]:
            for left, right in ((writes, other_reads), (writes, other_writes),
                                (reads, other_writes)):
                for tensor in left.keys() & right.keys():
                    a, b = left[tensor], right[tensor]
                    p = q = 0
                    while p < len(a) and q < len(b):
                        if a[p][0] <= b[q][1] and b[q][0] <= a[p][1]:
                            return False
                        if a[p][1] < b[q][1]:
                            p += 1
                        else:
                            q += 1
    return True


def _pack_waves(groups, hardware):
    """Preserve original SMs and partition independent groups by RF/SH budget."""
    try:
        validate_wave_capacity(groups, hardware)
        return [groups]
    except ValueError:
        if not _independent(groups):
            raise
    batches = []
    for group in groups:
        for batch in batches:
            try:
                validate_wave_capacity([*batch, group], hardware)
            except ValueError:
                continue
            batch.append(group)
            break
        else:
            validate_wave_capacity([group], hardware)
            batches.append([group])
    return batches


def screen_case(source, hardware, max_k):
    records = program_records(source)
    header = next(records)
    if header["hardware"]["tc_k_parallel"] != 1 or hardware["tc_k_parallel"] != 1:
        raise ValueError("K split preserves numeric order only for K parallel 1")
    cache = {}
    cycles = waves = split_chunks = split_waves = partitioned_waves = 0
    for record in records:
        if record["record"] == "commit":
            cycles += 1
        elif record["record"] == "wave":
            groups = []
            count = 0
            for group in record["groups"]:
                converted, n = split_group(group, max_k)
                groups.append(converted)
                count += n
            batches = _pack_waves(groups, hardware)
            for batch in batches:
                cycles += estimate_wave(batch, hardware, cache)
                waves += 1
            partitioned_waves += len(batches) > 1
            split_chunks += count
            split_waves += bool(count)
    return {"cycles": cycles, "waves": waves, "split_chunks": split_chunks,
            "split_waves": split_waves, "partitioned_waves": partitioned_waves}


def screen(spec_path, output):
    spec_path, output = Path(spec_path), Path(output)
    spec = json.loads(spec_path.read_text())
    base = json.loads(Path(spec["base_solution"]).read_text())
    hardware = spec["hardware"]
    validate(hardware)
    output.mkdir(parents=True, exist_ok=True)
    progress_path = output / "progress.json"
    identity = {"spec_sha256": sha(spec_path),
                "estimator_sha256": sha(Path(__file__).with_name("estimate.py")),
                "model_sha256": sha(Path(__file__)),
                "source_sha256": {case: base["selected_programs"][case]["program_sha256"]
                                  for case in SCORE_CASES}}
    progress = json.loads(progress_path.read_text()) if progress_path.exists() else {
        **identity, "cases": {}}
    if any(progress.get(key) != value for key, value in identity.items()):
        raise ValueError("changed screen inputs")
    for case in SCORE_CASES:
        if case in progress["cases"]:
            continue
        selected = base["selected_programs"][case]
        if sha(selected["program"]) != selected["program_sha256"]:
            raise ValueError("source SHA mismatch")
        try:
            max_k = spec.get("case_max_k", {}).get(case, spec["max_k"])
            result = screen_case(selected["program"], hardware, max_k)
        except ValueError as error:
            result = {"infeasible": str(error)}
        progress["cases"][case] = result
        write(progress_path, progress)
    feasible = all("cycles" in progress["cases"][case] for case in SCORE_CASES)
    score = (1000 * math.exp(sum(weight * math.log(reference / progress["cases"][case]["cycles"])
             for case, (reference, weight) in SCORE_CASES.items())) if feasible else None)
    result = {**identity, "hardware": hardware, "area_au": area(hardware),
              "max_k": spec["max_k"], "case_max_k": spec.get("case_max_k", {}),
              "cases": progress["cases"],
              "conditional_predicted_score": score,
              "meets_grade_gate": score is not None and score >= spec["target_score"],
              "candidate_program_generated": False,
              "numerical_correctness": "not_checked", "power": "not_checked",
              "official_score": None}
    write(output / "screen.json", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("spec", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    result = screen(args.spec, args.output)
    print(json.dumps({"area_au": result["area_au"],
                      "conditional_predicted_score": result["conditional_predicted_score"],
                      "cases": result["cases"]}, indent=2))


if __name__ == "__main__":
    main()
