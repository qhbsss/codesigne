"""Price moving the independent AV value DMA before ragged score DMA batches."""

import argparse
import json
from pathlib import Path

from .estimate import estimate_wave, program_records, validate_wave_capacity
from .hardware import validate
from .local_causal_mask import _fill_invalid, _localize_group, _mask_wave
from .tool import sha, write


def prefetch_group(group, score_ids, context, max_live_tokens):
    commands = list(group["commands"])
    swaps = 0
    for index in range(len(commands) - 2):
        first, second, wait = commands[index:index + 3]
        score = first.get("instruction", {})
        partner = second.get("instruction", {})
        if (first["command"] == second["command"] == "async" and
                score.get("op") == partner.get("op") == "load" and
                score["tensor"] in score_ids and
                partner["tensor"] not in score_ids and
                wait["command"] == "wait" and
                set(wait["tokens"]) == {first["token"], second["token"]} and
                _fill_invalid(score, context)):
            commands[index], commands[index + 1] = second, first
            swaps += 1
    if not swaps:
        return None, 0, 0
    candidate, fills = _localize_group(
        dict(group, commands=commands), score_ids, context, max_live_tokens)
    return candidate, fills, swaps


def screen(source, hardware, base_ragged_cycles, output=None):
    source = Path(source)
    validate(hardware)
    records = program_records(source)
    header = next(records)
    if header["decode"] or header["batch"] != 1:
        raise ValueError("prefetch requires batch-one prefill")
    context = header["shape"]["prefill"]
    heads = header["shape"]["heads"]
    max_live = hardware["dma_engines"] * (1 + hardware["dma_depth"])
    active = []
    pending_score_run = []
    cache = {}
    stats = {"waves": 0, "candidate_waves": 0, "accepted_waves": 0,
             "accepted_swaps": 0, "original_affected_cycles": 0,
             "replacement_affected_cycles": 0, "accepted_wave_indices": []}

    def finish_score_run():
        if len(pending_score_run) == heads:
            for index in pending_score_run:
                active[index] = True
        pending_score_run.clear()

    for record in records:
        kind = record["record"]
        if kind in ("input", "alloc"):
            score = kind == "alloc" and record["len"] == context * context
            if not score:
                finish_score_run()
            active.append(False)
            if score:
                pending_score_run.append(len(active) - 1)
            continue
        finish_score_run()
        if kind == "release":
            active.pop()
            continue
        if kind != "wave":
            continue
        wave_index = stats["waves"]
        stats["waves"] += 1
        score_ids = {index for index, score in enumerate(active) if score}
        if _mask_wave(record["groups"], score_ids, context):
            continue
        original = []
        candidate = []
        swaps = 0
        for group in record["groups"]:
            baseline, _ = _localize_group(group, score_ids, context, max_live)
            transformed, _, group_swaps = prefetch_group(
                group, score_ids, context, max_live)
            original.append(baseline)
            candidate.append(transformed if group_swaps else baseline)
            swaps += group_swaps
        if not swaps:
            continue
        stats["candidate_waves"] += 1
        validate_wave_capacity(candidate, hardware)
        before = estimate_wave(original, hardware, cache)
        after = estimate_wave(candidate, hardware, cache)
        if after >= before:
            continue
        stats["accepted_waves"] += 1
        stats["accepted_swaps"] += swaps
        stats["accepted_wave_indices"].append(wave_index)
        stats["original_affected_cycles"] += before
        stats["replacement_affected_cycles"] += after
    result = {"scope": "value DMA prefetch before batched causal score loads",
              "source_sha256": sha(source),
              "estimator_sha256": sha(Path(__file__).with_name("estimate.py")),
              "model_sha256": sha(Path(__file__)),
              "ragged_model_sha256": sha(Path(__file__).with_name("local_causal_mask.py")),
              "hardware": hardware, "base_ragged_cycles": base_ragged_cycles,
              **stats,
              "predicted_cycles": (base_ragged_cycles -
                                   stats["original_affected_cycles"] +
                                   stats["replacement_affected_cycles"]),
              "candidate_program_generated": False,
              "numerical_correctness": "not_checked", "official_score": None}
    if output is not None:
        Path(output).parent.mkdir(parents=True, exist_ok=True)
        write(output, result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("hardware", type=Path)
    parser.add_argument("base_ragged_cycles", type=int)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    document = json.loads(args.hardware.read_text())
    hardware = document.get("hardware", document)
    result = screen(args.source, hardware, args.base_ragged_cycles, args.output)
    print(json.dumps({key: result[key] for key in
                      ("candidate_waves", "accepted_waves", "predicted_cycles")},
                     indent=2))


if __name__ == "__main__":
    main()
