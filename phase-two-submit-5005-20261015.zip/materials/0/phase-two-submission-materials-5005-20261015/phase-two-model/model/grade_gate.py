"""Screen five static programs before starting an official grade."""

import json
import math
from pathlib import Path

from .estimate import estimate_program
from .tool import SCORE_CASES


def screen_five_programs(programs, receipt=None, target_score=5000, estimator=estimate_program):
    if not isinstance(target_score, (int, float)) or not math.isfinite(target_score) or target_score <= 0:
        raise ValueError("grade target must be positive and finite")
    if isinstance(programs, (str, Path)):
        programs = {name: Path(programs) / f"{name}.jsonl" for name in SCORE_CASES}
    if set(programs) != set(SCORE_CASES):
        raise ValueError("prediction requires exactly the five official cases")
    cycles = {name: estimator(programs[name])["cycles"] for name in SCORE_CASES}
    if any(not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0
           for value in cycles.values()):
        raise ValueError("prediction requires positive finite cycles for every case")
    score = 1000 * math.exp(sum(weight * math.log(reference / cycles[name])
                                for name, (reference, weight) in SCORE_CASES.items()))
    if not math.isfinite(score):
        raise ValueError("prediction produced a nonfinite score")
    result = {"conditional_predicted_score": score, "predicted_cycles": cycles,
              "target_score": target_score, "grade_allowed": score >= target_score}
    if receipt is not None:
        Path(receipt).write_text(json.dumps(result, indent=2) + "\n")
    return result
