"""Price single-K GEMM panel reuse without materializing candidate programs.

For an output tile with one reduction chunk, the accumulator is dead as soon
as the tile is stored.  Independent output tiles can therefore reuse both the
B panel and the same accumulator address.  This differs from the general
multi-chunk transformation, which must keep one accumulator per output tile.
"""

import argparse
import copy
import json
from collections import defaultdict
from pathlib import Path

from .estimate import estimate_wave, program_records, validate_wave_capacity
from .hardware import validate
from .reuse_b import _tile
from .reuse_b_within import _tiles
from .tool import sha, write


def _reuse_batch(tiles):
    """Return paid commands for independent one-chunk tiles sharing B."""
    first = tiles[0]
    panel = first["chunks"][0][1]
    commands = []
    token = 0
    panel_token = None
    for index, tile in enumerate(tiles):
        activation, candidate_panel, operation = tile["chunks"][0]
        if candidate_panel != panel:
            raise ValueError("panel reuse batch changed B load")
        commands.append({"command": "run",
                         "instruction": copy.deepcopy(tile["fill"])})
        if index == 0:
            token += 1
            panel_token = token
            commands.append({"command": "async", "token": token,
                             "instruction": copy.deepcopy(panel)})
        token += 1
        commands.append({"command": "async", "token": token,
                         "instruction": copy.deepcopy(activation)})
        commands.append({"command": "wait", "tokens":
                         [panel_token, token] if index == 0 else [token]})
        commands.append({"command": "run",
                         "instruction": copy.deepcopy(operation)})
        commands.append({"command": "run",
                         "instruction": copy.deepcopy(tile["store"])})
    return commands


def _outputs_independent(first, second):
    if first["store"]["tensor"] != second["store"]["tensor"]:
        return True
    return all(left_end < right_start or right_end < left_start
               for left_start, left_end in first["footprint"]
               for right_start, right_end in second["footprint"])


def _logical_tiles(group):
    """Recover one-chunk tiles from original or already panel-reused commands."""
    parsed = _tiles(group)
    if parsed is not None:
        return [tile for _, tile in parsed]
    fills = {}
    loads = {}
    pending = defaultdict(list)
    tiles = []
    for command in group["commands"]:
        instruction = command.get("instruction", {})
        operation = instruction.get("op")
        if command["command"] == "wait":
            continue
        if operation == "fill" and command["command"] == "run":
            fills[instruction["dst"]] = copy.deepcopy(instruction)
            continue
        if operation == "load" and command["command"] in ("run", "async"):
            loads[instruction["local"]["base"]] = copy.deepcopy(instruction)
            continue
        if operation == "mma" and command["command"] == "run":
            if (instruction["c"] not in fills or instruction["a"] not in loads or
                    instruction["b"] not in loads):
                return None
            pending[instruction["c"]].append((
                copy.deepcopy(fills[instruction["c"]]),
                copy.deepcopy(loads[instruction["a"]]),
                copy.deepcopy(loads[instruction["b"]]),
                copy.deepcopy(instruction)))
            continue
        if operation == "store" and command["command"] == "run":
            base = instruction["local"]["base"]
            if not pending[base]:
                return None
            fill, activation, panel, mma = pending[base].pop(0)
            fill["dst"] = 0
            mma["c"] = 0
            store = copy.deepcopy(instruction)
            store["local"]["base"] = 0
            synthetic = dict(group, commands=[
                {"command": "run", "instruction": fill},
                {"command": "async", "token": 1, "instruction": activation},
                {"command": "async", "token": 2, "instruction": panel},
                {"command": "wait", "tokens": [1, 2]},
                {"command": "run", "instruction": mma},
                {"command": "run", "instruction": store},
            ])
            tile = _tile(synthetic)
            if tile is None:
                return None
            tiles.append(tile)
            continue
        return None
    if any(queue for queue in pending.values()):
        return None
    return tiles


def reuse_group(group, max_fanout):
    """Reuse equal B panels in one group while preserving RF reservation."""
    if max_fanout < 2:
        raise ValueError("max_fanout must be at least two")
    tiles = _logical_tiles(group)
    if tiles is None or len(tiles) < 2:
        return group, 0, 0
    if not all(_outputs_independent(left, right)
               for index, left in enumerate(tiles)
               for right in tiles[index + 1:]):
        return group, 0, 0
    buckets = defaultdict(list)
    order = []
    for tile in tiles:
        key = tile["signature"]
        if key not in buckets:
            order.append(key)
        buckets[key].append(tile)
    if all(len(bucket) == 1 for bucket in buckets.values()):
        return group, 0, 0
    commands = []
    reused_tiles = 0
    for key in order:
        bucket = buckets[key]
        for offset in range(0, len(bucket), max_fanout):
            batch = bucket[offset:offset + max_fanout]
            if len(batch) == 1:
                # Rebuild this tile to keep token numbering local and valid.
                commands.extend(_reuse_batch(batch))
                continue
            commands.extend(_reuse_batch(batch))
            reused_tiles += len(batch)
    original_loads = sum(command.get("instruction", {}).get("op") == "load"
                         for command in group["commands"])
    replacement_loads = sum(command.get("instruction", {}).get("op") == "load"
                            for command in commands)
    removed_loads = original_loads - replacement_loads
    if removed_loads <= 0:
        return group, 0, 0
    return dict(group, commands=commands), reused_tiles, removed_loads


def screen(source, hardware, base_cycles, max_fanout, output=None):
    """Apply the scheduling variable in memory and price only changed waves."""
    source = Path(source)
    validate(hardware)
    if base_cycles <= 0:
        raise ValueError("base_cycles must be positive")
    records = program_records(source)
    header = next(records)
    cache = {}
    stats = {"waves": 0, "changed_waves": 0, "changed_groups": 0,
             "reused_tiles": 0, "removed_b_loads": 0,
             "original_affected_cycles": 0, "replacement_affected_cycles": 0}
    for record in records:
        if record["record"] != "wave":
            continue
        stats["waves"] += 1
        groups = []
        changed = False
        for group in record["groups"]:
            candidate, reused, removed = reuse_group(group, max_fanout)
            groups.append(candidate)
            if removed:
                changed = True
                stats["changed_groups"] += 1
                stats["reused_tiles"] += reused
                stats["removed_b_loads"] += removed
        if not changed:
            continue
        validate_wave_capacity(groups, hardware)
        stats["changed_waves"] += 1
        stats["original_affected_cycles"] += estimate_wave(
            record["groups"], hardware, cache)
        stats["replacement_affected_cycles"] += estimate_wave(groups, hardware, cache)
    predicted = (base_cycles - stats["original_affected_cycles"] +
                 stats["replacement_affected_cycles"])
    result = {"scope": "single-reduction-chunk independent GEMM tiles",
              "source_sha256": sha(source),
              "estimator_sha256": sha(Path(__file__).with_name("estimate.py")),
              "model_sha256": sha(Path(__file__)),
              "hardware": hardware, "max_fanout": max_fanout,
              "base_cycles": base_cycles, **stats,
              "predicted_cycles": predicted,
              "candidate_program_generated": False,
              "numerical_correctness": "not_checked", "official_score": None}
    if output is not None:
        Path(output).parent.mkdir(parents=True, exist_ok=True)
        write(output, result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("hardware", type=Path,
                        help="JSON file containing a hardware object or solution.hardware")
    parser.add_argument("base_cycles", type=int)
    parser.add_argument("output", type=Path)
    parser.add_argument("--max-fanout", type=int, default=64)
    args = parser.parse_args()
    document = json.loads(args.hardware.read_text())
    hardware = document.get("hardware", document)
    result = screen(args.source, hardware, args.base_cycles,
                    args.max_fanout, args.output)
    print(json.dumps({key: result[key] for key in
                      ("max_fanout", "removed_b_loads", "predicted_cycles")},
                     indent=2))


if __name__ == "__main__":
    main()
