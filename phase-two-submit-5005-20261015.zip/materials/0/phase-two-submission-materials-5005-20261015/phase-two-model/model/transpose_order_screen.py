"""Screen independent initial K transpose task orders without writing programs."""

import argparse
import copy
import json
import math
from pathlib import Path

from .estimate import estimate_wave
from .padded_k_transpose_screen import _records
from .tool import SCORE_CASES, sha, write


MODES = ("original", "reverse_groups", "reverse_tasks", "even_odd", "channel_order")


def reordered(record, mode, channels):
    result = copy.deepcopy(record)
    if mode == "reverse_groups":
        result["groups"].reverse()
        return result
    if mode == "original":
        return result
    if mode not in MODES:
        raise ValueError(f"unknown transpose order: {mode}")
    for group in result["groups"]:
        commands = group["commands"]
        if len(commands) % 3:
            raise ValueError("transpose commands are not independent triples")
        triples = [commands[i:i + 3] for i in range(0, len(commands), 3)]
        for first, second, third in triples:
            if (first["command"] != "async" or second != {"command": "wait", "tokens": [first["token"]]}
                    or third["command"] != "run" or
                    first["instruction"]["op"] != "load_shared" or
                    third["instruction"]["op"] != "store_shared"):
                raise ValueError("transpose task dependency differs from expected triple")
        if mode == "reverse_tasks":
            triples.reverse()
        elif mode == "even_odd":
            triples = triples[::2] + triples[1::2]
        elif mode == "channel_order":
            triples.sort(key=lambda t: (t[2]["instruction"]["global"]["base"] // 64) % channels)
        group["commands"] = [command for triple in triples for command in triple]
    return result


def screen(source, base_manifest, case, output):
    source, base_manifest, output = map(Path, (source, base_manifest, output))
    base = json.loads(base_manifest.read_text())
    if (case not in ("w-d1", "w-d16", "w-d4l") or
            sha(source) != base["program_sha256"][case]):
        raise ValueError("source or case differs from five-case base")
    hardware = base["hardware"]
    totals = {mode: 0 for mode in MODES}
    selected = []
    cache = {}
    pairs = set()
    count = 0
    for header, record, pair in _records(source):
        if pair is None:
            continue
        if header["hardware"] != hardware:
            raise ValueError("shared hardware differs from base")
        pairs.add(pair)
        count += 1
        measured = {mode: estimate_wave(reordered(record, mode, hardware["hbm_channels"])["groups"],
                                        hardware, cache) for mode in MODES}
        for mode, cycles in measured.items():
            totals[mode] += cycles
        winner = min(MODES, key=lambda mode: measured[mode])
        selected.append({"wave": count - 1, "mode": winner, "cycles": measured[winner],
                         "baseline_cycles": measured["original"]})
    if len(pairs) != header["shape"]["layers"] or not count:
        raise ValueError("initial transpose pairs missing")
    original = totals["original"]
    totals["per_wave_best"] = sum(row["cycles"] for row in selected)
    cases = {}
    for mode, cycles in totals.items():
        predicted = dict(base["exact_model_cycles"])
        predicted[case] += cycles - original
        score = 1000 * math.exp(sum(weight * math.log(reference / predicted[name])
                                    for name, (reference, weight) in SCORE_CASES.items()))
        cases[mode] = {"affected_cycles": cycles, "five_case_model_score": score,
                       "meets_grade_gate": score >= 5000,
                       "five_case_model_cycles": predicted}
    result = {"case": case, "source_sha256": sha(source),
              "base_manifest_sha256": sha(base_manifest), "affected_waves": count,
              "transpose_pairs": len(pairs), "modes": cases, "selected": selected,
              "candidate_program_generated": False, "official_score": None}
    write(output, result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("base_manifest", type=Path)
    parser.add_argument("case")
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    result = screen(args.source, args.base_manifest, args.case, args.output)
    print(json.dumps({"case": args.case, "modes": {name: row["affected_cycles"]
                      for name, row in result["modes"].items()}}, indent=2))


if __name__ == "__main__":
    main()
