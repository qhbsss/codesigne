"""Model and materialize cache-line-padded decode K scratch layouts."""

import argparse
import copy
import json
import math
from pathlib import Path

from .estimate import _dma_lines, estimate_wave, program_records


def _layout(header, old_stride=None, new_stride=None):
    if not header["decode"]:
        raise ValueError("K padding applies only to decode")
    shape = header["shape"]
    natural = shape["history"] + shape["steps"]
    old = natural if old_stride is None else old_stride
    new = math.ceil(natural / 16) * 16 if new_stride is None else new_stride
    if old < natural or new < natural or new == old:
        raise ValueError("invalid K row stride transition")
    if new % 16:
        raise ValueError("new K row stride must align to a cache line")
    return old, new, header["batch"] * shape["d"] * old


def _pad_wave(record, targets, old, new, channels):
    padded = copy.deepcopy(record)
    changed = 0
    lines_before = lines_after = 0
    for group in padded["groups"]:
        for command in group["commands"]:
            instruction = command.get("instruction", {})
            if instruction.get("tensor") not in targets or instruction.get("op") not in (
                    "load", "store", "load_shared", "store_shared"):
                continue
            view = instruction["global"]
            base = view["base"]
            row_stride = view["row_stride"]
            if view["col_stride"] != 1 or (view["rows"] > 1 and row_stride != old):
                raise ValueError("unexpected transposed K view")
            lines_before += sum(_dma_lines(base % (64 * channels), view["rows"],
                                             view["cols"], row_stride, 1, channels)[0])
            row, col = divmod(base, old)
            view["base"] = row * new + col
            if row_stride == old:
                view["row_stride"] = new
            lines_after += sum(_dma_lines(view["base"] % (64 * channels), view["rows"],
                                            view["cols"], view["row_stride"], 1, channels)[0])
            changed += 1
    return padded, changed, lines_before, lines_after


def screen_case(source, hardware, baseline_cycles, old_stride=None, new_stride=None):
    records = program_records(source)
    header = next(records)
    old, new, old_size = _layout(header, old_stride, new_stride)
    active = []
    targets = set()
    cache = {}
    result = {"baseline_cycles": baseline_cycles, "changed_waves": 0,
              "changed_dma": 0, "lines_before": 0, "lines_after": 0,
              "target_allocations": 0, "old_stride": old, "new_stride": new}
    delta = 0
    for record in records:
        kind = record["record"]
        if kind in ("input", "alloc"):
            tensor = len(active)
            active.append(record["len"])
            if kind == "alloc" and record["len"] == old_size:
                targets.add(tensor)
                result["target_allocations"] += 1
        elif kind == "release":
            if record["tensor"] != len(active) - 1:
                raise ValueError("tensor stack changed")
            targets.discard(record["tensor"])
            active.pop()
        elif kind == "wave" and targets:
            padded, changed, before, after = _pad_wave(
                record, targets, old, new, hardware["hbm_channels"])
            if changed:
                delta += estimate_wave(padded["groups"], hardware, cache) - \
                         estimate_wave(record["groups"], hardware, cache)
                result["changed_waves"] += 1
                result["changed_dma"] += changed
                result["lines_before"] += before
                result["lines_after"] += after
    if result["target_allocations"] != header["shape"]["layers"] or not result["changed_waves"]:
        raise ValueError("did not find each layer's transposed K scratch")
    result["cycle_delta"] = delta
    result["predicted_cycles"] = baseline_cycles + delta
    return result


def write_expanded(source, destination, hardware, old_stride=None, new_stride=None):
    records = program_records(source)
    header = next(records)
    old, new, old_size = _layout(header, old_stride, new_stride)
    active = []
    targets = set()
    statistics = {"target_allocations": 0, "changed_waves": 0,
                  "changed_dma": 0, "old_stride": old, "new_stride": new}
    destination = Path(destination)
    with destination.open("x") as writer:
        writer.write(json.dumps(dict(header, hardware=hardware), separators=(",", ":")) + "\n")
        for record in records:
            kind = record["record"]
            if kind in ("input", "alloc"):
                tensor = len(active)
                active.append(record["len"])
                if kind == "alloc" and record["len"] == old_size:
                    targets.add(tensor)
                    record = dict(record, len=header["batch"] * header["shape"]["d"] * new)
                    statistics["target_allocations"] += 1
            elif kind == "release":
                if record["tensor"] != len(active) - 1:
                    raise ValueError("tensor stack changed")
                targets.discard(record["tensor"])
                active.pop()
            elif kind == "wave" and targets:
                record, changed, _, _ = _pad_wave(record, targets, old, new,
                                                   hardware["hbm_channels"])
                if changed:
                    statistics["changed_waves"] += 1
                    statistics["changed_dma"] += changed
            writer.write(json.dumps(record, separators=(",", ":")) + "\n")
    if statistics["target_allocations"] != header["shape"]["layers"]:
        raise ValueError("K scratch allocation mismatch")
    return statistics


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("hardware", type=Path)
    parser.add_argument("baseline_cycles", type=int)
    args = parser.parse_args()
    hardware = json.loads(args.hardware.read_text())
    print(json.dumps(screen_case(args.source, hardware, args.baseline_cycles), indent=2))


if __name__ == "__main__":
    main()
