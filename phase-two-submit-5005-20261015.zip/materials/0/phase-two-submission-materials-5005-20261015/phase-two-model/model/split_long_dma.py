"""Screen two-way splitting of long DMA loads across all five cases."""

import argparse
import json
import math
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

from .estimate import estimate_program, estimate_wave, program_records
from .hardware import area, validate
from .split_k_dma import _split_wave
from .tool import SCORE_CASES, STARTER, sha, write


def transform(source, hardware, output=None, baseline_cycles=None,
              factor=2, min_rows=64, min_cols=16,
              choose_negative=False, selected_waves=None):
    records = program_records(source)
    header = next(records)
    cache = {}
    changed_waves = changed_dma = delta = 0
    accepted_waves = []
    wave_index = -1
    writer = Path(output).open("x") if output is not None else None
    try:
        if writer:
            writer.write(json.dumps(dict(header, hardware=hardware), separators=(",", ":")) + "\n")
        for record in records:
            if record["record"] == "wave":
                wave_index += 1
                rewritten, changed = _split_wave(record, None, factor, min_rows, min_cols)
                if changed:
                    wave_delta = 0
                    if baseline_cycles is not None:
                        wave_delta = estimate_wave(rewritten["groups"], hardware, cache) - \
                                     estimate_wave(record["groups"], hardware, cache)
                    accept = ((wave_delta < 0) if choose_negative else
                              (wave_index in selected_waves if selected_waves is not None else True))
                    if accept:
                        changed_waves += 1
                        changed_dma += changed
                        delta += wave_delta
                        accepted_waves.append(wave_index)
                        record = rewritten
            if writer:
                writer.write(json.dumps(record, separators=(",", ":")) + "\n")
    finally:
        if writer:
            writer.close()
    return {"factor": factor, "min_rows": min_rows, "min_cols": min_cols,
            "changed_waves": changed_waves, "changed_dma": changed_dma,
            "accepted_waves": accepted_waves,
            "cycle_delta": delta,
            "predicted_cycles": baseline_cycles + delta if baseline_cycles is not None else None}


def screen(base_dir, output, factor=2, min_rows=64, min_cols=16,
           choose_negative=False):
    base_dir, output = Path(base_dir), Path(output)
    base = json.loads((base_dir / "manifest.json").read_text())
    hardware = base["hardware"]
    validate(hardware)
    cycles = dict(base["model_cycles"])
    result = {"source_manifest_sha256": sha(base_dir / "manifest.json"),
              "hardware": hardware, "factor": factor, "min_rows": min_rows,
              "min_cols": min_cols, "choose_negative": choose_negative,
              "baseline_cycles": cycles.copy(),
              "predicted_cycles": cycles, "cases": {},
              "candidate_program_generated": False, "official_score": None}
    output.parent.mkdir(parents=True, exist_ok=True)
    for case in SCORE_CASES:
        source = base_dir / "programs" / f"{case}.jsonl"
        if sha(source) != base["programs"][case]["program_sha256"]:
            raise ValueError(f"source changed: {case}")
        row = transform(source, hardware, baseline_cycles=cycles[case], factor=factor,
                        min_rows=min_rows, min_cols=min_cols,
                        choose_negative=choose_negative)
        cycles[case] = row["predicted_cycles"]
        result["cases"][case] = row
        write(output, result)
        print(case, row, flush=True)
    score = 1000 * math.exp(sum(weight * math.log(reference / cycles[case])
        for case, (reference, weight) in SCORE_CASES.items()))
    result["conditional_predicted_score"] = score
    result["meets_grade_gate"] = score >= 5000
    write(output, result)
    print("five-case score", score, flush=True)
    return result


def materialize(base_dir, screen_path, output):
    base_dir, screen_path, output = map(Path, (base_dir, screen_path, output))
    base = json.loads((base_dir / "manifest.json").read_text())
    screen_result = json.loads(screen_path.read_text())
    if (screen_result["source_manifest_sha256"] != sha(base_dir / "manifest.json") or
            screen_result["conditional_predicted_score"] < 5000):
        raise ValueError("source changed or five-case model gate not passed")
    hardware = base["hardware"]
    output.mkdir(parents=True, exist_ok=False)
    programs = output / "programs"
    programs.mkdir()
    hashes = {}
    for case in SCORE_CASES:
        source = base_dir / "programs" / f"{case}.jsonl"
        if sha(source) != base["programs"][case]["program_sha256"]:
            raise ValueError(f"source changed: {case}")
        destination = programs / f"{case}.jsonl"
        if screen_result["cases"][case]["changed_waves"]:
            with tempfile.TemporaryDirectory(prefix=f"phase-two-longdma-{case}-") as temp:
                expanded = Path(temp) / "expanded.jsonl"
                transform(source, hardware, output=expanded,
                          factor=screen_result["factor"],
                          min_rows=screen_result["min_rows"],
                          min_cols=screen_result["min_cols"],
                          selected_waves=(set(screen_result["cases"][case]["accepted_waves"])
                                          if "accepted_waves" in screen_result["cases"][case]
                                          else None))
                subprocess.run([sys.executable, str(STARTER / "tools/compact_program.py"),
                                str(expanded), str(destination)], check=True)
        else:
            shutil.copyfile(source, destination)
        hashes[case] = sha(destination)
    exact = {case: estimate_program(programs / f"{case}.jsonl")["cycles"]
             for case in SCORE_CASES}
    score = 1000 * math.exp(sum(weight * math.log(reference / exact[case])
        for case, (reference, weight) in SCORE_CASES.items()))
    result = {"hardware": hardware, "area_au": area(hardware),
              "screen_sha256": sha(screen_path), "factor": screen_result["factor"],
              "min_rows": screen_result["min_rows"], "min_cols": screen_result["min_cols"],
              "program_sha256": hashes, "exact_model_cycles": exact,
              "exact_model_score": score, "grade_allowed": score >= 5000,
              "official_score": None}
    write(output / "manifest.json", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="mode", required=True)
    first = sub.add_parser("screen")
    first.add_argument("base_dir", type=Path)
    first.add_argument("output", type=Path)
    first.add_argument("--factor", type=int, default=2)
    first.add_argument("--min-rows", type=int, default=64)
    first.add_argument("--min-cols", type=int, default=16)
    first.add_argument("--choose-negative", action="store_true")
    second = sub.add_parser("materialize")
    second.add_argument("base_dir", type=Path)
    second.add_argument("screen", type=Path)
    second.add_argument("output", type=Path)
    args = parser.parse_args()
    if args.mode == "screen":
        screen(args.base_dir, args.output, args.factor, args.min_rows,
               args.min_cols, args.choose_negative)
    else:
        print(json.dumps(materialize(args.base_dir, args.screen, args.output), indent=2))


if __name__ == "__main__":
    main()
