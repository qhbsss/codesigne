"""Price sequential single-K accumulators under the RF64 portfolio."""

import argparse
import copy
import json
from pathlib import Path

from .estimate import estimate_wave, program_records
from .inplace_panel_reuse import reuse_group
from .ksplit_screen import _end, _independent, _pack_waves, split_group
from .tool import sha, write


def _compact(group):
    if any(command.get("instruction", {}).get("op") not in
           (None, "fill", "load", "mma", "store")
           for command in group["commands"]):
        return group, False
    candidate, _, removed = reuse_group(group, 64)
    if not removed:
        return group, False
    candidate = copy.deepcopy(candidate)
    mmas = [command["instruction"] for command in candidate["commands"]
            if command.get("instruction", {}).get("op") == "mma"]
    old_bases = {mma["b"] for mma in mmas}
    if len(old_bases) != 1:
        return group, False
    old_b = next(iter(old_bases))
    new_b = max(mma["a"] + mma["m"] * mma["k"] for mma in mmas)
    if new_b >= old_b:
        return group, False
    for command in candidate["commands"]:
        instruction = command.get("instruction", {})
        if instruction.get("op") == "load" and instruction["local"]["base"] == old_b:
            instruction["local"]["base"] = new_b
        elif instruction.get("op") == "mma":
            instruction["b"] = new_b
        elif instruction.get("op") == "store" and instruction["local"]["base"] == old_b:
            return group, False
    words = max(_end(command["instruction"]) for command in candidate["commands"]
                if "instruction" in command)
    candidate["rf_kib"] = (words + 255) // 256
    return candidate, True


def _cost(groups, hardware, max_k, cache):
    converted = [split_group(group, max_k)[0] for group in groups]
    return sum(estimate_wave(batch, hardware, cache)
               for batch in _pack_waves(converted, hardware))


def screen_case(source, hardware, max_k):
    records = program_records(source)
    next(records)
    cache = {}
    accepted = []
    wave_index = -1
    for record in records:
        if record["record"] != "wave":
            continue
        wave_index += 1
        groups = record["groups"]
        if not _independent(groups):
            continue
        replacements = [_compact(group) for group in groups]
        if not any(changed for _, changed in replacements):
            continue
        candidate = [group for group, _ in replacements]
        try:
            old_cycles = _cost(groups, hardware, max_k, cache)
            new_cycles = _cost(candidate, hardware, max_k, cache)
        except ValueError:
            continue
        if new_cycles < old_cycles:
            accepted.append({"wave": wave_index, "old_cycles": old_cycles,
                             "new_cycles": new_cycles,
                             "saving": old_cycles - new_cycles})
    return {"source_sha256": sha(source), "accepted_waves": accepted,
            "delta_cycles": -sum(row["saving"] for row in accepted)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("base_solution", type=Path)
    parser.add_argument("ksplit_screen", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    base = json.loads(args.base_solution.read_text())
    prior = json.loads(args.ksplit_screen.read_text())
    result = {}
    for case in ("w-p", "a-p", "w-d1", "w-d16", "w-d4l"):
        source = base["selected_programs"][case]["program"]
        max_k = prior.get("case_max_k", {}).get(case, prior["max_k"])
        result[case] = screen_case(source, prior["hardware"], max_k)
        print(case, result[case]["delta_cycles"],
              len(result[case]["accepted_waves"]), flush=True)
    write(args.output, {"cases": result, "candidate_program_generated": False,
                        "official_score": None})


if __name__ == "__main__":
    main()
