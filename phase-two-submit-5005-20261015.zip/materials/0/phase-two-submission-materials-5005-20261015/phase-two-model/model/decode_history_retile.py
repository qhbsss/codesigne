"""Retile a complete decode history GEMM, avoiding per-K128 tail fragments."""

import copy
import math


def _tile(commands):
    if (len(commands) < 6 or commands[0].get("instruction", {}).get("op") != "fill"
            or commands[-1].get("instruction", {}).get("op") != "store"
            or (len(commands) - 2) % 4):
        return None
    quartets = [commands[i:i + 4] for i in range(1, len(commands) - 1, 4)]
    if len(quartets) < 17:
        return None
    first_a = quartets[0][0].get("instruction", {})
    first_b = quartets[0][1].get("instruction", {})
    first_mma = quartets[0][3].get("instruction", {})
    if (first_a.get("op") != "load" or first_b.get("op") != "load"
            or first_mma.get("op") != "mma"
            or (first_mma.get("m"), first_mma.get("n"), first_mma.get("k")) !=
            (1, 32, 128)):
        return None
    main = quartets[:-1]
    tail = quartets[-1]
    if len(main) * 128 != 4096:
        return None
    if tail[3].get("instruction", {}).get("k") != 1:
        return None
    accumulator = first_mma["c"]
    for index, quartet in enumerate(quartets):
        a, b, wait, mma = quartet
        ia, ib, im = (item.get("instruction", {}) for item in (a, b, mma))
        expected_k = 128 if index < len(main) else 1
        offset = index * 128
        if (a.get("command") != "async" or b.get("command") != "async"
                or wait != {"command": "wait", "tokens": [a.get("token"), b.get("token")]}
                or mma.get("command") != "run"
                or (ia.get("op"), ib.get("op"), im.get("op")) !=
                ("load", "load", "mma")
                or (im.get("m"), im.get("n"), im.get("k"), im.get("c")) !=
                (1, 32, expected_k, accumulator)
                or ia["tensor"] != first_a["tensor"] or
                ib["tensor"] != first_b["tensor"]
                or ia["global"]["base"] != first_a["global"]["base"] + offset
                or ib["global"]["base"] != first_b["global"]["base"] +
                offset * first_b["global"]["row_stride"]
                or ia["global"]["rows"] != 1 or ia["global"]["cols"] != expected_k
                or ib["global"]["rows"] != expected_k or ib["global"]["cols"] != 32
                or ia["global"]["col_stride"] != 1 or
                ib["global"]["col_stride"] != 1
                or im["a"] != ia["local"]["base"] or
                im["b"] != ib["local"]["base"]):
            return None
    if commands[0]["instruction"]["dst"] != accumulator or +            commands[-1]["instruction"]["local"]["base"] != accumulator:
        return None
    return first_a, first_b, first_mma, tail


def retile_group(group, panel_k):
    if not 16 <= panel_k <= 120 or group["sh_kib"]:
        return group, 0
    commands = group["commands"]
    tiles = []
    start = 0
    for index, command in enumerate(commands):
        if command.get("instruction", {}).get("op") != "store":
            continue
        tile = commands[start:index + 1]
        parsed = _tile(tile)
        if parsed is None:
            return group, 0
        tiles.append((tile, parsed))
        start = index + 1
    if not tiles or start != len(commands):
        return group, 0
    output = []
    token = 1
    for tile, (first_a, first_b, first_mma, tail) in tiles:
        output.append(copy.deepcopy(tile[0]))
        for offset in range(0, 4096, panel_k):
            length = min(panel_k, 4096 - offset)
            a = copy.deepcopy(first_a)
            b = copy.deepcopy(first_b)
            mma = copy.deepcopy(first_mma)
            a["global"]["base"] += offset
            a["global"]["cols"] = length
            a["local"].update(base=32, cols=length, row_stride=length)
            b["global"]["base"] += offset * b["global"]["row_stride"]
            b["global"]["rows"] = length
            b["local"].update(base=32 + panel_k, rows=length)
            mma.update(a=32, b=32 + panel_k, k=length)
            output.extend((
                {"command": "async", "token": token, "instruction": a},
                {"command": "async", "token": token + 1, "instruction": b},
                {"command": "wait", "tokens": [token, token + 1]},
                {"command": "run", "instruction": mma},
            ))
            token += 2
        tail_a, tail_b, _, tail_mma = tail
        a = copy.deepcopy(tail_a["instruction"])
        b = copy.deepcopy(tail_b["instruction"])
        mma = copy.deepcopy(tail_mma["instruction"])
        a["local"].update(base=32, cols=1, row_stride=1)
        b["local"].update(base=32 + panel_k, rows=1)
        mma.update(a=32, b=32 + panel_k)
        output.extend((
            {"command": "async", "token": token, "instruction": a},
            {"command": "async", "token": token + 1, "instruction": b},
            {"command": "wait", "tokens": [token, token + 1]},
            {"command": "run", "instruction": mma},
            copy.deepcopy(tile[-1]),
        ))
        token += 2
    words = 32 + panel_k + panel_k * 32
    return dict(group, rf_kib=math.ceil(words / 256), commands=output), len(tiles)
