"""Necessary, program-free capacity checks from the official GEMM generator.

These constraints reject designs that the generator cannot export. Passing
them does not establish a cycle estimate, numerical correctness, or power.
"""

from .hardware import validate


def _gemm_shapes(config):
    shape = config["shape"]
    d, f, heads = shape["d"], shape["f"], shape["heads"]
    if d % heads:
        raise ValueError("head width must divide d")
    per_sample = 1 if config["decode"] else shape["prefill"]
    rows = config["batch"] * per_sample
    yield "qkv", rows, 3 * d, d
    yield "out", rows, d, d
    yield "up", rows, f, d
    yield "down", rows, d, f
    for step in range(shape["steps"] if config["decode"] else 1):
        context = (shape["history"] + step if config["decode"] else 0) + per_sample
        yield "qk", per_sample, context, d // heads
        yield "av", per_sample, d // heads, context


def validate_generator_config(config):
    """Check exact tile, SH panel, and RF limits before exporting JSONL."""
    hardware = config["hardware"]
    validate(hardware)
    policy = config["policy"]
    m, n, k = (policy[key] for key in ("m", "n", "k"))
    if any(type(value) is not int for value in (m, n, k)) or not (
            1 <= m <= 64 and 1 <= n <= 64 and 1 <= k <= 256):
        raise ValueError("policy requires M,N in 1..64 and K in 1..256")
    sh_rows = policy.get("sh_rows", 0)
    if type(sh_rows) is not int or not 0 <= sh_rows <= 8:
        raise ValueError("sh_rows must be 0..8")
    if policy.get("split_k", 1) not in (1, 2, 4, 8):
        raise ValueError("split_k must be 1/2/4/8")
    head_group = policy.get("head_group", 1)
    if type(head_group) is not int or not 1 <= head_group <= 32:
        raise ValueError("head_group must be 1..32")
    if not 1 <= config.get("parallel_groups", 1) <= hardware["resident_groups"]:
        raise ValueError("parallel_groups exceeds residency")
    if not hardware["tc_count"]:
        raise ValueError("GEMM requires a TC")
    rf_words = hardware["rf_kib"] * 256
    sh_words = hardware["sh_kib"] * 256
    for stage, rows, width, _ in _gemm_shapes(config):
        if rows < 1 or width < 1:
            raise ValueError(f"{stage} has empty GEMM dimensions")
        if sh_rows and rows > 1:
            if policy.get("sh_direct", False):
                if not hardware["sh_tc_bw"]:
                    raise ValueError(f"{stage} direct SH GEMM requires SH-TC bandwidth")
                if k * n > sh_words:
                    raise ValueError(f"{stage} shared panel exceeds SH capacity")
                if sh_rows * m * n + m * k > rf_words:
                    raise ValueError(f"{stage} persistent shared GEMM exceeds RF capacity")
            else:
                if k * n + sh_rows * m * n > sh_words:
                    raise ValueError(f"{stage} shared GEMM exceeds SH capacity")
                if m * n + m * k + k * n > rf_words:
                    raise ValueError(f"{stage} shared GEMM staging exceeds RF capacity")
        else:
            tile_m, tile_n = min(rows, m), min(width, n)
            if tile_m * tile_n + tile_m * k + k * tile_n > rf_words:
                raise ValueError(f"{stage} GEMM tile working set exceeds RF capacity")
