"""Share a GEMM B panel across adjacent independent tiles of one workgroup."""

import argparse
import copy
import json
from pathlib import Path

from .estimate import program_records, validate_wave_capacity
from .reuse_b import _tile


def _tiles(group):
    commands = group["commands"]
    if not commands:
        return None
    tiles = []
    start = 0
    for index, command in enumerate(commands):
        if command.get("instruction", {}).get("op") != "store":
            continue
        segment = commands[start:index + 1]
        tile = _tile(dict(group, commands=segment))
        if tile is None:
            return None
        tiles.append((segment, tile))
        start = index + 1
    return tiles if start == len(commands) else None


def _independent(first, second):
    if first["signature"] != second["signature"]:
        return False
    return all(left_end < right_start or right_end < left_start
               for left_start, left_end in first["footprint"]
               for right_start, right_end in second["footprint"])


def _renumber(commands):
    seen = {}
    next_token = 0
    for command in commands:
        if command["command"] == "async":
            next_token += 1
            old_token = command["token"]
            seen[old_token] = next_token
            command["token"] = next_token
        elif command["command"] == "wait":
            command["tokens"] = [seen[token] for token in command["tokens"]]
    return commands


def _combined(group, tiles):
    reservation = group["rf_kib"] * 256
    size = tiles[0]["fill"]["len"]
    addresses = [0] + [reservation + index * size for index in range(len(tiles) - 1)]
    commands = [{"command": "run", "instruction": dict(tile["fill"], dst=address)}
                for tile, address in zip(tiles, addresses)]
    token = 0
    for chunks in zip(*(tile["chunks"] for tile in tiles)):
        token += 1
        commands.append({"command": "async", "instruction": copy.deepcopy(chunks[0][1]),
                         "token": token})
        panel_token = token
        for tile_index, ((activation, _, operation), address) in enumerate(
                zip(chunks, addresses)):
            token += 1
            commands.append({"command": "async", "instruction": copy.deepcopy(activation),
                             "token": token})
            commands.append({"command": "wait", "tokens":
                             [panel_token, token] if tile_index == 0 else [token]})
            commands.append({"command": "run",
                             "instruction": dict(operation, c=address)})
    for tile, address in zip(tiles, addresses):
        store = copy.deepcopy(tile["store"])
        store["local"]["base"] = address
        commands.append({"command": "run", "instruction": store})
    required_words = reservation + (len(tiles) - 1) * size
    return {"sm": group["sm"], "rf_kib": (required_words + 255) // 256,
            "sh_kib": group["sh_kib"], "commands": commands}


def _group(group, max_fanout=2):
    if not 2 <= max_fanout <= 8:
        raise ValueError("reuse fanout must be 2..8")
    tiles = _tiles(group)
    if tiles is None or len(tiles) < 2:
        return group, 0, 0
    commands = []
    maximum_rf = group["rf_kib"]
    pairs = removed_loads = 0
    index = 0
    while index < len(tiles):
        original, first = tiles[index]
        selected = [first]
        for _, candidate in tiles[index + 1:index + max_fanout]:
            if (candidate["signature"] != first["signature"] or
                    not all(_independent(existing, candidate) for existing in selected)):
                break
            selected.append(candidate)
        if len(selected) > 1:
            combined = _combined(group, selected)
            commands.extend(combined["commands"])
            maximum_rf = max(maximum_rf, combined["rf_kib"])
            pairs += len(selected) - 1
            removed_loads += (len(selected) - 1) * len(first["chunks"])
            index += len(selected)
            continue
        commands.extend(original)
        index += 1
    if not pairs:
        return group, 0, 0
    return dict(group, rf_kib=maximum_rf,
                commands=_renumber(copy.deepcopy(commands))), pairs, removed_loads


def reuse_b_within_program(source, destination, max_fanout=2):
    records = program_records(source)
    header = next(records)
    stats = {"max_fanout": max_fanout, "waves": 0, "paired_tiles": 0,
             "removed_b_loads": 0,
             "rejected_by_rf_capacity": 0}
    with Path(destination).open("x") as writer:
        writer.write(json.dumps(header, separators=(",", ":")) + "\n")
        for record in records:
            if record.get("record") == "wave":
                stats["waves"] += 1
                selected = list(record["groups"])
                for index, group in enumerate(record["groups"]):
                    for fanout in range(max_fanout, 1, -1):
                        changed, pairs, loads = _group(group, fanout)
                        if not pairs:
                            continue
                        selected[index] = changed
                        try:
                            validate_wave_capacity(selected, header["hardware"])
                        except ValueError:
                            selected[index] = group
                            if fanout == 2:
                                stats["rejected_by_rf_capacity"] += pairs
                        else:
                            stats["paired_tiles"] += pairs
                            stats["removed_b_loads"] += loads
                            break
                record = dict(record, groups=selected)
            writer.write(json.dumps(record, separators=(",", ":")) + "\n")
    if not stats["paired_tiles"]:
        raise ValueError("no capacity-feasible adjacent GEMM tiles share B panels")
    return stats


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("--max-fanout", type=int, default=2)
    args = parser.parse_args()
    print(json.dumps(reuse_b_within_program(args.source, args.destination,
                                            args.max_fanout), indent=2))


if __name__ == "__main__":
    main()
