"""Price ragged AV score DMA plus RF zeros in place of global causal masks.

Scratch starts as NaN and the executor rejects uninitialized HBM reads.  A
rectangular AV score load therefore cannot read above the causal diagonal.
For a diagonal tile, issue one DMA per initialized row prefix, then fill the
remaining RF suffix after all loads complete.  The later global zero-mask
waves can then be removed.  No candidate JSONL is exported.
"""

import argparse
import copy
import json
from pathlib import Path

from .estimate import estimate_wave, program_records, validate_wave_capacity
from .hardware import validate
from .tool import sha, write


def _mask_wave(groups, score_ids, context):
    if not groups:
        return False
    for group in groups:
        commands = group["commands"]
        if not commands or len(commands) % 2:
            return False
        for fill_command, store_command in zip(commands[::2], commands[1::2]):
            fill = fill_command.get("instruction", {})
            store = store_command.get("instruction", {})
            if (fill_command["command"] != "run" or
                    store_command["command"] != "run" or
                    fill.get("op") != "fill" or fill.get("value") != 0 or
                    store.get("op") != "store" or
                    store["tensor"] not in score_ids):
                return False
            view = store["global"]
            row, column = divmod(view["base"], context)
            if (view["rows"] != 1 or view["col_stride"] != 1 or
                    column <= row or column + view["cols"] > context or
                    fill["dst"] != store["local"]["base"] or
                    fill["len"] != view["cols"]):
                return False
    return True


def _fill_invalid(instruction, context):
    view = instruction["global"]
    local = instruction["local"]
    if (view["row_stride"] != context or view["col_stride"] != 1 or
            local["rows"] != view["rows"] or
            local["cols"] != view["cols"] or local["col_stride"] != 1 or
            local["row_stride"] < local["cols"]):
        raise ValueError("unsupported causal AV score load layout")
    row_start, col_start = divmod(view["base"], context)
    if col_start + view["cols"] > context:
        raise ValueError("causal AV score load crosses a score row")
    fills = []
    for offset in range(view["rows"]):
        invalid_start = max(0, row_start + offset + 1 - col_start)
        if invalid_start >= view["cols"]:
            continue
        fills.append({"command": "run", "instruction": {
            "op": "fill",
            "dst": local["base"] + offset * local["row_stride"] + invalid_start,
            "len": view["cols"] - invalid_start, "value": 0.0}})
    return fills


def _localize_group(group, score_ids, context, max_live_tokens=6):
    # Row softmax also loads the score tensor, but only over valid prefixes.
    # The RF fill belongs specifically to the subsequent AV MMA group.
    if not any(command.get("instruction", {}).get("op") == "mma"
               for command in group["commands"]):
        return group, 0
    pending = {}
    commands = []
    inserted = 0
    live_tokens = set()
    next_token = 1 + max((command["token"] for command in group["commands"]
                          if command["command"] == "async"), default=0)
    for command in group["commands"]:
        instruction = command.get("instruction", {})
        if instruction.get("op") == "load" and instruction["tensor"] in score_ids:
            fills = _fill_invalid(instruction, context)
            if not fills:
                commands.append(command)
                if command["command"] == "async":
                    live_tokens.add(command["token"])
                    if len(live_tokens) > max_live_tokens:
                        raise ValueError("existing group exceeds live DMA token cap")
                continue
            view = instruction["global"]
            local = instruction["local"]
            row_start, col_start = divmod(view["base"], context)
            replacement = []
            wait_tokens = []
            for offset in range(view["rows"]):
                valid = min(view["cols"], max(0, row_start + offset + 1 - col_start))
                if not valid:
                    continue
                selected = copy.deepcopy(command)
                selected["instruction"]["global"] = {
                    "base": view["base"] + offset * context,
                    "rows": 1, "cols": valid,
                    "row_stride": valid, "col_stride": 1}
                selected["instruction"]["local"] = {
                    "base": local["base"] + offset * local["row_stride"],
                    "rows": 1, "cols": valid,
                    "row_stride": valid, "col_stride": 1}
                if command["command"] == "async":
                    token = command["token"] if not wait_tokens else next_token
                    if wait_tokens:
                        next_token += 1
                    selected["token"] = token
                    wait_tokens.append(token)
                replacement.append(selected)
            if command["command"] == "async":
                batch_capacity = max_live_tokens - len(live_tokens)
                if batch_capacity < 1:
                    raise ValueError("no async DMA token slot for ragged score load")
                for offset in range(0, len(replacement), batch_capacity):
                    batch = replacement[offset:offset + batch_capacity]
                    commands.extend(batch)
                    commands.append({"command": "wait",
                                     "tokens": [item["token"] for item in batch]})
                # The source token has already been waited on.  Keep the RF
                # suffix fills at the original wait after any value DMA.
                pending[command["token"]] = ([], fills)
            elif command["command"] == "run":
                commands.extend(replacement)
                commands.extend(fills)
                inserted += len(fills)
            else:
                raise ValueError("unsupported score load command")
        elif command["command"] == "wait":
            tokens = []
            after_wait = []
            for token in command["tokens"]:
                if token in pending:
                    expanded, fills = pending.pop(token)
                    tokens.extend(expanded)
                    after_wait.extend(fills)
                else:
                    tokens.append(token)
            if tokens:
                commands.append(dict(command, tokens=tokens))
                live_tokens.difference_update(tokens)
            commands.extend(after_wait)
            inserted += len(after_wait)
        else:
            commands.append(command)
            if command["command"] == "async":
                live_tokens.add(command["token"])
                if len(live_tokens) > max_live_tokens:
                    raise ValueError("existing group exceeds live DMA token cap")
    if pending:
        raise ValueError("score DMA has no matching wait")
    return dict(group, commands=commands), inserted


def screen(source, hardware, base_cycles, output=None):
    source = Path(source)
    validate(hardware)
    records = program_records(source)
    header = next(records)
    if header["decode"] or header["batch"] != 1:
        raise ValueError("causal mask localization supports batch-one prefill")
    shape = header["shape"]
    context = shape["prefill"]
    active = []
    pending_score_run = []
    masked_scores = set()
    cache = {}
    stats = {"waves": 0, "mask_waves_removed": 0, "mask_commands_removed": 0,
             "av_waves_changed": 0, "rf_fills_inserted": 0,
             "extra_ragged_dma_loads": 0,
             "candidate_total_commands": 0,
             "max_candidate_wave_commands": 0,
             "max_candidate_wave_access_intervals": 0,
             "original_affected_cycles": 0, "replacement_affected_cycles": 0,
             "score_allocations": 0}

    def finish_score_run():
        if len(pending_score_run) == shape["heads"]:
            for index in pending_score_run:
                active[index] = True
            stats["score_allocations"] += len(pending_score_run)
        pending_score_run.clear()

    def admit(groups):
        commands = sum(len(group["commands"]) for group in groups)
        intervals = sum(command["instruction"]["global"]["rows"]
                        for group in groups for command in group["commands"]
                        if command.get("instruction", {}).get("op") in
                        ("load", "store", "load_shared", "store_shared"))
        # Compact counts distinct access intervals after coalescing, so the
        # raw interval count below is diagnostic only.
        if commands > 2_097_152:
            raise ValueError("ragged candidate exceeds compact wave command admission")
        stats["candidate_total_commands"] += commands
        stats["max_candidate_wave_commands"] = max(
            stats["max_candidate_wave_commands"], commands)
        stats["max_candidate_wave_access_intervals"] = max(
            stats["max_candidate_wave_access_intervals"], intervals)

    for record in records:
        kind = record["record"]
        if kind in ("input", "alloc"):
            score_sized = kind == "alloc" and record["len"] == context * context
            if not score_sized:
                finish_score_run()
            active.append(False)
            if score_sized:
                pending_score_run.append(len(active) - 1)
            continue
        finish_score_run()
        if kind == "release":
            if record["tensor"] != len(active) - 1:
                raise ValueError("tensor release stack changed")
            masked_scores.discard(record["tensor"])
            active.pop()
            continue
        if kind != "wave":
            continue
        stats["waves"] += 1
        score_ids = {index for index, score in enumerate(active) if score}
        groups = record["groups"]
        if _mask_wave(groups, score_ids, context):
            masked_scores.update(
                command["instruction"]["tensor"]
                for group in groups for command in group["commands"]
                if command["instruction"]["op"] == "store")
            stats["mask_waves_removed"] += 1
            stats["mask_commands_removed"] += sum(len(g["commands"]) for g in groups)
            stats["original_affected_cycles"] += estimate_wave(groups, hardware, cache)
            continue
        candidate = []
        count = 0
        for group in groups:
            if (any(command.get("instruction", {}).get("op") == "load" and
                    command["instruction"]["tensor"] in masked_scores
                    for command in group["commands"]) and
                    not any(command.get("instruction", {}).get("op") == "mma"
                            for command in group["commands"])):
                raise ValueError("masked score has an unsupported later consumer")
            changed, inserted = _localize_group(
                group, score_ids, context,
                hardware["dma_engines"] * (1 + hardware["dma_depth"]))
            candidate.append(changed)
            count += inserted
            stats["extra_ragged_dma_loads"] += (
                sum(command.get("instruction", {}).get("op") == "load"
                    for command in changed["commands"]) -
                sum(command.get("instruction", {}).get("op") == "load"
                    for command in group["commands"]))
        if count:
            validate_wave_capacity(candidate, hardware)
            stats["av_waves_changed"] += 1
            stats["rf_fills_inserted"] += count
            stats["original_affected_cycles"] += estimate_wave(groups, hardware, cache)
            stats["replacement_affected_cycles"] += estimate_wave(candidate, hardware, cache)
        admit(candidate)
    if stats["score_allocations"] != shape["layers"] * shape["heads"]:
        raise ValueError(f"score tensor detection was ambiguous: {stats['score_allocations']} allocations")
    if not stats["mask_waves_removed"] or not stats["av_waves_changed"]:
        raise ValueError("causal mask or AV waves were not found")
    if stats["candidate_total_commands"] > 50_000_000:
        raise ValueError("ragged candidate exceeds compact scenario command budget")
    result = {"scope": "ragged initialized score loads and AV RF causal zeros",
              "source_sha256": sha(source),
              "estimator_sha256": sha(Path(__file__).with_name("estimate.py")),
              "model_sha256": sha(Path(__file__)),
              "hardware": hardware, "base_cycles": base_cycles, **stats,
              "predicted_cycles": (base_cycles - stats["original_affected_cycles"] +
                                   stats["replacement_affected_cycles"]),
              "candidate_program_generated": False,
              "numerical_correctness": "not_checked", "official_score": None}
    if output is not None:
        Path(output).parent.mkdir(parents=True, exist_ok=True)
        write(output, result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("hardware", type=Path)
    parser.add_argument("base_cycles", type=int)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    document = json.loads(args.hardware.read_text())
    hardware = document.get("hardware", document)
    result = screen(args.source, hardware, args.base_cycles, args.output)
    print(json.dumps({key: result[key] for key in (
        "mask_waves_removed", "rf_fills_inserted", "predicted_cycles")}, indent=2))


if __name__ == "__main__":
    main()
