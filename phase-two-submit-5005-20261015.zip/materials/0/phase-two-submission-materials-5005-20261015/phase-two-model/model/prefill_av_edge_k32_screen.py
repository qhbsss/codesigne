"""Screen 32 KiB AV panels for causal prefill without creating a program.

The original 32-row causal AV tile always reserves K128, although its row
prefixes may span only 1..32, 33..64, 65..96, or 97..128 entries.  K32/K64
panels preserve the loaded score and V addresses and ascending-K accumulation.
Every AV tile of a group is rewritten so that its reservation really falls
from 56 to 32 KiB; independent adjacent waves may then share a barrier.
"""

import argparse
import copy
import json
import math
from pathlib import Path

from .estimate import estimate_wave, program_records, validate_wave_capacity
from .resident4_pack_materialize import _cross_sm_safe
from .resident4_pack_screen import _access_footprint
from .resident4_window_screen import independent
from .tool import SCORE_CASES, sha, write


def _view_end(view):
    return (view["base"] + (view["rows"] - 1) * view["row_stride"] +
            (view["cols"] - 1) * view["col_stride"] + 1)


def _rf_end(instruction):
    op = instruction["op"]
    if op == "fill":
        return instruction["dst"] + instruction["len"]
    if op in ("load", "store"):
        return _view_end(instruction["local"])
    if op == "mma":
        return max(instruction["a"] + instruction["m"] * instruction["k"],
                   instruction["b"] + instruction["k"] * instruction["n"],
                   instruction["c"] + instruction["m"] * instruction["n"])
    raise ValueError(f"unrecognized causal AV instruction {op}")


def _edge(segment, context, next_token):
    if (len(segment) < 4 or segment[0]["command"] != "run" or
            segment[0]["instruction"] !=
            {"op": "fill", "dst": 0, "len": 2048, "value": 0.0} or
            segment[-1]["command"] != "run" or
            segment[-1]["instruction"].get("op") != "store"):
        return None
    store = segment[-1]["instruction"]
    gv, lv = store["global"], store["local"]
    if (gv["rows"] != 32 or gv["cols"] != 64 or
            lv != {"base": 0, "rows": 32, "cols": 64,
                   "row_stride": 64, "col_stride": 1}):
        return None
    mma_indices = [index for index, command in enumerate(segment[:-1])
                   if command.get("instruction", {}).get("op") == "mma"]
    if not mma_indices or mma_indices[-1] != len(segment) - 2:
        return None
    edge_start = mma_indices[-2] + 1 if len(mma_indices) > 1 else 1
    edge = segment[edge_start:-1]
    mma = edge[-1]["instruction"]
    if (edge[-1]["command"] != "run" or
            mma != {"op": "mma", "a": 2048, "b": 6144, "c": 0,
                    "m": 32, "n": 64, "k": 128}):
        return None
    score_loads = {}
    value_loads = {}
    fills = {}
    issued = set()
    waited = set()
    for command in edge[:-1]:
        form = command["command"]
        if form == "wait":
            tokens = command["tokens"]
            if not tokens or any(token not in issued or token in waited
                                 for token in tokens):
                return None
            waited.update(tokens)
            continue
        instruction = command["instruction"]
        op = instruction["op"]
        if op == "load" and form == "async":
            token = command["token"]
            if token in issued:
                return None
            issued.add(token)
            local = instruction["local"]
            if local["base"] in (6144, 10240):
                if local["base"] in value_loads:
                    return None
                value_loads[local["base"]] = command
            else:
                row, offset = divmod(local["base"] - 2048, 128)
                if not 0 <= row < 32 or offset or row in score_loads:
                    return None
                score_loads[row] = command
        elif op == "fill" and form == "run":
            row, offset = divmod(instruction["dst"] - 2048, 128)
            if not 0 <= row < 32 or row in fills or not 0 <= offset < 128:
                return None
            fills[row] = command
        else:
            return None
    if (issued != waited or len(score_loads) != 32 or
            set(value_loads) != {6144, 10240}):
        return None
    query_start = gv["base"] // gv["row_stride"]
    score_tensor = score_loads[0]["instruction"]["tensor"]
    value_tensor = value_loads[6144]["instruction"]["tensor"]
    first_valid = score_loads[0]["instruction"]["global"]["cols"]
    if first_valid not in (1, 33, 65, 97):
        return None
    score_col_start = query_start - first_valid + 1
    if score_col_start < 0 or score_col_start % 128:
        return None
    for row in range(32):
        score = score_loads[row]["instruction"]
        view, local = score["global"], score["local"]
        fill = fills.get(row, {}).get("instruction")
        valid = first_valid + row
        if (score["tensor"] != score_tensor or
                view != {"base": (query_start + row) * context + score_col_start,
                         "rows": 1, "cols": valid,
                         "row_stride": valid, "col_stride": 1} or
                local != {"base": 2048 + row * 128, "rows": 1,
                          "cols": valid, "row_stride": valid, "col_stride": 1} or
                fill != ({"op": "fill", "dst": 2048 + row * 128 + valid,
                          "len": 128 - valid, "value": 0.0}
                         if valid < 128 else None)):
            return None
    low = value_loads[6144]["instruction"]
    high = value_loads[10240]["instruction"]
    if (low["tensor"] != value_tensor or high["tensor"] != value_tensor or
            low["global"]["rows"] != 64 or low["global"]["cols"] != 64 or
            low["global"]["col_stride"] != 1 or
            high["global"] != dict(low["global"],
                                   base=low["global"]["base"] +
                                   64 * low["global"]["row_stride"]) or
            low["local"] != {"base": 6144, "rows": 64, "cols": 64,
                             "row_stride": 64, "col_stride": 1} or
            high["local"] != {"base": 10240, "rows": 64, "cols": 64,
                              "row_stride": 64, "col_stride": 1}):
        return None

    def mma_command(k):
        return {"command": "run", "instruction":
                {"op": "mma", "a": 2048, "b": 4096, "c": 0,
                 "m": 32, "n": 64, "k": k}}

    rewritten = []
    if first_valid <= 33:
        k = 32 if first_valid == 1 else 64
        removed_token = value_loads[10240]["token"]
        for command in edge[:-1]:
            if command["command"] == "wait":
                remaining = [token for token in command["tokens"]
                             if token != removed_token]
                if remaining:
                    rewritten.append(dict(command, tokens=remaining))
                continue
            instruction = command["instruction"]
            if instruction["op"] == "load":
                base = instruction["local"]["base"]
                if base == 10240:
                    continue
                selected = copy.deepcopy(command)
                item = selected["instruction"]
                if base == 6144:
                    item["global"] = dict(item["global"], rows=k)
                    item["local"] = {"base": 4096, "rows": k, "cols": 64,
                                     "row_stride": 64, "col_stride": 1}
                else:
                    row = (base - 2048) // 128
                    item["local"] = dict(item["local"], base=2048 + row * k)
                rewritten.append(selected)
            else:
                row = (instruction["dst"] - 2048) // 128
                valid = first_valid + row
                if valid < k:
                    rewritten.append({"command": "run", "instruction": {
                        "op": "fill", "dst": 2048 + row * k + valid,
                        "len": k - valid, "value": 0.0}})
        rewritten.append(mma_command(k))
    else:
        # The first 64 score columns are valid in every row.  One rectangular
        # DMA replaces their 32 row loads, then a second K32/K64 panel covers
        # the remaining causal prefix without keeping either panel resident.
        k2 = 32 if first_valid == 65 else 64
        first_score = copy.deepcopy(score_loads[0])
        first_score["instruction"]["global"] = {
            "base": score_loads[0]["instruction"]["global"]["base"],
            "rows": 32, "cols": 64, "row_stride": context, "col_stride": 1}
        first_score["instruction"]["local"] = {
            "base": 2048, "rows": 32, "cols": 64,
            "row_stride": 64, "col_stride": 1}
        first_value = copy.deepcopy(value_loads[6144])
        first_value["instruction"]["local"] = {
            "base": 4096, "rows": 64, "cols": 64,
            "row_stride": 64, "col_stride": 1}
        rewritten.extend((first_score, first_value,
                          {"command": "wait", "tokens":
                           [first_score["token"], first_value["token"]]},
                          mma_command(64)))

        second_score_tokens = ([score_loads[row]["token"] for row in range(1, 32)] +
                               [value_loads[10240]["token"]])
        pending = []
        for row, token in enumerate(second_score_tokens):
            selected = copy.deepcopy(score_loads[row])
            selected["token"] = token
            item = selected["instruction"]
            remaining = first_valid + row - 64
            item["global"] = dict(item["global"],
                                  base=item["global"]["base"] + 64,
                                  cols=remaining, row_stride=remaining)
            item["local"] = {"base": 2048 + row * k2,
                             "rows": 1, "cols": remaining,
                             "row_stride": remaining, "col_stride": 1}
            rewritten.append(selected)
            pending.append(token)
            if len(pending) == 6 or row == 31:
                rewritten.append({"command": "wait", "tokens": pending})
                pending = []
        second_value = copy.deepcopy(value_loads[10240])
        second_value["token"] = next_token
        second_value["instruction"]["global"] = dict(
            second_value["instruction"]["global"], rows=k2)
        second_value["instruction"]["local"] = {
            "base": 4096, "rows": k2, "cols": 64,
            "row_stride": 64, "col_stride": 1}
        rewritten.extend((second_value,
                          {"command": "wait", "tokens": [next_token]}))
        next_token += 1
        for row in range(32):
            remaining = first_valid + row - 64
            if remaining < k2:
                rewritten.append({"command": "run", "instruction": {
                    "op": "fill", "dst": 2048 + row * k2 + remaining,
                    "len": k2 - remaining, "value": 0.0}})
        rewritten.append(mma_command(k2))
    return segment[:edge_start] + rewritten + segment[-1:], next_token


def retile_group(group, context):
    if group["rf_kib"] != 56 or group["sh_kib"]:
        return None, 0
    commands = []
    segment = []
    edges = 0
    next_token = 1 + max((command["token"] for command in group["commands"]
                          if "token" in command), default=0)
    for command in group["commands"]:
        segment.append(command)
        if command.get("instruction", {}).get("op") == "store":
            changed = _edge(segment, context, next_token)
            if changed is None:
                return None, 0
            rewritten, next_token = changed
            commands.extend(rewritten)
            edges += 1
            segment = []
    if segment or not edges:
        return None, 0
    if any(_rf_end(command["instruction"]) > 8192
           for command in commands if command["command"] != "wait"):
        return None, 0
    return dict(group, rf_kib=32, commands=commands), edges


def retile_wave(record, hardware, context):
    groups = record["groups"]
    if len(groups) != 8 or {group["sm"] for group in groups} != set(range(8)):
        return None, 0
    changed = []
    edges = 0
    for group in groups:
        new, count = retile_group(group, context)
        if new is None:
            return None, 0
        changed.append(new)
        edges += count
    validate_wave_capacity(changed, hardware)
    return changed, edges


def _select(waves, singles, pairs):
    best = [0] * (waves + 2)
    action = [None] * waves
    for index in range(waves - 1, -1, -1):
        best[index] = best[index + 1]
        single = singles.get(index)
        if single and single["base"] - single["cycles"] + best[index + 1] > best[index]:
            best[index] = single["base"] - single["cycles"] + best[index + 1]
            action[index] = single
        pair = pairs.get(index)
        if pair and pair["base"] - pair["cycles"] + best[index + 2] > best[index]:
            best[index] = pair["base"] - pair["cycles"] + best[index + 2]
            action[index] = pair
    chosen = []
    index = 0
    while index < waves:
        row = action[index]
        if row:
            chosen.append(row)
            index += row["source_waves"]
        else:
            index += 1
    return chosen, best[0]


def screen(source, manifest_path, case, output):
    source, manifest_path, output = map(Path, (source, manifest_path, output))
    manifest = json.loads(manifest_path.read_text())
    if case not in ("w-p", "a-p") or sha(source) != manifest["program_sha256"][case]:
        raise ValueError("case or source SHA differs from five-case manifest")
    records = program_records(source)
    header = next(records)
    hardware = manifest["hardware"]
    if header["hardware"] != hardware:
        raise ValueError("hardware differs from five-case manifest")
    context = header["shape"]["prefill"]
    cache = {}
    singles = {}
    pairs = {}
    previous = None
    waves = eligible = edges = independent_pairs = 0
    for record in records:
        if record["record"] != "wave":
            previous = None
            continue
        changed, count = retile_wave(record, hardware, context)
        if changed is not None:
            eligible += 1
            edges += count
            old = estimate_wave(record["groups"], hardware, cache)
            new = estimate_wave(changed, hardware, cache)
            singles[waves] = {"source_start": waves, "source_waves": 1,
                              "output_waves": 1, "edges": count,
                              "base": old, "cycles": new}
            if previous is not None:
                prior_index, prior_record, prior_changed, prior_old, prior_edges = previous
                entries = [(prior_record, prior_old, _access_footprint(prior_record), prior_index),
                           (record, old, _access_footprint(record), waves)]
                merged = prior_changed + changed
                if (prior_index + 1 == waves and independent(entries) and
                        _cross_sm_safe(merged)):
                    validate_wave_capacity(merged, hardware)
                    cost = estimate_wave(merged, hardware, cache)
                    independent_pairs += 1
                    pairs[prior_index] = {"source_start": prior_index,
                                          "source_waves": 2, "output_waves": 1,
                                          "edges": prior_edges + count,
                                          "base": prior_old + old,
                                          "cycles": cost}
            previous = (waves, record, changed, old, count)
            if eligible % 4 == 0:
                print(case, "eligible", eligible, "edges", edges,
                      "pair_options", independent_pairs, flush=True)
        else:
            previous = None
        waves += 1
    chosen, saved = _select(waves, singles, pairs)
    cycles = dict(manifest["model_cycles"])
    cycles[case] -= saved
    score = 1000 * math.exp(sum(weight * math.log(reference / cycles[name])
                                for name, (reference, weight) in SCORE_CASES.items()))
    result = {"case": case, "source_sha256": sha(source),
              "manifest_sha256": sha(manifest_path), "model_sha256": sha(Path(__file__)),
              "source_waves": waves, "eligible_waves": eligible,
              "eligible_edges": edges, "independent_pair_options": independent_pairs,
              "selected_source_waves": sum(row["source_waves"] for row in chosen),
              "selected_edges": sum(row["edges"] for row in chosen),
              "merged_wave_pairs": sum(row["source_waves"] == 2 for row in chosen),
              "base_cycles": manifest["model_cycles"][case],
              "selected_cycles": cycles[case], "cycle_delta": -saved,
              "choices": chosen, "five_case_model_cycles": cycles,
              "five_case_model_score": score, "meets_grade_gate": score >= 5000,
              "candidate_program_generated": False, "official_score": None}
    output.parent.mkdir(parents=True, exist_ok=True)
    write(output, result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("manifest", type=Path)
    parser.add_argument("case", choices=("w-p", "a-p"))
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    result = screen(args.source, args.manifest, args.case, args.output)
    print(json.dumps({key: result[key] for key in
                      ("case", "eligible_waves", "eligible_edges", "merged_wave_pairs",
                       "cycle_delta", "five_case_model_score")}, indent=2), flush=True)


if __name__ == "__main__":
    main()
