"""Screen one-K GEMM activation-panel reuse without writing candidate JSONL.

Independent output tiles with the same A panel may run consecutively while
keeping that panel in RF. The accumulator address is reused after each store.
"""

import argparse
import copy
import json
from collections import defaultdict
from pathlib import Path

from .estimate import estimate_wave, program_records, validate_wave_capacity
from .hardware import validate
from .inplace_panel_reuse import _logical_tiles
from .tool import sha, write


def _key(tile):
    activation, _, mma = tile["chunks"][0]
    return (activation["tensor"], tuple(sorted(activation["global"].items())),
            mma["m"], mma["n"], mma["k"], mma["a"])


def _batch(tiles):
    commands = []
    activation = tiles[0]["chunks"][0][0]
    token = 0
    for index, tile in enumerate(tiles):
        other_activation, panel, mma = tile["chunks"][0]
        if other_activation != activation:
            raise ValueError("activation batch changed A load")
        commands.append({"command": "run", "instruction": copy.deepcopy(tile["fill"])})
        if index == 0:
            token += 1
            activation_token = token
            commands.append({"command": "async", "token": token,
                             "instruction": copy.deepcopy(activation)})
        token += 1
        commands.append({"command": "async", "token": token,
                         "instruction": copy.deepcopy(panel)})
        commands.append({"command": "wait", "tokens":
                         [activation_token, token] if index == 0 else [token]})
        commands.append({"command": "run", "instruction": copy.deepcopy(mma)})
        commands.append({"command": "run", "instruction": copy.deepcopy(tile["store"])})
    return commands


def _disjoint_outputs(tiles):
    intervals = defaultdict(list)
    for tile in tiles:
        intervals[tile["store"]["tensor"]].extend(tile["footprint"])
    for addresses in intervals.values():
        addresses.sort()
        if any(left[1] >= right[0]
               for left, right in zip(addresses, addresses[1:])):
            return False
    return True


def reuse_group(group, max_fanout=64):
    if max_fanout < 2:
        raise ValueError("max_fanout must be at least two")
    tiles = _logical_tiles(group)
    if tiles is None or len(tiles) < 2:
        return group, 0
    outputs = {tile["store"]["tensor"] for tile in tiles}
    inputs = {load["tensor"] for tile in tiles for load in tile["chunks"][0][:2]}
    if outputs & inputs or not _disjoint_outputs(tiles):
        return group, 0
    buckets = defaultdict(list)
    order = []
    for tile in tiles:
        key = _key(tile)
        if key not in buckets:
            order.append(key)
        buckets[key].append(tile)
    removed = sum(len(bucket) - (len(bucket) + max_fanout - 1) // max_fanout
                  for bucket in buckets.values())
    if not removed:
        return group, 0
    commands = []
    for key in order:
        bucket = buckets[key]
        for offset in range(0, len(bucket), max_fanout):
            commands.extend(_batch(bucket[offset:offset + max_fanout]))
    return dict(group, commands=commands), removed


def screen(source, hardware, base_cycles, max_fanout=64, output=None):
    validate(hardware)
    records = program_records(source)
    next(records)
    cache = {}
    result = {"scope": "one-K independent GEMM activation-panel reuse",
              "source_sha256": sha(source),
              "estimator_sha256": sha(Path(__file__).with_name("estimate.py")),
              "model_sha256": sha(Path(__file__)),
              "hardware": hardware, "base_cycles": base_cycles,
              "max_fanout": max_fanout, "waves": 0, "changed_waves": 0,
              "accepted_waves": [], "removed_a_loads": 0,
              "saved_cycles": 0, "candidate_program_generated": False,
              "numerical_correctness": "not_checked", "official_score": None}
    for record in records:
        if record["record"] != "wave":
            continue
        wave_index = result["waves"]
        result["waves"] += 1
        groups = []
        removed = 0
        for group in record["groups"]:
            transformed, count = reuse_group(group, max_fanout)
            groups.append(transformed)
            removed += count
        if not removed:
            continue
        validate_wave_capacity(groups, hardware)
        old = estimate_wave(record["groups"], hardware, cache)
        new = estimate_wave(groups, hardware, cache)
        result["changed_waves"] += 1
        if new < old:
            result["accepted_waves"].append({"wave": wave_index,
                                             "old_cycles": old,
                                             "new_cycles": new,
                                             "saving": old - new,
                                             "removed_a_loads": removed})
            result["saved_cycles"] += old - new
            result["removed_a_loads"] += removed
    result["predicted_cycles"] = base_cycles - result["saved_cycles"]
    if output is not None:
        Path(output).parent.mkdir(parents=True, exist_ok=True)
        write(output, result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("hardware", type=Path)
    parser.add_argument("base_cycles", type=int)
    parser.add_argument("output", type=Path)
    parser.add_argument("--max-fanout", type=int, default=64)
    args = parser.parse_args()
    document = json.loads(args.hardware.read_text())
    result = screen(args.source, document.get("hardware", document),
                    args.base_cycles, args.max_fanout, args.output)
    print(json.dumps({key: result[key] for key in
                      ("changed_waves", "removed_a_loads", "saved_cycles",
                       "predicted_cycles")}, indent=2))


if __name__ == "__main__":
    main()
