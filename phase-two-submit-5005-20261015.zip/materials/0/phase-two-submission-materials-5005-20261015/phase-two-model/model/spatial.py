"""Reassign independent wave workgroups to SMs without changing paid commands."""

import argparse
import json
from pathlib import Path

from .estimate import program_records, validate_wave_capacity
from .hardware import validate


def _rewrite_record(record, sms, statistics):
    if isinstance(record, list):
        for member in record:
            _rewrite_record(member, sms, statistics)
    elif isinstance(record, dict):
        if record.get("record") == "wave":
            statistics["wave_definitions"] += 1
            for group_index, group in enumerate(record["groups"]):
                old_sm = group["sm"]
                if isinstance(old_sm, int):
                    group["sm"] = group_index % sms
                    statistics["changed_group_definitions"] += group["sm"] != old_sm
                else:
                    statistics["symbolic_group_definitions"] += 1
        for value in record.values():
            _rewrite_record(value, sms, statistics)


def rebalance_program(source, destination, hardware):
    validate(hardware)
    source = Path(source)
    destination = Path(destination)
    statistics = {"wave_definitions": 0, "changed_group_definitions": 0,
                  "symbolic_group_definitions": 0, "expanded_waves": 0}
    with source.open() as reader, destination.open("x") as writer:
        header = json.loads(next(reader))
        if not 1 <= header["hardware"]["sms"] <= hardware["sms"]:
            raise ValueError("spatial remapping cannot reduce the number of SMs")
        header["hardware"] = hardware
        writer.write(json.dumps(header, separators=(",", ":")) + "\n")
        for line in reader:
            record = json.loads(line)
            _rewrite_record(record, hardware["sms"], statistics)
            writer.write(json.dumps(record, separators=(",", ":")) + "\n")
    records = program_records(destination)
    next(records)
    for record in records:
        if record.get("record") == "wave":
            validate_wave_capacity(record["groups"], hardware)
            statistics["expanded_waves"] += 1
    return statistics


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("hardware", type=Path)
    args = parser.parse_args()
    hardware = json.loads(args.hardware.read_text())
    print(json.dumps(rebalance_program(args.source, args.destination, hardware), indent=2))


if __name__ == "__main__":
    main()
