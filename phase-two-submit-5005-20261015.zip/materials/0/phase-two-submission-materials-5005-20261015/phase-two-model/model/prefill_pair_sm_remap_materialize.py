"""Materialize SHA-gated SM load balancing of paired prefill waves."""

import argparse
import json
import subprocess
import sys
import tempfile
from pathlib import Path

from . import prefill_pair_sm_remap_screen
from .estimate import estimate_program, estimate_wave, program_records, validate_wave_capacity
from .resident4_pack_materialize import _cross_sm_safe
from .tool import STARTER, sha, write


def materialize(source, manifest_path, screen_path, output):
    source, manifest_path, screen_path, output = map(
        Path, (source, manifest_path, screen_path, output))
    manifest = json.loads(manifest_path.read_text())
    screen = json.loads(screen_path.read_text())
    case = screen["case"]
    if (case not in ("w-p", "a-p") or
            screen["source_sha256"] != sha(source) or
            screen["manifest_sha256"] != sha(manifest_path) or
            screen["model_sha256"] != sha(Path(prefill_pair_sm_remap_screen.__file__)) or
            manifest["program_sha256"][case] != sha(source) or
            screen["five_case_model_score"] < 5000 or
            not screen["meets_grade_gate"] or screen["cycle_delta"] >= 0):
        raise ValueError("screen gate or immutable source identity failed")
    hardware = manifest["hardware"]
    choices = {row["wave"]: row for row in screen["choices"]}
    if len(choices) != len(screen["choices"]):
        raise ValueError("duplicate selected wave")

    output.mkdir(parents=True, exist_ok=False)
    target = output / f"{case}.jsonl"
    wave_index = selected = source_commands = output_commands = 0
    with tempfile.TemporaryDirectory(prefix="pair-sm-remap-") as temporary:
        expanded = Path(temporary) / "expanded.jsonl"
        with expanded.open("x") as writer:
            records = program_records(source)
            header = next(records)
            if header["hardware"] != hardware:
                raise ValueError("source hardware changed")
            writer.write(json.dumps(header, separators=(",", ":")) + "\n")
            for record in records:
                if record["record"] != "wave":
                    writer.write(json.dumps(record, separators=(",", ":")) + "\n")
                    continue
                groups = record["groups"]
                source_commands += sum(len(group["commands"]) for group in groups)
                choice = choices.get(wave_index)
                if choice is not None:
                    if not prefill_pair_sm_remap_screen.eligible(groups):
                        raise ValueError("selected wave no longer has paired RF32 groups")
                    mapping = choice["mapping"]
                    if (len(mapping) != 8 or sorted(mapping) != list(range(8)) or
                            mapping == list(range(8))):
                        raise ValueError("selected mapping is not an SM permutation")
                    changed = prefill_pair_sm_remap_screen.remap(groups, mapping)
                    validate_wave_capacity(changed, hardware)
                    if not _cross_sm_safe(changed):
                        raise ValueError("selected SM mapping has a cross-SM dependency")
                    base = estimate_wave(groups, hardware)
                    cost = estimate_wave(changed, hardware)
                    if base != choice["base"] or cost != choice["cycles"]:
                        raise ValueError("selected wave differs from model screen")
                    groups = changed
                    selected += 1
                output_commands += sum(len(group["commands"]) for group in groups)
                writer.write(json.dumps({"record": "wave", "groups": groups},
                                        separators=(",", ":")) + "\n")
                wave_index += 1
        if (wave_index != screen["source_waves"] or
                selected != screen["selected_waves"] or
                source_commands != output_commands):
            raise ValueError("candidate coverage or command count changed")
        subprocess.run([sys.executable, str(STARTER / "tools/compact_program.py"),
                        str(expanded), str(target)], check=True)

    exact = estimate_program(target)["cycles"]
    if exact != screen["selected_cycles"]:
        raise ValueError("compact candidate differs from full model screen")
    result = {"case": case, "source_sha256": sha(source),
              "screen_sha256": sha(screen_path), "program_sha256": sha(target),
              "source_waves": wave_index, "selected_waves": selected,
              "source_commands": source_commands, "output_commands": output_commands,
              "exact_model_cycles": exact,
              "five_case_model_score": screen["five_case_model_score"],
              "hardware": hardware, "grade_allowed": True,
              "official_score": None}
    write(output / "manifest.json", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("manifest", type=Path)
    parser.add_argument("screen", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    print(json.dumps(materialize(args.source, args.manifest,
                                 args.screen, args.output), indent=2), flush=True)


if __name__ == "__main__":
    main()
