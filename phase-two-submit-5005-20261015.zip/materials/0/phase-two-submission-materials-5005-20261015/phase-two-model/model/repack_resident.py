"""Search independent decode waves packed into more resident workgroups."""

import argparse
import heapq
import json
from collections import defaultdict
from pathlib import Path

from .estimate import estimate_wave, program_records, validate_wave_capacity
from .merge import MAX_ACCESS_INTERVALS, MAX_COMMANDS, _overlaps


DMA = {"load", "store", "load_shared", "store_shared"}
WRITES = {"store", "store_shared"}


def footprint(record):
    result = {"reads": defaultdict(list), "writes": defaultdict(list),
              "commands": 0, "intervals": 0}
    for group in record["groups"]:
        result["commands"] += len(group["commands"])
        for command in group["commands"]:
            instruction = command.get("instruction", {})
            if instruction.get("op") not in DMA:
                continue
            view = instruction["global"]
            result["intervals"] += view["rows"]
            target = result["writes"] if instruction["op"] in WRITES else result["reads"]
            for row in range(view["rows"]):
                left = view["base"] + row * view["row_stride"]
                right = left + (view["cols"] - 1) * view["col_stride"]
                target[instruction["tensor"]].append((min(left, right), max(left, right)))
    for interval_list in (*result["reads"].values(), *result["writes"].values()):
        interval_list.sort()
    return result


def combine(left, right):
    if left["commands"] + right["commands"] > MAX_COMMANDS or \
            left["intervals"] + right["intervals"] > MAX_ACCESS_INTERVALS:
        return None
    for tensor in left["writes"].keys() | right["writes"].keys():
        if (_overlaps(left["writes"].get(tensor, []), right["writes"].get(tensor, [])) or
                _overlaps(left["writes"].get(tensor, []), right["reads"].get(tensor, [])) or
                _overlaps(left["reads"].get(tensor, []), right["writes"].get(tensor, []))):
            return None
    return {"reads": {tensor: list(heapq.merge(left["reads"].get(tensor, []),
                                                right["reads"].get(tensor, [])))
                      for tensor in left["reads"].keys() | right["reads"].keys()},
            "writes": {tensor: list(heapq.merge(left["writes"].get(tensor, []),
                                                 right["writes"].get(tensor, [])))
                       for tensor in left["writes"].keys() | right["writes"].keys()},
            "commands": left["commands"] + right["commands"],
            "intervals": left["intervals"] + right["intervals"]}


def pack(waves, hardware):
    groups = [group for wave in waves for group in wave["groups"]]
    result = []
    active = []
    rf = [0] * hardware["sms"]
    sh = [0] * hardware["sms"]
    slots = [0] * hardware["sms"]
    commands = intervals = 0

    def flush():
        nonlocal active, rf, sh, slots, commands, intervals
        if active:
            validate_wave_capacity(active, hardware)
            result.append({"record": "wave", "groups": active})
        active = []
        rf = [0] * hardware["sms"]
        sh = [0] * hardware["sms"]
        slots = [0] * hardware["sms"]
        commands = intervals = 0

    for group in groups:
        count = len(group["commands"])
        accesses = sum(command["instruction"]["global"]["rows"]
                       for command in group["commands"]
                       if command.get("instruction", {}).get("op") in DMA)
        if active and (commands + count > MAX_COMMANDS or
                       intervals + accesses > MAX_ACCESS_INTERVALS):
            flush()
        choices = [sm for sm in range(hardware["sms"])
                   if slots[sm] < hardware["resident_groups"] and
                   rf[sm] + group["rf_kib"] <= hardware["rf_kib"] and
                   sh[sm] + group["sh_kib"] <= hardware["sh_kib"]]
        if not choices:
            flush()
            choices = list(range(hardware["sms"]))
        sm = min(choices, key=lambda index: (slots[index], rf[index], sh[index], index))
        active.append(dict(group, sm=sm))
        rf[sm] += group["rf_kib"]
        sh[sm] += group["sh_kib"]
        slots[sm] += 1
        commands += count
        intervals += accesses
    flush()
    return result


def screen_case(source, hardware, max_run=8):
    records = program_records(source)
    next(records)
    cache = {}
    result = {"source_waves": 0, "output_waves": 0, "accepted_runs": [],
              "baseline_cycles": 0, "predicted_cycles": 0}
    pending = []
    intervals = None
    pending_start = 0

    def flush():
        nonlocal pending, intervals, pending_start
        if not pending:
            return
        old = sum(estimate_wave(wave["groups"], hardware, cache) for wave in pending)
        chosen = pending
        if len(pending) > 1:
            packed = pack(pending, hardware)
            new = sum(estimate_wave(wave["groups"], hardware, cache) for wave in packed)
            if new < old:
                chosen = packed
                result["accepted_runs"].append({"start_wave": pending_start,
                    "source_waves": len(pending), "output_waves": len(packed),
                    "old_cycles": old, "new_cycles": new, "saving": old - new})
        result["baseline_cycles"] += old
        result["predicted_cycles"] += (old if chosen is pending else new)
        result["output_waves"] += len(chosen)
        pending = []
        intervals = None

    for record in records:
        if record["record"] != "wave":
            flush()
            if record["record"] == "commit":
                result["baseline_cycles"] += 1
                result["predicted_cycles"] += 1
            continue
        index = result["source_waves"]
        result["source_waves"] += 1
        current = footprint(record)
        combined = combine(intervals, current) if intervals is not None else current
        if pending and (combined is None or len(pending) >= max_run):
            flush()
            combined = current
        if not pending:
            pending_start = index
        pending.append(record)
        intervals = combined
    flush()
    result["total_saving"] = result["baseline_cycles"] - result["predicted_cycles"]
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("hardware", type=Path)
    parser.add_argument("--max-run", type=int, default=8)
    args = parser.parse_args()
    hardware = json.loads(args.hardware.read_text())
    print(json.dumps(screen_case(args.source, hardware, args.max_run), indent=2))


if __name__ == "__main__":
    main()
