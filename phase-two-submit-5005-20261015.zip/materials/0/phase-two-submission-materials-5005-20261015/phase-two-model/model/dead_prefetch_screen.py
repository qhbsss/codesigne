"""Remove RF DMA loads proven overwritten before any RF read, then price waves."""

import argparse
import copy
import json
import math
from collections import Counter
from pathlib import Path

from .estimate import estimate_wave, program_records, validate_wave_capacity
from .tool import SCORE_CASES, sha, write


def _view_bounds(view):
    base = view["base"]
    return base, base + (view["rows"] - 1) * view["row_stride"] + (view["cols"] - 1) * view["col_stride"] + 1


def _rf_reads(instruction):
    op = instruction["op"]
    if op == "mma":
        return [(instruction["a"], instruction["a"] + instruction["m"] * instruction["k"]),
                (instruction["b"], instruction["b"] + instruction["k"] * instruction["n"]),
                (instruction["c"], instruction["c"] + instruction["m"] * instruction["n"])]
    if op == "mma_shared":
        return [(instruction["a"], instruction["a"] + instruction["m"] * instruction["k"]),
                (instruction["c"], instruction["c"] + instruction["m"] * instruction["n"])]
    if op == "vector":
        return [(arg["base"], arg["base"] + (instruction["len"] - 1) * arg["stride"] + 1)
                for arg in (instruction["a"], instruction["b"]) if arg["kind"] == "reg"]
    if op == "reduce":
        return [(instruction["src"], instruction["src"] + instruction["len"]),
                (instruction["scratch"], instruction["scratch"] + instruction["len"])]
    if op == "store":
        return [_view_bounds(instruction["local"])]
    if op == "shared_write":
        return [(instruction["local"], instruction["local"] +
                 instruction["shared"]["rows"] * instruction["shared"]["cols"])]
    if op in ("load", "load_shared", "store_shared", "shared_read", "fill"):
        return []
    return None


def _signature(view):
    return tuple(sorted(view.items()))


def dead_loads(group):
    commands = group["commands"]
    waits = Counter(token for command in commands if command["command"] == "wait"
                    for token in command["tokens"])
    repeats = Counter(_signature(command["instruction"]["local"])
                      for command in commands if command["command"] == "async" and
                      command["instruction"]["op"] == "load")
    pending = {}
    by_token = {}
    deleted = {}
    for index, command in enumerate(commands):
        if command["command"] == "wait":
            for token in command["tokens"]:
                candidate = by_token.get(token)
                if candidate is not None:
                    candidate["wait"] = index
            continue
        instruction = command["instruction"]
        reads = _rf_reads(instruction)
        if reads is None:
            pending.clear()
        elif reads:
            for key, candidate in list(pending.items()):
                left, right = candidate["bounds"]
                if any(left < end and start < right for start, end in reads):
                    del pending[key]
        if (command["command"] != "async" or instruction["op"] != "load" or
                waits[command["token"]] != 1):
            continue
        key = _signature(instruction["local"])
        if repeats[key] < 2:
            continue
        previous = pending.get(key)
        if previous is not None and previous["wait"] is not None:
            deleted[previous["index"]] = (previous["token"], previous["wait"])
        candidate = {"index": index, "token": command["token"],
                     "bounds": _view_bounds(instruction["local"]), "wait": None}
        pending[key] = candidate
        by_token[command["token"]] = candidate
    return deleted


def transform_group(group):
    dead = dead_loads(group)
    if not dead:
        return group, 0
    remove_from_wait = {}
    for token, wait_index in dead.values():
        remove_from_wait.setdefault(wait_index, set()).add(token)
    commands = []
    for index, command in enumerate(group["commands"]):
        if index in dead:
            continue
        if index in remove_from_wait:
            keep = [token for token in command["tokens"] if token not in remove_from_wait[index]]
            if keep:
                commands.append({"command": "wait", "tokens": keep})
        else:
            commands.append(command)
    return dict(group, commands=commands), len(dead)


def screen_case(source, hardware, baseline_cycles, output):
    source, output = Path(source), Path(output)
    records = program_records(source)
    header = next(records)
    if header["hardware"] != hardware:
        raise ValueError("source hardware changed")
    cache = {}
    waves = changed = removed = delta = 0
    decisions = []
    for record in records:
        if record["record"] != "wave":
            continue
        groups = []
        count = 0
        for group in record["groups"]:
            updated, found = transform_group(group)
            groups.append(updated)
            count += found
        if count:
            validate_wave_capacity(groups, hardware)
            before = estimate_wave(record["groups"], hardware, cache)
            after = estimate_wave(groups, hardware, cache)
            if after < before:
                delta += after - before
                changed += 1
                removed += count
                decisions.append({"wave": waves, "removed_loads": count,
                                  "old_cycles": before, "new_cycles": after})
        waves += 1
        if waves % 8 == 0:
            write(output, {"source_sha256": sha(source), "waves_seen": waves,
                           "changed_waves": changed, "removed_loads": removed,
                           "cycle_delta": delta, "decisions": decisions,
                           "complete": False})
    result = {"source_sha256": sha(source), "waves_seen": waves,
              "changed_waves": changed, "removed_loads": removed,
              "cycle_delta": delta, "decisions": decisions,
              "predicted_cycles": baseline_cycles + delta,
              "complete": True, "candidate_program_generated": False,
              "official_score": None}
    write(output, result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("manifest", type=Path)
    parser.add_argument("case")
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    manifest = json.loads(args.manifest.read_text())
    if args.case not in SCORE_CASES:
        raise ValueError("unknown score case")
    source = args.manifest.parent / "programs" / f"{args.case}.jsonl"
    if sha(source) != manifest["program_sha256"][args.case]:
        raise ValueError("source SHA changed")
    result = screen_case(source, manifest["hardware"],
                         manifest["exact_model_cycles"][args.case], args.output)
    cycles = dict(manifest["exact_model_cycles"])
    cycles[args.case] = result["predicted_cycles"]
    result["five_case_model_score"] = 1000 * math.exp(sum(
        weight * math.log(reference / cycles[case])
        for case, (reference, weight) in SCORE_CASES.items()))
    result["meets_grade_gate"] = result["five_case_model_score"] >= 5000
    write(args.output, result)
    print(json.dumps({key: result[key] for key in ("changed_waves", "removed_loads",
          "cycle_delta", "five_case_model_score")}, indent=2))


if __name__ == "__main__":
    main()
