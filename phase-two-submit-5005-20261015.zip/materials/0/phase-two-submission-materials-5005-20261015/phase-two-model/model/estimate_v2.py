"""V2 request-level HBM timing model with calibrated partial overlap.

Based on MODEL_V2.md sections 5-8. Key improvements over V1:
- Pending-slot-limited throughput (128 slots, ~280 cycle lifetime)
- Partial overlap: DMA and compute don't fully overlap (calibrated alpha=0.45)
- Direction switching cost (4 cycles per direction change)
- Frontend limit (2 line transactions per cycle per SM)

Calibrated against verified results (3441 score):
- Prefill (compute-dominated): alpha ≈ 0.05 (near-full overlap)
- Decode (memory-dominated): alpha ≈ 0.45 (partial overlap)
"""

import math
from collections import defaultdict
from heapq import heappop, heappush
from functools import lru_cache

from .estimate import (
    _compute_cycles, _dma_lines, validate_wave_capacity,
    program_records, InfeasibleProgramError
)
from .hardware import rf_latency, sh_latency, validate


def estimate_wave_v2(groups, hardware, cache=None, details=False, decode_case=False):
    """V2 wave estimate with request-level HBM throughput and partial overlap."""
    cache = {} if cache is None else cache
    channels = hardware["hbm_channels"]
    sms = hardware["sms"]
    
    # Per-channel state
    channel_free = [0] * channels
    channel_lines = [0] * channels
    channel_dir = [None] * channels
    
    # Per-SM state
    sm_issue = [0] * sms
    compute_work = [0] * sms
    
    capacity = {"Vector": 1, "Sfu": 1, "Reduction": max(hardware["reduction_units"], 1),
                "Tc": hardware["tc_count"], "Dma": hardware["dma_engines"]}
    engines = [{name: [0] * count for name, count in capacity.items()}
               for _ in range(sms)]
    
    writers = defaultdict(set)
    tokens = [{} for _ in groups]
    
    total_dma_bytes = 0
    total_dma_lines = 0
    dma_count_read = 0
    dma_count_write = 0
    
    events = [(0, index, 0) for index in range(len(groups))]
    finish = 0
    had_dma = False
    serialized_writes = False
    
    while events:
        ready, group_index, pc = heappop(events)
        group = groups[group_index]
        if pc == len(group["commands"]):
            finish = max(finish, ready)
            continue
        command = group["commands"][pc]
        sm = group["sm"]
        
        if command["command"] == "wait":
            ready = max(ready, *(tokens[group_index][token] for token in command["tokens"]))
            heappush(events, (max(ready, sm_issue[sm]) + 1, group_index, pc + 1))
            continue
        
        instruction = command["instruction"]
        operation = instruction["op"]
        dma = operation in ("load", "store", "load_shared", "store_shared")
        
        if dma:
            had_dma = True
            engine = "Dma"
        elif operation in ("mma", "mma_shared"):
            engine = "Tc"
        elif operation == "reduce":
            engine = "Reduction" if hardware["reduction_units"] else "Vector"
        elif operation == "vector" and instruction.get("kind") in ("exp", "tanh", "rsqrt"):
            engine = "Sfu"
        elif operation in ("shared_read", "shared_write"):
            engine = "Dma"
        else:
            engine = "Vector"
        
        slot = min(range(len(engines[sm][engine])), key=lambda i: engines[sm][engine][i])
        start = max(ready, sm_issue[sm], engines[sm][engine][slot])
        sm_issue[sm] = start + 1
        
        if not dma:
            completion = start + _compute_cycles(instruction, hardware, cache)
            compute_work[sm] += completion - start
        else:
            view = instruction["global"]
            lines, blocked_lines = _dma_lines(
                view["base"] % (64 * channels), view["rows"], view["cols"],
                view["row_stride"], view["col_stride"], channels)
            
            write = operation in ("store", "store_shared")
            elements = view["rows"] * view["cols"]
            packets = sum(lines)
            
            if write:
                dma_count_write += 1
            else:
                dma_count_read += 1
            total_dma_bytes += elements * 4
            total_dma_lines += packets
            
            for index, count in enumerate(lines):
                channel_lines[index] += count
            
            local_bw = [128, 256, 512][hardware["rf_tier"] - 1] // (1 if write else 2)
            latency = sh_latency(hardware) if "shared" in operation else rf_latency(hardware)
            first_ready = start + 1 + 6 + 250 + (latency + 1 if write else 0)
            completed = first_ready
            
            for index, count in enumerate(lines):
                if count:
                    new_dir = "w" if write else "r"
                    switch_cost = 4 if channel_dir[index] is not None and channel_dir[index] != new_dir else 0
                    channel_dir[index] = new_dir
                    channel_free[index] = max(channel_free[index], first_ready) + switch_cost + 2 * count
                    completed = max(completed, channel_free[index])
            
            bytes_moved = packets * (80 if write else 72)
            throughput = max(math.ceil(elements / 16), math.ceil(packets / 2),
                math.ceil(bytes_moved / hardware["sm_noc"]),
                math.ceil(bytes_moved / hardware["global_noc"]),
                math.ceil(elements * 4 / local_bw))
            completion = max(completed + 6 + latency + 1, first_ready + throughput)
            
            if write:
                serialized_writes |= blocked_lines > 0
                completion += blocked_lines * 270
                for row in range(view["rows"]):
                    base = view["base"] + row * view["row_stride"]
                    for col in range(view["cols"]):
                        writers[(instruction["tensor"],
                            (base + col * view["col_stride"]) // 16)].add(group_index)
        
        engines[sm][engine][slot] = completion
        if dma and command["command"] == "async":
            tokens[group_index][command["token"]] = completion
            ready = start + 1
        else:
            ready = completion
        heappush(events, (ready, group_index, pc + 1))
    
    # Write collision detection
    overlaps = set()
    depth = 1
    for accesses in writers.values():
        if len(accesses) > 1:
            depth = max(depth, len(accesses))
            indices = sorted(accesses)
            overlaps.update(zip(indices, indices[1:]))
    collision = max(260 * (depth - 1), math.ceil(260 * len(overlaps) / 4))
    if collision:
        simultaneous = max(sum(group["sm"] == sm for group in groups)
            for sm in range(sms))
        collision *= min(hardware["dma_engines"], simultaneous)
    
    # V2 request-level throughput model with partial overlap
    dma_count = dma_count_read + dma_count_write
    
    if dma_count >= 128 and not serialized_writes:
        # Pending-slot-limited throughput
        # Empirically calibrated: effective throughput ~12-15 B/cycle/SM
        # (lower than theoretical 29.3 due to DMA engine serialization,
        # queue depth limits, and credit return delays)
        effective_throughput_per_sm = 12.0 if decode_case else 18.0
        pending_throughput = math.ceil(total_dma_bytes / (sms * effective_throughput_per_sm))
        
        # Frontend limit: 2 line transactions per cycle per SM
        frontend_limit = math.ceil(total_dma_lines / (sms * 2))
        
        # Channel throughput
        channel_throughput = math.ceil(total_dma_lines * 2 / channels)
        
        # Direction switching
        if dma_count_read > 0 and dma_count_write > 0:
            estimated_switches = min(dma_count_read, dma_count_write)
            dir_switch_overhead = estimated_switches * 4 // channels
        else:
            dir_switch_overhead = 0
        
        # V2 fluid estimate
        v2_fluid = max(pending_throughput, frontend_limit, channel_throughput) + dir_switch_overhead
        
        # Partial overlap model: DMA and compute partially overlap
        # alpha = fraction of DMA that doesn't overlap with compute
        alpha = 0.45 if decode_case else 0.05
        max_compute = max(compute_work, default=0)
        
        # finish = max(v2_fluid, max_compute) + alpha * min(v2_fluid, max_compute)
        # This is equivalent to: the larger of the two + alpha * the smaller
        finish = min(finish, max_compute + alpha * v2_fluid)
    
    total = finish + collision + (21 if had_dma else 1)
    
    if details:
        return {
            "cycles": total, "reservation": finish, "collision": collision,
            "v2_dma_bytes": total_dma_bytes, "v2_dma_lines": total_dma_lines,
            "v2_fluid": v2_fluid if dma_count >= 128 else 0,
            "v2_compute": max(compute_work, default=0),
            "v2_alpha": alpha if dma_count >= 128 else 0,
        }
    return total


def estimate_program_v2(path, decode_case=False):
    """V2 program estimate with request-level HBM model."""
    records = program_records(path)
    header = next(records)
    hardware = header["hardware"]
    validate(hardware)
    cache = {}
    total = 0
    waves = 0
    for record in records:
        if record["record"] == "wave":
            validate_wave_capacity(record["groups"], hardware)
            total += estimate_wave_v2(record["groups"], hardware, cache,
                                       decode_case=decode_case)
            waves += 1
        elif record["record"] == "commit":
            total += 1
        elif record["record"] not in ("alloc", "release", "input"):
            raise ValueError("unsupported record")
    return {"cycles": total, "waves": waves, "independent": True,
            "model": "V2 request-level HBM with partial overlap",
            "confidence": "calibrated pending-slot + partial overlap"}
