"""Paid two-pass causal attention: recompute QK to avoid materialized scores."""

import math

from .estimate import validate_wave_capacity
from .online_attention import _emit, _imm, _load, _reg, _vector, _view


def _key_view(layout, begin, count, context, head_index, hidden_width, head_width):
    if layout == "transposed":
        return _view(head_index * head_width * context + begin,
                     head_width, count, context)
    if layout == "strided":
        return _view(begin * hidden_width + head_index * head_width,
                     head_width, count, 1, hidden_width)
    raise ValueError(f"unsupported key layout: {layout}")


def _score_block(commands, query_base, key_base, score_base, maximum_base,
                 scratch_base, temporary_base, start, rows, begin, count,
                 head_width, scale, update_maximum):
    _emit(commands, "fill", dst=score_base, len=rows * count, value=0.0)
    _emit(commands, "mma", a=query_base, b=key_base, c=score_base,
          m=rows, n=count, k=head_width)
    _vector(commands, "mul", score_base, rows * count,
            _reg(score_base), _imm(scale))
    for row in range(rows):
        score_row = score_base + row * count
        valid = min(count, max(0, start + row + 1 - begin))
        if valid < count:
            _emit(commands, "fill", dst=score_row + valid,
                  len=count - valid, value=-1e30)
        if update_maximum:
            _emit(commands, "reduce", scratch=scratch_base,
                  dst=temporary_base, src=score_row, len=count, max=True)
            _vector(commands, "add", temporary_base + 1, 1,
                    _reg(maximum_base + row, 0), _imm(0.0))
            _emit(commands, "reduce", scratch=scratch_base,
                  dst=maximum_base + row, src=temporary_base, len=2, max=True)


def _two_pass_group(start, rows, context, head_index, hidden_width, head_width,
                    key_block, query_tensor, key_tensor, value_tensor,
                    output_tensor, key_layout, sm):
    query_base = 0
    output_base = query_base + rows * head_width
    score_base = output_base + rows * head_width
    key_base = score_base + rows * key_block
    value_base = key_base + head_width * key_block
    maximum_base = value_base + key_block * head_width
    sum_base = maximum_base + rows
    temporary_base = sum_base + rows
    scratch_base = temporary_base + 8
    words = scratch_base + max(key_block, 2)
    commands = []
    _load(commands, query_tensor,
          _view(start * 3 * hidden_width + head_index * head_width,
                rows, head_width, 3 * hidden_width),
          _view(query_base, rows, head_width, head_width))
    _emit(commands, "fill", dst=output_base, len=rows * head_width, value=0.0)
    _emit(commands, "fill", dst=maximum_base, len=rows, value=-1e30)
    _emit(commands, "fill", dst=sum_base, len=rows, value=0.0)
    end = min(start + rows, context)
    scale = 1.0 / math.sqrt(head_width)
    for begin in range(0, end, key_block):
        count = min(key_block, end - begin)
        _load(commands, key_tensor,
              _key_view(key_layout, begin, count, context, head_index,
                        hidden_width, head_width),
              _view(key_base, head_width, count, count))
        _score_block(commands, query_base, key_base, score_base,
                     maximum_base, scratch_base, temporary_base,
                     start, rows, begin, count, head_width, scale, True)
    for begin in range(0, end, key_block):
        count = min(key_block, end - begin)
        _load(commands, key_tensor,
              _key_view(key_layout, begin, count, context, head_index,
                        hidden_width, head_width),
              _view(key_base, head_width, count, count))
        _load(commands, value_tensor,
              _view(begin * hidden_width + head_index * head_width,
                    count, head_width, hidden_width),
              _view(value_base, count, head_width, head_width))
        _score_block(commands, query_base, key_base, score_base,
                     maximum_base, scratch_base, temporary_base,
                     start, rows, begin, count, head_width, scale, False)
        for row in range(rows):
            score_row = score_base + row * count
            _vector(commands, "sub", score_row, count,
                    _reg(score_row), _reg(maximum_base + row, 0))
            _vector(commands, "exp", score_row, count,
                    _reg(score_row), _imm(0.0))
            _emit(commands, "reduce", scratch=scratch_base,
                  dst=temporary_base, src=score_row, len=count, max=False)
            _vector(commands, "add", sum_base + row, 1,
                    _reg(sum_base + row, 0), _reg(temporary_base, 0))
        _emit(commands, "mma", a=score_base, b=value_base, c=output_base,
              m=rows, n=head_width, k=count)
    for row in range(rows):
        _vector(commands, "div", output_base + row * head_width, head_width,
                _reg(output_base + row * head_width), _reg(sum_base + row, 0))
    _emit(commands, "store", tensor=output_tensor,
          **{"global": _view(start * hidden_width + head_index * head_width,
                            rows, head_width, hidden_width),
             "local": _view(output_base, rows, head_width, head_width)})
    return {"sm": sm, "rf_kib": (words + 255) // 256,
            "sh_kib": 0, "commands": commands}


def two_pass_waves(header, query_tensor, key_tensor, value_tensor, output_tensor,
                   key_layout, row_tile, key_block):
    shape = header["shape"]
    context = shape["prefill"]
    head_width = shape["d"] // shape["heads"]
    sms = header["hardware"]["sms"]
    if head_width > 64 or key_block > 64 or row_tile > 64:
        raise ValueError("two-pass template only supports head, row and key widths <=64")
    for head_index in range(shape["heads"]):
        starts = list(range(0, context, row_tile))
        for offset in range(0, len(starts), 2 * sms):
            chunk = starts[offset:offset + 2 * sms]
            groups = [
                _two_pass_group(start, min(row_tile, context - start), context,
                                head_index, shape["d"], head_width, key_block,
                                query_tensor, key_tensor, value_tensor, output_tensor,
                                key_layout, index % sms)
                for index, start in enumerate(chunk)
            ]
            validate_wave_capacity(groups, header["hardware"])
            yield {"record": "wave", "groups": groups}
