"""Materialize a compact GELU-batched candidate after full model screening."""

import argparse
import json
import subprocess
import sys
import tempfile
from pathlib import Path

from . import prefill_gelu_batch_screen
from .estimate import estimate_program, estimate_wave, program_records
from .tool import STARTER, sha, write


def materialize(source, manifest_path, screen_path, output):
    source, manifest_path, screen_path, output = map(
        Path, (source, manifest_path, screen_path, output))
    manifest = json.loads(manifest_path.read_text())
    screen = json.loads(screen_path.read_text())
    case = screen["case"]
    if (screen["source_sha256"] != sha(source) or
            screen["manifest_sha256"] != sha(manifest_path) or
            screen["model_sha256"] != sha(Path(prefill_gelu_batch_screen.__file__)) or
            manifest["program_sha256"][case] != sha(source) or
            screen["five_case_model_score"] < 5000 or
            not screen["meets_grade_gate"] or
            screen["cycle_delta"] >= 0 or
            screen["beneficial_waves"] != len(screen["choices"])):
        raise ValueError("screen gate or immutable source identity failed")
    hardware = manifest["hardware"]
    choices = {row["wave"]: row for row in screen["choices"]}
    if len(choices) != len(screen["choices"]):
        raise ValueError("duplicate chosen wave")

    output.mkdir(parents=True, exist_ok=False)
    target = output / f"{case}.jsonl"
    wave_index = selected_tiles = source_commands = output_commands = 0
    with tempfile.TemporaryDirectory(prefix="gelu-batch-") as temporary:
        expanded = Path(temporary) / "expanded.jsonl"
        with expanded.open("x") as writer:
            records = program_records(source)
            header = next(records)
            if header["hardware"] != hardware:
                raise ValueError("source hardware changed")
            writer.write(json.dumps(header, separators=(",", ":")) + "\n")
            for record in records:
                if record["record"] != "wave":
                    writer.write(json.dumps(record, separators=(",", ":")) + "\n")
                    continue
                source_commands += sum(len(group["commands"]) for group in record["groups"])
                choice = choices.get(wave_index)
                if choice is not None:
                    candidate, tiles = prefill_gelu_batch_screen.batch_wave(
                        record["groups"], hardware)
                    base = estimate_wave(record["groups"], hardware)
                    new = estimate_wave(candidate, hardware)
                    if (tiles != choice["tiles"] or base != choice["base"] or
                            new != choice["cycles"]):
                        raise ValueError("candidate wave differs from model screen")
                    record = dict(record, groups=candidate)
                    selected_tiles += tiles
                output_commands += sum(len(group["commands"]) for group in record["groups"])
                writer.write(json.dumps(record, separators=(",", ":")) + "\n")
                wave_index += 1
        if (wave_index != screen["source_waves"] or
                selected_tiles != screen["selected_tiles"] or
                source_commands - output_commands !=
                screen["eliminated_vector_instructions"]):
            raise ValueError("candidate coverage or command count changed")
        subprocess.run([sys.executable, str(STARTER / "tools/compact_program.py"),
                        str(expanded), str(target)], check=True)

    exact = estimate_program(target)["cycles"]
    if exact != screen["selected_cycles"]:
        raise ValueError("compact candidate differs from full model screen")
    result = {"case": case, "source_sha256": sha(source),
              "screen_sha256": sha(screen_path), "program_sha256": sha(target),
              "source_waves": wave_index, "selected_tiles": selected_tiles,
              "source_commands": source_commands, "output_commands": output_commands,
              "exact_model_cycles": exact,
              "five_case_model_score": screen["five_case_model_score"],
              "hardware": hardware, "grade_allowed": True,
              "official_score": None}
    write(output / "manifest.json", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("manifest", type=Path)
    parser.add_argument("screen", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    print(json.dumps(materialize(args.source, args.manifest,
                                 args.screen, args.output), indent=2), flush=True)


if __name__ == "__main__":
    main()
