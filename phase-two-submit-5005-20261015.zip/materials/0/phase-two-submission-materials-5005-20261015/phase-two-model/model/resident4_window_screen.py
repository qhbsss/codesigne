"""Screen wider independent-wave packing without generating candidate programs."""

import argparse
import heapq
import json
import math
from collections import deque
from pathlib import Path

from .estimate import estimate_wave, program_records
from .merge import _overlaps
from .resident4_pack_screen import _access_footprint, _pack
from .tool import SCORE_CASES, sha, write


def independent(entries):
    """Reject every cross-wave tensor read/write conflict before moving a barrier."""
    if len(entries) < 2 or any(entry[2] is None for entry in entries):
        return False
    first = entries[0][2]["key"]
    if any((entry[2]["key"][0], entry[2]["key"][4]) != (first[0], first[4])
           for entry in entries[1:]):
        return False
    aggregate = entries[0][2]["intervals"]
    for entry in entries[1:]:
        newer = entry[2]["intervals"]
        for tensor in aggregate["writes"].keys() | newer["writes"].keys():
            if (_overlaps(aggregate["writes"].get(tensor, []), newer["writes"].get(tensor, [])) or
                    _overlaps(aggregate["writes"].get(tensor, []), newer["reads"].get(tensor, [])) or
                    _overlaps(aggregate["reads"].get(tensor, []), newer["writes"].get(tensor, []))):
                return False
        aggregate = {
            kind: {tensor: list(heapq.merge(aggregate[kind].get(tensor, []),
                                           newer[kind].get(tensor, [])))
                   for tensor in aggregate[kind].keys() | newer[kind].keys()}
            for kind in ("reads", "writes")
        }
    return True


def choose(rows):
    """Exact shortest path over nonoverlapping packing windows."""
    best = [0] * (len(rows) + 1)
    selected = [None] * len(rows)
    for i in range(len(rows) - 1, -1, -1):
        best[i] = rows[i]["base"] + best[i + 1]
        for option in rows[i]["options"]:
            end = i + option["source_waves"]
            if option["cycles"] + best[end] < best[i]:
                best[i] = option["cycles"] + best[end]
                selected[i] = option
    output = []
    i = 0
    while i < len(rows):
        if selected[i] is None:
            output.append({"source_start": i, "source_waves": 1,
                           "packed_waves": 1, "cycles": rows[i]["base"]})
            i += 1
        else:
            output.append({"source_start": i, **selected[i]})
            i += selected[i]["source_waves"]
    return output, best[0]


def screen(source, case, manifest_path, output, max_window=4):
    source, manifest_path, output = map(Path, (source, manifest_path, output))
    output.parent.mkdir(parents=True, exist_ok=True)
    manifest = json.loads(manifest_path.read_text())
    if sha(source) != manifest["program_sha256"][case]:
        raise ValueError("program SHA changed")
    records = program_records(source)
    header = next(records)
    hardware = manifest["hardware"]
    if header["hardware"] != hardware:
        raise ValueError("hardware mismatch")
    cache = {}
    rows = []
    buffer = deque()
    wave_index = 0
    commit_cycles = 0

    def flush(force=False):
        while buffer and (force or len(buffer) >= max_window):
            first = buffer[0]
            choices = []
            for width in range(2, min(len(buffer), max_window) + 1):
                entries = list(buffer)[:width]
                if not independent(entries):
                    continue
                packed = _pack([entry[0] for entry in entries], hardware)
                if len(packed) >= width:
                    continue
                cost = sum(estimate_wave(groups, hardware, cache) for groups in packed)
                base = sum(entry[1] for entry in entries)
                if cost < base:
                    choices.append({"source_waves": width, "packed_waves": len(packed),
                                    "cycles": cost, "base": base})
            rows.append({"base": first[1], "options": choices})
            buffer.popleft()
            if len(rows) % 64 == 0:
                print(case, "screened", len(rows), flush=True)
                write(output.with_name("progress.json"),
                      {"case": case, "source_sha256": sha(source),
                       "screened_waves": len(rows), "total_options": sum(len(row["options"]) for row in rows)})

    for record in records:
        if record.get("record") != "wave":
            flush(force=True)
            if record.get("record") == "commit":
                commit_cycles += 1
            continue
        groups = record["groups"]
        buffer.append((record, estimate_wave(groups, hardware, cache),
                       _access_footprint(record), wave_index))
        wave_index += 1
        flush()
    flush(force=True)
    baseline = commit_cycles + sum(row["base"] for row in rows)
    if wave_index != len(rows) or baseline != manifest["model_cycles"][case]:
        raise ValueError(f"full model baseline differs: {wave_index}, {baseline}, {manifest['model_cycles'][case]}")
    picked, packed_wave_cost = choose(rows)
    cost = commit_cycles + packed_wave_cost
    cycles = dict(manifest["model_cycles"])
    cycles[case] = cost
    score = 1000 * math.exp(sum(weight * math.log(reference / cycles[name])
                              for name, (reference, weight) in SCORE_CASES.items()))
    result = {"case": case, "source_sha256": sha(source),
              "manifest_sha256": sha(manifest_path), "max_window": max_window,
              "source_waves": wave_index, "packed_waves": sum(row["packed_waves"] for row in picked),
              "chosen": [row for row in picked if row["source_waves"] > 1],
              "candidate_options": sum(len(row["options"]) for row in rows),
              "base_cycles": baseline, "selected_cycles": cost, "cycle_delta": cost - baseline,
              "five_case_model_cycles": cycles, "five_case_model_score": score,
              "meets_grade_gate": score >= 5000,
              "candidate_program_generated": False, "official_score": None}
    write(output, result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("case")
    parser.add_argument("manifest", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--max-window", type=int, default=4)
    args = parser.parse_args()
    if not 2 <= args.max_window <= 6:
        parser.error("max-window must be in [2, 6]")
    result = screen(args.source, args.case, args.manifest, args.output, args.max_window)
    print(json.dumps({key: result[key] for key in ("case", "source_waves", "packed_waves",
                                                   "candidate_options", "cycle_delta",
                                                   "five_case_model_score")}, indent=2))


if __name__ == "__main__":
    main()
