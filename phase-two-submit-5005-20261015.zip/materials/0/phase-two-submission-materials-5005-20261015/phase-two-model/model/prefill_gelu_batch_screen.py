"""Screen a batched GELU epilogue in memory, without writing candidate programs.

The existing fused prefill GEMM computes each 32-by-64 tile's GELU one row at
a time, reusing one 64-word scratch vector.  After the final MMA, the 2048-word
RF range 6144..8191 is dead.  This transform places one scratch value per
output element there and executes each of the nine GELU operations once over
the complete tile.  Every element keeps its original operation order.
"""

import argparse
import copy
import json
import math
from pathlib import Path

from .estimate import estimate_wave, program_records, validate_wave_capacity
from .tool import SCORE_CASES, sha, write


ROWS = 32
COLS = 64
ELEMENTS = ROWS * COLS
SCRATCH = 6144


def _reg(base):
    return {"kind": "reg", "base": base, "stride": 1}


def _imm(value):
    return {"kind": "imm", "value": value}


def _vector(kind, dst, length, a, b):
    return {"op": "vector", "kind": kind, "dst": dst, "len": length,
            "a": a, "b": b}


def _gelu_row(row):
    out = row * COLS
    return (
        _vector("square", SCRATCH, COLS, _reg(out), _imm(0.0)),
        _vector("mul", SCRATCH, COLS, _reg(SCRATCH), _reg(out)),
        _vector("mul", SCRATCH, COLS, _reg(SCRATCH), _imm(0.044715)),
        _vector("add", SCRATCH, COLS, _reg(SCRATCH), _reg(out)),
        _vector("mul", SCRATCH, COLS, _reg(SCRATCH), _imm(0.7978845)),
        _vector("tanh", SCRATCH, COLS, _reg(SCRATCH), _imm(0.0)),
        _vector("add", SCRATCH, COLS, _reg(SCRATCH), _imm(1.0)),
        _vector("mul", SCRATCH, COLS, _reg(SCRATCH), _imm(0.5)),
        _vector("mul", out, COLS, _reg(out), _reg(SCRATCH)),
    )


def _matches(commands, start, group):
    if group["rf_kib"] < 32 or start < ROWS + 1:
        return False
    if start + ROWS * 9 >= len(commands):
        return False
    load = commands[start - ROWS - 1]
    if (load["command"] != "run" or
            load["instruction"].get("op") != "load" or
            load["instruction"]["local"] !=
            {"base": SCRATCH, "rows": 1, "cols": COLS,
             "row_stride": COLS, "col_stride": 1}):
        return False
    for row in range(ROWS):
        bias = commands[start - ROWS + row]
        if (bias["command"] != "run" or
                bias["instruction"] != _vector("add", row * COLS, COLS,
                                                 _reg(row * COLS), _reg(SCRATCH))):
            return False
        for step, expected in enumerate(_gelu_row(row)):
            command = commands[start + row * 9 + step]
            if command["command"] != "run" or command["instruction"] != expected:
                return False
    store = commands[start + ROWS * 9]
    if (store["command"] != "run" or
            store["instruction"].get("op") != "store" or
            store["instruction"]["local"] !=
            {"base": 0, "rows": ROWS, "cols": COLS,
             "row_stride": COLS, "col_stride": 1}):
        return False
    next_index = start + ROWS * 9 + 1
    return (next_index == len(commands) or
            (commands[next_index]["command"] == "run" and
             commands[next_index]["instruction"].get("op") == "fill"))


def _batch_gelu():
    for instruction in _gelu_row(0):
        rewritten = copy.deepcopy(instruction)
        rewritten["len"] = ELEMENTS
        yield {"command": "run", "instruction": rewritten}


def batch_group(group):
    """Return a new command list and matched tile count; leave source untouched."""
    commands = group["commands"]
    rewritten = []
    pending = set()
    cursor = 0
    tiles = 0
    while cursor < len(commands):
        command = commands[cursor]
        if (not pending and command["command"] == "run" and
                command["instruction"].get("op") == "vector" and
                command["instruction"].get("kind") == "square" and
                _matches(commands, cursor, group)):
            rewritten.extend(_batch_gelu())
            cursor += ROWS * 9
            tiles += 1
            continue
        rewritten.append(command)
        if command["command"] == "async":
            pending.add(command["token"])
        elif command["command"] == "wait":
            pending.difference_update(command["tokens"])
        cursor += 1
    return rewritten, tiles


def batch_wave(groups, hardware):
    result = []
    total_tiles = 0
    for group in groups:
        commands, tiles = batch_group(group)
        result.append(dict(group, commands=commands))
        total_tiles += tiles
    if total_tiles:
        validate_wave_capacity(result, hardware)
    return result, total_tiles


def screen(source, manifest_path, case, output):
    source, manifest_path, output = map(Path, (source, manifest_path, output))
    manifest = json.loads(manifest_path.read_text())
    if case not in ("w-p", "a-p"):
        raise ValueError("GELU batching is scoped to the two prefill cases")
    expected_sha = manifest["program_sha256"][case]
    if sha(source) != expected_sha:
        raise ValueError("source SHA differs from full five-case manifest")
    records = program_records(source)
    header = next(records)
    hardware = manifest["hardware"]
    if header["hardware"] != hardware:
        raise ValueError("hardware differs from full five-case manifest")

    cache = {}
    waves = eligible = beneficial = tiles_seen = tiles_selected = 0
    saved_cycles = 0
    choices = []
    for record in records:
        if record["record"] != "wave":
            continue
        candidate, tiles = batch_wave(record["groups"], hardware)
        if tiles:
            eligible += 1
            tiles_seen += tiles
            original = estimate_wave(record["groups"], hardware, cache)
            replacement = estimate_wave(candidate, hardware, cache)
            if replacement < original:
                beneficial += 1
                tiles_selected += tiles
                saved_cycles += original - replacement
                choices.append({"wave": waves, "tiles": tiles,
                                "base": original, "cycles": replacement})
            if eligible % 8 == 0:
                print(case, "eligible", eligible, "beneficial", beneficial,
                      "saved_cycles", saved_cycles, flush=True)
        waves += 1

    cycles = dict(manifest["model_cycles"])
    cycles[case] -= saved_cycles
    score = 1000 * math.exp(sum(weight * math.log(reference / cycles[name])
                                for name, (reference, weight) in SCORE_CASES.items()))
    result = {"case": case, "source_sha256": expected_sha,
              "manifest_sha256": sha(manifest_path),
              "model_sha256": sha(Path(__file__)),
              "source_waves": waves, "eligible_waves": eligible,
              "beneficial_waves": beneficial, "eligible_tiles": tiles_seen,
              "selected_tiles": tiles_selected,
              "eliminated_vector_instructions": tiles_selected * (ROWS * 9 - 9),
              "base_cycles": manifest["model_cycles"][case],
              "selected_cycles": cycles[case], "cycle_delta": -saved_cycles,
              "choices": choices, "five_case_model_cycles": cycles,
              "five_case_model_score": score,
              "meets_grade_gate": score >= 5000,
              "candidate_program_generated": False, "official_score": None}
    output.parent.mkdir(parents=True, exist_ok=True)
    write(output, result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("manifest", type=Path)
    parser.add_argument("case", choices=("w-p", "a-p"))
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    result = screen(args.source, args.manifest, args.case, args.output)
    print(json.dumps({key: result[key] for key in
                      ("case", "eligible_waves", "beneficial_waves", "selected_tiles",
                       "cycle_delta", "five_case_model_score")}, indent=2), flush=True)


if __name__ == "__main__":
    main()
