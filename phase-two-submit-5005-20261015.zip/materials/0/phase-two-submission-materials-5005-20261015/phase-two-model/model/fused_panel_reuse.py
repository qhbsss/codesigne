"""Price two-output fused GEMM panel reuse entirely in memory.

The original tiles have a GEMM reduction followed by a paid RF epilogue.
Two independent tiles share one A or B DMA per reduction chunk, retain a
second accumulator, then execute their unchanged epilogues in tile order.
"""

import argparse
import copy
import json
from collections import defaultdict
from pathlib import Path

from .estimate import estimate_wave, program_records, validate_wave_capacity
from .hardware import validate
from .reuse_b import _tile
from .tool import sha, write


def _tiles(group):
    commands = group["commands"]
    starts = [index for index, command in enumerate(commands)
              if command.get("instruction", {}).get("op") == "fill"]
    if not starts or starts[0] != 0:
        return None
    parsed = []
    for index, start in enumerate(starts):
        end = starts[index + 1] if index + 1 < len(starts) else len(commands)
        segment = commands[start:end]
        if (not segment or segment[-1]["command"] != "run" or
                segment[-1].get("instruction", {}).get("op") != "store"):
            return None
        cursor = 1
        chunks = []
        while cursor + 3 < len(segment):
            first, second, wait, mma = segment[cursor:cursor + 4]
            if (first["command"] != "async" or second["command"] != "async" or
                    wait != {"command": "wait", "tokens":
                             [first["token"], second["token"]]} or
                    mma["command"] != "run" or
                    tuple(item.get("instruction", {}).get("op")
                          for item in (first, second, mma)) !=
                    ("load", "load", "mma")):
                break
            chunks.append((first, second, mma))
            cursor += 4
        if not chunks:
            return None
        epilogue = segment[cursor:]
        if (not epilogue or any(command["command"] != "run" or
                command.get("instruction", {}).get("op") not in
                ("load", "vector", "store")
                for command in epilogue) or
                any(command["instruction"]["op"] == "store"
                    for command in epilogue[:-1])):
            return None
        synthetic = dict(group, commands=[segment[0], *segment[1:cursor], segment[-1]])
        tile = _tile(synthetic)
        if tile is None:
            return None
        parsed.append({"source": segment, "chunks": chunks,
                       "epilogue": epilogue, "tile": tile})
    return parsed


def _key(entry, shared):
    tile = entry["tile"]
    side = 0 if shared == "a" else 1
    return (tile["signature"][:2],
            tuple((chunk[side]["tensor"],
                   tuple(sorted(chunk[side]["global"].items())),
                   tuple(sorted(chunk[side]["local"].items())),
                   chunk[2]["m"], chunk[2]["n"], chunk[2]["k"])
                  for chunk in tile["chunks"]))


def _disjoint(entries):
    outputs = {entry["tile"]["store"]["tensor"] for entry in entries}
    inputs = set()
    intervals = defaultdict(list)
    for entry in entries:
        tile = entry["tile"]
        intervals[tile["store"]["tensor"]].extend(tile["footprint"])
        for a, b, _ in tile["chunks"]:
            inputs.update((a["tensor"], b["tensor"]))
        for command in entry["epilogue"]:
            if command["instruction"]["op"] == "load":
                inputs.add(command["instruction"]["tensor"])
    if outputs & inputs:
        return False
    for addresses in intervals.values():
        addresses.sort()
        if any(left[1] >= right[0]
               for left, right in zip(addresses, addresses[1:])):
            return False
    return True


def _paired(first, second, shared, secondary):
    size = first["tile"]["fill"]["len"]
    commands = [copy.deepcopy(first["source"][0])]
    other_fill = copy.deepcopy(second["source"][0])
    other_fill["instruction"]["dst"] = secondary
    commands.append(other_fill)
    token = 0

    def async_load(instruction):
        nonlocal token
        token += 1
        commands.append({"command": "async", "token": token,
                         "instruction": copy.deepcopy(instruction)})
        return token

    for left, right in zip(first["tile"]["chunks"], second["tile"]["chunks"]):
        side = 0 if shared == "a" else 1
        common = async_load(left[side])
        first_other = async_load(left[1 - side])
        commands.append({"command": "wait", "tokens": [common, first_other]})
        commands.append({"command": "run", "instruction": copy.deepcopy(left[2])})
        second_other = async_load(right[1 - side])
        commands.append({"command": "wait", "tokens": [second_other]})
        second_mma = copy.deepcopy(right[2])
        second_mma["c"] = secondary
        commands.append({"command": "run", "instruction": second_mma})
    commands.extend(copy.deepcopy(first["epilogue"]))
    for original in second["epilogue"]:
        command = copy.deepcopy(original)
        instruction = command["instruction"]
        if instruction["op"] in ("load", "store"):
            view = instruction["local"]
            last = (view["base"] + (view["rows"] - 1) * view["row_stride"]
                    + (view["cols"] - 1) * view["col_stride"])
            if view["base"] < size:
                if last >= size:
                    raise ValueError("epilogue local view straddles accumulator")
                view["base"] += secondary
        elif instruction["op"] == "vector":
            if instruction["dst"] < size:
                if instruction["dst"] + instruction["len"] > size:
                    raise ValueError("epilogue vector destination straddles accumulator")
                instruction["dst"] += secondary
            for operand in (instruction["a"], instruction["b"]):
                if operand["kind"] == "reg" and operand["base"] < size:
                    if (operand["base"] +
                            (instruction["len"] - 1) * operand["stride"] >= size):
                        raise ValueError("epilogue vector source straddles accumulator")
                    operand["base"] += secondary
        commands.append(command)
    return commands


def _renumber(commands):
    seen = {}
    number = 0
    for command in commands:
        if command["command"] == "async":
            number += 1
            seen[command["token"]] = number
            command["token"] = number
        elif command["command"] == "wait":
            command["tokens"] = [seen[token] for token in command["tokens"]]
    return commands


def reuse_group(group, shared="b"):
    if shared not in ("a", "b"):
        raise ValueError("shared panel must be a or b")
    entries = _tiles(group)
    if entries is None or len(entries) < 2 or not _disjoint(entries):
        return group, 0
    buckets = defaultdict(list)
    order = []
    for entry in entries:
        key = _key(entry, shared)
        if key not in buckets:
            order.append(key)
        buckets[key].append(entry)
    if not any(len(buckets[key]) > 1 for key in order):
        return group, 0
    secondary = group["rf_kib"] * 256
    commands = []
    removed = 0
    largest = group["rf_kib"]
    for key in order:
        bucket = buckets[key]
        for offset in range(0, len(bucket), 2):
            if offset + 1 == len(bucket):
                commands.extend(copy.deepcopy(bucket[offset]["source"]))
                continue
            first, second = bucket[offset:offset + 2]
            size = first["tile"]["fill"]["len"]
            largest = max(largest, (secondary + size + 255) // 256)
            commands.extend(_paired(first, second, shared, secondary))
            removed += len(first["tile"]["chunks"])
    return dict(group, rf_kib=largest, commands=_renumber(commands)), removed


def screen(source, hardware, base_cycles, shared="b", output=None):
    validate(hardware)
    records = program_records(source)
    next(records)
    cache = {}
    result = {"scope": "two-output fused multi-K GEMM panel reuse",
              "shared_panel": shared, "source_sha256": sha(source),
              "estimator_sha256": sha(Path(__file__).with_name("estimate.py")),
              "model_sha256": sha(Path(__file__)), "hardware": hardware,
              "base_cycles": base_cycles, "waves": 0, "changed_waves": 0,
              "accepted_waves": [], "removed_panel_loads": 0,
              "saved_cycles": 0, "candidate_program_generated": False,
              "numerical_correctness": "not_checked", "official_score": None}
    for record in records:
        if record["record"] != "wave":
            continue
        index = result["waves"]
        result["waves"] += 1
        groups = []
        removed = 0
        for group in record["groups"]:
            candidate, count = reuse_group(group, shared)
            groups.append(candidate)
            removed += count
        if not removed:
            continue
        try:
            validate_wave_capacity(groups, hardware)
        except ValueError:
            continue
        original = estimate_wave(record["groups"], hardware, cache)
        replacement = estimate_wave(groups, hardware, cache)
        result["changed_waves"] += 1
        if replacement < original:
            result["accepted_waves"].append({"wave": index,
                "old_cycles": original, "new_cycles": replacement,
                "saving": original - replacement,
                "removed_panel_loads": removed})
            result["saved_cycles"] += original - replacement
            result["removed_panel_loads"] += removed
    result["predicted_cycles"] = base_cycles - result["saved_cycles"]
    if output is not None:
        Path(output).parent.mkdir(parents=True, exist_ok=True)
        write(output, result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("hardware", type=Path)
    parser.add_argument("base_cycles", type=int)
    parser.add_argument("output", type=Path)
    parser.add_argument("--shared", choices=("a", "b"), default="b")
    args = parser.parse_args()
    document = json.loads(args.hardware.read_text())
    result = screen(args.source, document.get("hardware", document),
                    args.base_cycles, args.shared, args.output)
    print(json.dumps({key: result[key] for key in
        ("shared_panel", "changed_waves", "removed_panel_loads",
         "saved_cycles", "predicted_cycles")}, indent=2))


if __name__ == "__main__":
    main()
