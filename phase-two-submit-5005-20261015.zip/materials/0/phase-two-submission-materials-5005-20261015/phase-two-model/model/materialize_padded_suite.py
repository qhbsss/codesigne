"""Materialize one padded-K suite after its five-case model gate passes."""

import argparse
import json
import math
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

from .estimate import estimate_program
from .hardware import area, validate
from .pad_transposed_k import write_expanded
from .tool import SCORE_CASES, STARTER, sha, write


def materialize(base_path, screen_path, output):
    base = json.loads(Path(base_path).read_text())
    screen = json.loads(Path(screen_path).read_text())
    hardware = screen["hardware"]
    validate(hardware)
    claimed = screen["predicted_cycles"]
    if set(claimed) != set(SCORE_CASES):
        raise ValueError("screen lacks five model cycles")
    score = 1000 * math.exp(sum(weight * math.log(reference / claimed[case])
                                for case, (reference, weight) in SCORE_CASES.items()))
    if score < 5000 or not math.isclose(score, screen["conditional_predicted_score"], rel_tol=1e-10):
        raise ValueError("five-case model gate did not pass")
    output = Path(output)
    output.mkdir(parents=True, exist_ok=False)
    programs = output / "programs"
    programs.mkdir()
    manifest = {"hardware": hardware, "area_au": area(hardware),
                "screen_sha256": sha(screen_path), "source_sha256": {},
                "program_sha256": {}, "padding": {}, "screen_score": score}
    for case in SCORE_CASES:
        selected = base["selected_programs"][case]
        source = Path(selected["program"])
        if sha(source) != selected["program_sha256"]:
            raise ValueError(f"source changed: {case}")
        destination = programs / f"{case}.jsonl"
        if case in ("w-p", "a-p"):
            with source.open("rb") as reader, destination.open("xb") as writer:
                header = json.loads(reader.readline())
                header["hardware"] = hardware
                writer.write(json.dumps(header, separators=(",", ":")).encode() + b"\n")
                shutil.copyfileobj(reader, writer)
        else:
            with tempfile.TemporaryDirectory(prefix=f"phase-two-padk-{case}-") as temp:
                expanded = Path(temp) / "expanded.jsonl"
                manifest["padding"][case] = write_expanded(source, expanded, hardware)
                subprocess.run([sys.executable, str(STARTER / "tools/compact_program.py"),
                                str(expanded), str(destination)], check=True)
        manifest["source_sha256"][case] = selected["program_sha256"]
        manifest["program_sha256"][case] = sha(destination)
    exact_cycles = {case: estimate_program(programs / f"{case}.jsonl")["cycles"]
                    for case in SCORE_CASES}
    exact_score = 1000 * math.exp(sum(weight * math.log(reference / exact_cycles[case])
                                      for case, (reference, weight) in SCORE_CASES.items()))
    manifest.update(exact_model_cycles=exact_cycles, exact_model_score=exact_score,
                    grade_allowed=exact_score >= 5000, official_score=None)
    write(output / "manifest.json", manifest)
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("base", type=Path)
    parser.add_argument("screen", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    result = materialize(args.base, args.screen, args.output)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
