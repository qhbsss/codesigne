"""Price decode GEMM prefetch as paid wave deltas before writing programs."""

import argparse
import json
import math
from pathlib import Path

from .estimate import estimate_wave, program_records, validate_wave_capacity
from .pipeline_gemm import _pipeline_group
from .tool import SCORE_CASES, sha, write


DECODE_CASES = ("w-d1", "w-d16", "w-d4l")


def _read(path):
    return json.loads(Path(path).read_text())


def _save(path, value):
    temporary = path.with_suffix(".json.tmp")
    write(temporary, value)
    temporary.replace(path)


def _price_case(source, hardware):
    records = program_records(source)
    next(records)
    cache = {}
    stats = {"waves": 0, "changed_waves": 0, "accepted_tiles": 0,
             "rejected_tiles": 0, "pipelined_chunks": 0, "delta_cycles": 0}
    for record in records:
        if record["record"] != "wave":
            continue
        stats["waves"] += 1
        original = record["groups"]
        selected = list(original)
        changed = False
        for index, group in enumerate(original):
            transformed, tiles, chunks = _pipeline_group(group)
            if not tiles:
                continue
            selected[index] = transformed
            try:
                validate_wave_capacity(selected, hardware)
            except ValueError:
                selected[index] = group
                stats["rejected_tiles"] += tiles
                continue
            changed = True
            stats["accepted_tiles"] += tiles
            stats["pipelined_chunks"] += chunks
        if changed:
            original_cycles = estimate_wave(original, hardware, cache)
            transformed_cycles = estimate_wave(selected, hardware, cache)
            stats["delta_cycles"] += transformed_cycles - original_cycles
            stats["changed_waves"] += 1
    return stats


def screen(base_solution, hardware_spec, hardware_screen, hardware_name, output):
    base_solution, hardware_spec = Path(base_solution), Path(hardware_spec)
    hardware_screen, output = Path(hardware_screen), Path(output)
    base, spec, prior = map(_read, (base_solution, hardware_spec, hardware_screen))
    if prior["estimator_sha256"] != sha(Path(__file__).with_name("estimate.py")):
        raise ValueError("hardware screen used a different cycle estimator")
    if prior["base_solution_sha256"] != sha(base_solution):
        raise ValueError("hardware screen used a different program portfolio")
    choices = [option for option in spec["hardware_options"]
               if option["name"] == hardware_name]
    estimates = [result for result in prior["results"]
                 if result["name"] == hardware_name]
    if len(choices) != 1 or len(estimates) != 1 or not estimates[0]["completed"]:
        raise ValueError("hardware choice lacks a completed five-case estimate")
    hardware = choices[0]["hardware"]
    original_cycles = estimates[0]["predicted_cycles"]
    identity = {"base_solution_sha256": sha(base_solution),
                "hardware_spec_sha256": sha(hardware_spec),
                "hardware_screen_sha256": sha(hardware_screen),
                "estimator_sha256": prior["estimator_sha256"],
                "pipeline_sha256": sha(Path(__file__).with_name("pipeline_gemm.py")),
                "hardware_name": hardware_name}
    output.mkdir(parents=True, exist_ok=True)
    checkpoint = output / "progress.json"
    progress = _read(checkpoint) if checkpoint.exists() else {**identity, "cases": {}}
    if any(progress.get(key) != value for key, value in identity.items()):
        raise ValueError("pipeline screen checkpoint has changed inputs")
    for case in DECODE_CASES:
        if case in progress["cases"]:
            continue
        option = base["selected_programs"][case]
        source = Path(option["program"])
        if sha(source) != option["program_sha256"]:
            raise ValueError(f"source program changed: {case}")
        stats = _price_case(source, hardware)
        if sha(source) != option["program_sha256"]:
            raise ValueError(f"source program changed during screen: {case}")
        progress["cases"][case] = {"source_program_sha256": option["program_sha256"],
                                   "original_cycles": original_cycles[case],
                                   "pipeline_cycles": original_cycles[case] + stats["delta_cycles"],
                                   **stats}
        _save(checkpoint, progress)
    selected = {case: min(original_cycles[case], progress["cases"][case]["pipeline_cycles"])
                if case in DECODE_CASES else original_cycles[case]
                for case in SCORE_CASES}
    score = 1000 * math.exp(sum(weight * math.log(reference / selected[case])
                for case, (reference, weight) in SCORE_CASES.items()))
    result = {**identity, "scope": "fixed prefill bodies and decode GEMM pipeline choice",
              "cases": progress["cases"], "selected_predicted_cycles": selected,
              "conditional_predicted_score": score,
              "target_score": 5000, "meets_grade_gate": score >= 5000,
              "official_score": None, "numerical_correctness": "not_checked"}
    _save(output / "screen.json", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("base_solution", type=Path)
    parser.add_argument("hardware_spec", type=Path)
    parser.add_argument("hardware_screen", type=Path)
    parser.add_argument("hardware_name")
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    print(json.dumps(screen(args.base_solution, args.hardware_spec,
                            args.hardware_screen, args.hardware_name, args.output), indent=2))


if __name__ == "__main__":
    main()
