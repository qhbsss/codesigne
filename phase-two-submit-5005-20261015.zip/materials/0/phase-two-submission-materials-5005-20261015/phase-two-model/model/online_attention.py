"""Replace materialized causal scores with paid, row-tiled online softmax."""

import argparse
import json
import math
from pathlib import Path

from .causal import _score_tensors
from .estimate import program_records, validate_wave_capacity


def _view(base, rows, cols, row_stride, col_stride=1):
    return {"base": base, "rows": rows, "cols": cols,
            "row_stride": row_stride, "col_stride": col_stride}


def _reg(base, stride=1):
    return {"kind": "reg", "base": base, "stride": stride}


def _imm(value):
    return {"kind": "imm", "value": value}


def _emit(commands, operation, **arguments):
    commands.append({"command": "run", "instruction": {"op": operation, **arguments}})


def _vector(commands, kind, destination, length, left, right):
    _emit(commands, "vector", kind=kind, dst=destination, len=length, a=left, b=right)


def _load(commands, tensor, global_view, local_view):
    _emit(commands, "load", tensor=tensor, **{"global": global_view, "local": local_view})


def _online_group(start, rows, context, head_index, hidden_width, head_width,
                  key_block, query_tensor, key_tensor, value_tensor, output_tensor,
                  key_layout, sm):
    query_base = 0
    output_base = query_base + rows * head_width
    scores_base = output_base + rows * head_width
    keys_base = scores_base + rows * key_block
    values_base = keys_base + head_width * key_block
    max_base = values_base + key_block * head_width
    sum_base = max_base + rows
    temporary_base = sum_base + rows
    scratch_base = temporary_base + 8
    words = scratch_base + max(key_block, 2)
    commands = []
    _load(commands, query_tensor,
          _view(start * 3 * hidden_width + head_index * head_width,
                rows, head_width, 3 * hidden_width),
          _view(query_base, rows, head_width, head_width))
    _emit(commands, "fill", dst=output_base, len=rows * head_width, value=0.0)
    _emit(commands, "fill", dst=max_base, len=rows, value=-1e30)
    _emit(commands, "fill", dst=sum_base, len=rows, value=0.0)
    for begin in range(0, min(start + rows, context), key_block):
        count = min(key_block, context - begin, start + rows - begin)
        key_view = (_view(head_index * head_width * context + begin,
                          head_width, count, context)
                    if key_layout == "transposed" else
                    _view(begin * hidden_width + head_index * head_width,
                          head_width, count, 1, hidden_width))
        _load(commands, key_tensor,
              key_view,
              _view(keys_base, head_width, count, count))
        _load(commands, value_tensor,
              _view(begin * hidden_width + head_index * head_width,
                    count, head_width, hidden_width),
              _view(values_base, count, head_width, head_width))
        _emit(commands, "fill", dst=scores_base, len=rows * count, value=0.0)
        _emit(commands, "mma", a=query_base, b=keys_base, c=scores_base,
              m=rows, n=count, k=head_width)
        _vector(commands, "mul", scores_base, rows * count,
                _reg(scores_base), _imm(1.0 / math.sqrt(head_width)))
        for row in range(rows):
            score_row = scores_base + row * count
            valid = min(count, max(0, start + row + 1 - begin))
            if valid < count:
                _emit(commands, "fill", dst=score_row + valid,
                      len=count - valid, value=-1e30)
            _emit(commands, "reduce", scratch=scratch_base, dst=temporary_base,
                  src=score_row, len=count, max=True)
            _vector(commands, "add", temporary_base + 1, 1,
                    _reg(max_base + row, 0), _imm(0.0))
            _emit(commands, "reduce", scratch=scratch_base, dst=temporary_base + 2,
                  src=temporary_base, len=2, max=True)
            _vector(commands, "sub", temporary_base + 3, 1,
                    _reg(max_base + row, 0), _reg(temporary_base + 2, 0))
            _vector(commands, "exp", temporary_base + 3, 1,
                    _reg(temporary_base + 3, 0), _imm(0.0))
            _vector(commands, "sub", score_row, count,
                    _reg(score_row), _reg(temporary_base + 2, 0))
            _vector(commands, "exp", score_row, count, _reg(score_row), _imm(0.0))
            _emit(commands, "reduce", scratch=scratch_base, dst=temporary_base + 4,
                  src=score_row, len=count, max=False)
            _vector(commands, "mul", sum_base + row, 1,
                    _reg(sum_base + row, 0), _reg(temporary_base + 3, 0))
            _vector(commands, "add", sum_base + row, 1,
                    _reg(sum_base + row, 0), _reg(temporary_base + 4, 0))
            _vector(commands, "mul", output_base + row * head_width, head_width,
                    _reg(output_base + row * head_width), _reg(temporary_base + 3, 0))
            _vector(commands, "add", max_base + row, 1,
                    _reg(temporary_base + 2, 0), _imm(0.0))
        _emit(commands, "mma", a=scores_base, b=values_base, c=output_base,
              m=rows, n=head_width, k=count)
    for row in range(rows):
        _vector(commands, "div", output_base + row * head_width, head_width,
                _reg(output_base + row * head_width), _reg(sum_base + row, 0))
    _emit(commands, "store", tensor=output_tensor,
          **{"global": _view(start * hidden_width + head_index * head_width,
                            rows, head_width, hidden_width),
             "local": _view(output_base, rows, head_width, head_width)})
    return {"sm": sm, "rf_kib": (words + 255) // 256, "sh_kib": 0,
            "commands": commands}


def _online_waves(header, query_tensor, key_tensor, value_tensor, output_tensor,
                  key_layout, row_tile, key_block):
    shape = header["shape"]
    context = shape["prefill"]
    hidden_width = shape["d"]
    head_width = hidden_width // shape["heads"]
    sms = header["hardware"]["sms"]
    if head_width > 64 or key_block > 64 or row_tile > 64:
        raise ValueError("online template only supports head, row, key widths <=64")
    for head_index in range(shape["heads"]):
        starts = list(range(0, context, row_tile))
        for offset in range(0, len(starts), sms):
            groups = [
                _online_group(start, min(row_tile, context - start), context, head_index,
                              hidden_width, head_width, key_block, query_tensor, key_tensor,
                              value_tensor, output_tensor, key_layout, sm)
                for sm, start in enumerate(starts[offset:offset + sms])
            ]
            validate_wave_capacity(groups, header["hardware"])
            yield {"record": "wave", "groups": groups}


def online_attention_program(source, destination, row_tile=16, key_block=64,
                             algorithm="online"):
    records = program_records(source)
    header = next(records)
    if (header["decode"] or header["batch"] != 1 or
            row_tile < 1 or key_block < 1 or
            header["shape"]["d"] % header["shape"]["heads"]):
        raise ValueError("online attention requires batch-one prefill and positive tiles")
    shape = header["shape"]
    score_ids = _score_tensors(source, shape["prefill"], shape["heads"], shape["layers"])
    if algorithm == "online":
        wave_factory = _online_waves
    elif algorithm == "rf":
        from .rf_softmax import rf_waves
        wave_factory = rf_waves
    elif algorithm == "two-pass":
        from .two_pass_attention import two_pass_waves
        wave_factory = two_pass_waves
    else:
        raise ValueError(f"unknown attention algorithm: {algorithm}")
    tensors = []
    replaced = new_waves = stages = 0
    active = None
    with Path(destination).open("x") as writer:
        writer.write(json.dumps(header, separators=(",", ":")) + "\n")
        for record in records:
            if record["record"] in ("input", "alloc"):
                tensors.append(record["len"])
            if record["record"] == "wave":
                reads = set()
                writes = set()
                for group in record["groups"]:
                    for command in group["commands"]:
                        instruction = command.get("instruction", {})
                        if instruction.get("op") == "load":
                            reads.add(instruction["tensor"])
                        elif instruction.get("op") == "store":
                            writes.add(instruction["tensor"])
                if (reads | writes) & score_ids:
                    if active is None:
                        if not writes & score_ids:
                            raise ValueError("attention score read precedes QK")
                        non_score = reads - score_ids
                        query = [item for item in non_score
                                 if tensors[item] == 3 * shape["prefill"] * shape["d"]]
                        keys = non_score - set(query)
                        if len(query) != 1 or len(keys) != 1:
                            raise ValueError("could not identify QKV and transposed keys")
                        key_tensor = keys.pop()
                        key_views = {tuple(instruction["global"][field]
                                           for field in ("row_stride", "col_stride"))
                                     for group in record["groups"]
                                     for command in group["commands"]
                                     for instruction in [command.get("instruction", {})]
                                     if (instruction.get("op") == "load" and
                                         instruction["tensor"] == key_tensor)}
                        if key_views == {(shape["prefill"], 1)}:
                            key_layout = "transposed"
                        elif key_views == {(1, shape["d"])}:
                            key_layout = "strided"
                        else:
                            raise ValueError(f"unsupported key layout: {key_views}")
                        active = {"query": query[0], "key": key_tensor,
                                  "key_layout": key_layout,
                                  "value": None, "output": None}
                    remainder = reads - score_ids
                    output = writes - score_ids
                    if output:
                        if len(remainder) != 1 or len(output) != 1:
                            raise ValueError("unsupported AV output layout")
                        active["value"] = remainder.pop()
                        active["output"] = output.pop()
                    replaced += 1
                    continue
            if active is not None:
                if active["value"] is None or active["output"] is None:
                    raise ValueError("incomplete QK/softmax/AV attention stage")
                for fused in wave_factory(header, active["query"], active["key"],
                                          active["value"], active["output"],
                                          active["key_layout"], row_tile, key_block):
                    writer.write(json.dumps(fused, separators=(",", ":")) + "\n")
                    new_waves += 1
                stages += 1
                active = None
            writer.write(json.dumps(record, separators=(",", ":")) + "\n")
            if record["record"] == "release":
                if record["tensor"] != len(tensors) - 1:
                    raise ValueError("unexpected tensor release order")
                tensors.pop()
    if active is not None or stages != shape["layers"]:
        raise ValueError("missing complete attention stages")
    return {"stages": stages, "replaced_waves": replaced, "new_waves": new_waves,
            "row_tile": row_tile, "key_block": key_block, "algorithm": algorithm}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("--row-tile", type=int, default=16)
    parser.add_argument("--key-block", type=int, default=64)
    parser.add_argument("--algorithm", choices=("online", "rf", "two-pass"),
                        default="online")
    args = parser.parse_args()
    print(json.dumps(online_attention_program(args.source, args.destination,
                                              args.row_tile, args.key_block,
                                              args.algorithm), indent=2))


if __name__ == "__main__":
    main()
