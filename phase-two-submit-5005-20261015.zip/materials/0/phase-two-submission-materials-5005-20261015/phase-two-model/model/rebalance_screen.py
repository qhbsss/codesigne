"""Screen smaller RF and wider compute by splitting oversized waves in memory."""

import argparse
import json
import math
from pathlib import Path

from .estimate import estimate_wave, program_records, validate_wave_capacity
from .hardware import area, validate
from .tool import SCORE_CASES, sha, write


def split_wave(groups, hardware):
    """Place each original group on its pinned SM in an ordered wave round."""
    try:
        validate_wave_capacity(groups, hardware)
        return [groups]
    except ValueError:
        pass
    rounds = []
    last_round = {}
    for group in groups:
        validate_wave_capacity([group], hardware)
        sm = group["sm"]
        start = last_round.get(sm, 0)
        placed = False
        for index in range(start, len(rounds)):
            selected = rounds[index] + [group]
            try:
                validate_wave_capacity(selected, hardware)
            except ValueError:
                continue
            rounds[index].append(group)
            last_round[sm] = index
            placed = True
            break
        if not placed:
            rounds.append([group])
            last_round[sm] = len(rounds) - 1
    return rounds


def estimate_split_program(source, hardware):
    records = program_records(source)
    next(records)
    cache = {}
    result = {"cycles": 0, "source_waves": 0, "scheduled_waves": 0,
              "split_waves": 0, "commits": 0}
    for record in records:
        if record["record"] == "wave":
            result["source_waves"] += 1
            rounds = split_wave(record["groups"], hardware)
            result["scheduled_waves"] += len(rounds)
            result["split_waves"] += len(rounds) > 1
            result["cycles"] += sum(estimate_wave(groups, hardware, cache)
                                    for groups in rounds)
        elif record["record"] == "commit":
            result["commits"] += 1
            result["cycles"] += 1
        elif record["record"] not in ("input", "alloc", "release"):
            raise ValueError("unknown program record")
    return result


def screen(spec_path, output):
    spec_path, output = Path(spec_path), Path(output)
    spec = json.loads(spec_path.read_text())
    if set(spec) != {"base_solution", "target_score", "hardware_options"}:
        raise ValueError("invalid rebalance screen spec")
    if spec["target_score"] < 5000:
        raise ValueError("the grade gate must be at least 5000")
    base = json.loads(Path(spec["base_solution"]).read_text())
    output.mkdir(parents=True, exist_ok=True)
    identity = {"spec_sha256": sha(spec_path),
                "base_solution_sha256": sha(spec["base_solution"]),
                "estimator_sha256": sha(Path(__file__).with_name("estimate.py"))}
    progress_path = output / "progress.json"
    progress = (json.loads(progress_path.read_text()) if progress_path.exists() else
                {**identity, "cases": {}})
    if any(progress.get(key) != value for key, value in identity.items()):
        raise ValueError("rebalance screen inputs changed")
    for option in spec["hardware_options"]:
        name, hardware = option["name"], option["hardware"]
        validate(hardware)
        if hardware["sms"] != 8:
            raise ValueError("this screen preserves the eight pinned SMs")
        for case in SCORE_CASES:
            key = f"{name}:{case}"
            if key in progress["cases"]:
                continue
            selected = base["selected_programs"][case]
            if sha(selected["program"]) != selected["program_sha256"]:
                raise ValueError(f"source program changed: {case}")
            estimate = estimate_split_program(selected["program"], hardware)
            progress["cases"][key] = {"source_program_sha256": selected["program_sha256"],
                                      **estimate}
            write(progress_path, progress)
            print(name, case, estimate["cycles"], flush=True)
    choices = []
    for option in spec["hardware_options"]:
        name = option["name"]
        entries = {case: progress["cases"][f"{name}:{case}"] for case in SCORE_CASES}
        score = 1000 * math.exp(sum(weight * math.log(reference / entries[case]["cycles"])
                                    for case, (reference, weight) in SCORE_CASES.items()))
        choices.append({"name": name, "hardware": option["hardware"],
                        "area_au": area(option["hardware"]),
                        "cases": entries, "conditional_predicted_score": score,
                        "meets_grade_gate": score >= spec["target_score"]})
    result = {**identity, "target_score": spec["target_score"],
              "scope": "fixed expanded command bodies with virtual wave splitting",
              "choices": choices, "official_score": None,
              "numerical_correctness": "not_checked"}
    write(output / "screen.json", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("spec", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    screen(args.spec, args.output)


if __name__ == "__main__":
    main()
