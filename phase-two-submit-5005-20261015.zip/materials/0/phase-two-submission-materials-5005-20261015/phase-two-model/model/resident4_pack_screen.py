"""Screen packing three independent two-resident waves into two or fewer waves."""

import argparse
import heapq
import json
import math
from pathlib import Path

from .estimate import estimate_wave, program_records, validate_wave_capacity
from .merge import MAX_COMMANDS, _footprint, _overlaps, _pipeline_footprint
from .tool import SCORE_CASES, sha, write


def _pack(records, hardware):
    output = []
    current = []
    resources = {}
    commands = 0
    for record in records:
        for group in record["groups"]:
            sm = group["sm"]
            rf, sh, slots = resources.get(sm, (0, 0, 0))
            count = len(group["commands"])
            if (rf + group["rf_kib"] > hardware["rf_kib"] or
                    sh + group["sh_kib"] > hardware["sh_kib"] or
                    slots + 1 > hardware["resident_groups"] or
                    commands + count > MAX_COMMANDS):
                validate_wave_capacity(current, hardware)
                output.append(current)
                current = []
                resources = {}
                commands = 0
                rf = sh = slots = 0
            current.append(group)
            resources[sm] = (rf + group["rf_kib"], sh + group["sh_kib"], slots + 1)
            commands += count
    if current:
        validate_wave_capacity(current, hardware)
        output.append(current)
    return output


def _access_footprint(record):
    """Keep all reads, including tensors written only by another wave."""
    key = _footprint(record)
    detailed = _pipeline_footprint(record)
    if key is None or detailed is None:
        return None
    intervals = {}
    for kind in ("reads", "writes"):
        table = {}
        for group in detailed["intervals"]:
            for tensor, rows in group[kind].items():
                table.setdefault(tensor, []).extend(rows)
        for rows in table.values():
            rows.sort()
        intervals[kind] = table
    return {"key": key["key"], "intervals": intervals}


def _independent_triple(entries):
    if len(entries) != 3:
        return False
    footprints = [entry[2] for entry in entries]
    if any(item is None for item in footprints):
        return False
    if any(item["key"][0] != footprints[0]["key"][0] or
           item["key"][4] != footprints[0]["key"][4] for item in footprints[1:]):
        return False
    aggregate = footprints[0]["intervals"]
    for item in footprints[1:]:
        newer = item["intervals"]
        for tensor in aggregate["writes"].keys() | newer["writes"].keys():
            if (_overlaps(aggregate["writes"].get(tensor, []), newer["writes"].get(tensor, [])) or
                    _overlaps(aggregate["writes"].get(tensor, []), newer["reads"].get(tensor, [])) or
                    _overlaps(aggregate["reads"].get(tensor, []), newer["writes"].get(tensor, []))):
                return False
        aggregate = {kind: {tensor: list(heapq.merge(aggregate[kind].get(tensor, []),
                                                  newer[kind].get(tensor, [])))
                            for tensor in aggregate[kind].keys() | newer[kind].keys()}
                     for kind in ("reads", "writes")}
    return True


def screen(source, case, manifest_path, hardware_screen_path, checkpoint):
    source, manifest_path, hardware_screen_path, checkpoint = map(
        Path, (source, manifest_path, hardware_screen_path, checkpoint))
    checkpoint.parent.mkdir(parents=True, exist_ok=True)
    manifest = json.loads(manifest_path.read_text())
    hardware_screen = json.loads(hardware_screen_path.read_text())
    selected, = [item for item in hardware_screen["results"]
                 if item["name"] == "resident4_sfu17"]
    hardware = json.loads(Path("runs/hw-resident4-20261014/spec.json").read_text())[
        "hardware_options"][0]["hardware"]
    if (sha(source) != manifest["program_sha256"][case] or
            hardware_screen["source_program_sha256"][case] != sha(source) or
            next(program_records(source))["hardware"] != manifest["hardware"] or
            not selected["meets_grade_gate"]):
        raise ValueError("source, hardware, or full-five model gate changed")
    identity = {"case": case, "source_sha256": sha(source),
                "manifest_sha256": sha(manifest_path),
                "hardware_screen_sha256": sha(hardware_screen_path),
                "screen_code_sha256": sha(__file__)}
    state = json.loads(checkpoint.read_text()) if checkpoint.exists() else {**identity, "rows": []}
    if any(state.get(key) != value for key, value in identity.items()):
        raise ValueError("checkpoint identity changed")
    rows = state["rows"]
    skipped = sum(row["source_waves"] for row in rows)
    cache = {}
    pending = []
    wave_index = 0

    def process(flush=False):
        nonlocal pending
        while pending and (flush or len(pending) >= 3):
            choice = None
            if len(pending) >= 3 and _independent_triple(pending[:3]):
                packed = _pack([entry[0] for entry in pending[:3]], hardware)
                if len(packed) < 3:
                    old_cost = sum(entry[1] for entry in pending[:3])
                    new_cost = sum(estimate_wave(groups, hardware, cache) for groups in packed)
                    if new_cost < old_cost:
                        choice = {"source_start": pending[0][3], "source_waves": 3,
                                  "packed_waves": len(packed), "base": old_cost,
                                  "cycles": new_cost}
            if choice is None:
                entry = pending[0]
                choice = {"source_start": entry[3], "source_waves": 1,
                          "packed_waves": 1, "base": entry[1], "cycles": entry[1]}
            rows.append(choice)
            del pending[:choice["source_waves"]]
            if len(rows) % 8 == 0:
                write(checkpoint, state)

    for record in program_records(source):
        if record.get("record") != "wave":
            process(flush=True)
            continue
        if wave_index < skipped:
            wave_index += 1
            continue
        baseline = estimate_wave(record["groups"], hardware, cache)
        pending.append((record, baseline, _access_footprint(record), wave_index))
        wave_index += 1
        process()
    process(flush=True)
    write(checkpoint, state)
    cycles = dict(selected["predicted_cycles"])
    cycles[case] += sum(row["cycles"] - row["base"] for row in rows)
    score = 1000 * math.exp(sum(weight * math.log(reference / cycles[name])
        for name, (reference, weight) in SCORE_CASES.items()))
    result = {**identity, "checkpoint_sha256": sha(checkpoint),
              "source_waves": sum(row["source_waves"] for row in rows),
              "packed_waves": sum(row["packed_waves"] for row in rows),
              "selected_triples": sum(row["source_waves"] == 3 for row in rows),
              "cycle_delta": cycles[case] - selected["predicted_cycles"][case],
              "five_case_model_cycles": cycles, "five_case_model_score": score,
              "meets_grade_gate": score >= 5000, "candidate_program_generated": False,
              "official_score": None}
    write(checkpoint.with_name("screen.json"), result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("case")
    parser.add_argument("manifest", type=Path)
    parser.add_argument("hardware_screen", type=Path)
    parser.add_argument("checkpoint", type=Path)
    args = parser.parse_args()
    print(json.dumps(screen(args.source, args.case, args.manifest,
                            args.hardware_screen, args.checkpoint), indent=2))


if __name__ == "__main__":
    main()
