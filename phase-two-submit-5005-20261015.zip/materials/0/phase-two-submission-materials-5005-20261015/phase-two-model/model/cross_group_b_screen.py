"""Model merging two same-SM GEMM groups that load identical B panels."""

import argparse
import copy
import json
import math
from collections import defaultdict
from pathlib import Path

from .estimate import estimate_wave, program_records, validate_wave_capacity
from .reuse_b_within import _renumber
from .tool import SCORE_CASES, sha, write


def _tile(segment):
    if (len(segment) < 8 or segment[0].get("instruction", {}).get("op") != "fill" or
            segment[-1].get("instruction", {}).get("op") != "store"):
        return None
    fill, store = segment[0]["instruction"], segment[-1]["instruction"]
    chunks = []
    cursor = 1
    while cursor + 4 < len(segment):
        first, low, high, wait, mma = segment[cursor:cursor + 5]
        if (tuple(item["command"] for item in (first, low, high, wait, mma)) !=
                ("async", "async", "async", "wait", "run") or
                tuple(item.get("instruction", {}).get("op") for item in
                      (first, low, high, mma)) != ("load", "load", "load", "mma") or
                wait["tokens"] != [first["token"], low["token"], high["token"]]):
            break
        a, b0, b1, op = (item["instruction"] for item in (first, low, high, mma))
        if (a["local"]["base"] != op["a"] or b0["local"]["base"] != op["b"] or
                b0["tensor"] != b1["tensor"] or
                b0["local"]["base"] + b0["local"]["rows"] * b0["local"]["cols"] !=
                b1["local"]["base"] or
                b0["global"]["rows"] + b1["global"]["rows"] != op["k"] or
                b0["global"]["cols"] != op["n"] or b1["global"]["cols"] != op["n"] or
                op["c"] != fill["dst"] or fill["len"] != op["m"] * op["n"]):
            return None
        chunks.append((first, low, high, mma))
        cursor += 5
    if not chunks or any(item["command"] != "run" or
                         item.get("instruction", {}).get("op") not in ("load", "vector")
                         for item in segment[cursor:-1]):
        return None
    if store["local"]["base"] != fill["dst"]:
        return None
    signature = tuple((b0["instruction"]["tensor"],
                       tuple(sorted(b0["instruction"]["global"].items())),
                       b1["instruction"]["tensor"],
                       tuple(sorted(b1["instruction"]["global"].items())),
                       mma["instruction"]["m"], mma["instruction"]["n"],
                       mma["instruction"]["k"])
                      for _, b0, b1, mma in chunks)
    return {"source": segment, "fill": fill, "store": store,
            "chunks": chunks, "epilogue": segment[cursor:-1],
            "signature": signature}


def _tiles(group):
    tiles = []
    start = 0
    for index, command in enumerate(group["commands"]):
        if command.get("instruction", {}).get("op") != "store":
            continue
        entry = _tile(group["commands"][start:index + 1])
        if entry is None:
            return None
        tiles.append(entry)
        start = index + 1
    return tiles if tiles and start == len(group["commands"]) else None


def _safe_groups(groups):
    reads = set()
    writes = defaultdict(list)
    for group in groups:
        for command in group["commands"]:
            instruction = command.get("instruction", {})
            op = instruction.get("op")
            if op == "load":
                reads.add(instruction["tensor"])
            elif op == "store":
                view = instruction["global"]
                if view["col_stride"] != 1 or view["row_stride"] < view["cols"]:
                    return False
                for row in range(view["rows"]):
                    start = view["base"] + row * view["row_stride"]
                    writes[instruction["tensor"]].append((start, start + view["cols"] - 1))
    if reads & writes.keys():
        return False
    for intervals in writes.values():
        intervals.sort()
        if any(left[1] >= right[0] for left, right in zip(intervals, intervals[1:])):
            return False
    return True


def _shift_epilogue(command, secondary, size):
    copied = copy.deepcopy(command)
    instruction = copied["instruction"]
    if instruction["op"] in ("load", "store"):
        view = instruction["local"]
        end = view["base"] + (view["rows"] - 1) * view["row_stride"] + (
            view["cols"] - 1) * view["col_stride"] + 1
        if view["base"] < size:
            if end > size:
                raise ValueError("epilogue view crosses accumulator boundary")
            view["base"] += secondary
    elif instruction["op"] == "vector":
        if instruction["dst"] < size:
            if instruction["dst"] + instruction["len"] > size:
                raise ValueError("vector result crosses accumulator boundary")
            instruction["dst"] += secondary
        for operand in (instruction["a"], instruction["b"]):
            if operand["kind"] == "reg" and operand["base"] < size:
                if operand["base"] + (instruction["len"] - 1) * operand["stride"] >= size:
                    raise ValueError("vector input crosses accumulator boundary")
                operand["base"] += secondary
    return copied


def _paired(left, right, secondary):
    size = left["fill"]["len"]
    if size != right["fill"]["len"] or len(left["chunks"]) != len(right["chunks"]):
        raise ValueError("paired GEMM tiles differ in shape")
    commands = [copy.deepcopy(left["source"][0])]
    second_fill = copy.deepcopy(right["source"][0])
    second_fill["instruction"]["dst"] += secondary
    commands.append(second_fill)
    for left_chunk, right_chunk in zip(left["chunks"], right["chunks"]):
        left_a, low, high, left_mma = left_chunk
        right_a, _, _, right_mma = right_chunk
        copied_a = copy.deepcopy(right_a)
        copied_a["instruction"]["local"]["base"] += secondary
        copied_a["token"] += 1000000
        commands.extend((copy.deepcopy(left_a), copy.deepcopy(low), copy.deepcopy(high), copied_a))
        commands.append({"command": "wait", "tokens": [left_a["token"], low["token"],
                             high["token"], copied_a["token"]]})
        commands.append(copy.deepcopy(left_mma))
        second_mma = copy.deepcopy(right_mma)
        second_mma["instruction"]["a"] += secondary
        second_mma["instruction"]["c"] += secondary
        second_mma["instruction"]["b"] = left_mma["instruction"]["b"]
        commands.append(second_mma)
    commands.extend(copy.deepcopy(left["epilogue"]))
    commands.append(copy.deepcopy(left["source"][-1]))
    commands.extend(_shift_epilogue(command, secondary, size)
                    for command in right["epilogue"])
    commands.append(_shift_epilogue(right["source"][-1], secondary, size))
    return commands


def _merge_groups(first, second):
    if first["sm"] != second["sm"] or first["sh_kib"] or second["sh_kib"]:
        return None, 0
    if not _safe_groups((first, second)):
        return None, 0
    left, right = _tiles(first), _tiles(second)
    if left is None or right is None:
        return None, 0
    lookup = defaultdict(list)
    for index, entry in enumerate(right):
        lookup[entry["signature"]].append(index)
    selected = {}
    for index, entry in enumerate(left):
        choices = lookup[entry["signature"]]
        if choices:
            selected[index] = choices.pop(0)
    if not selected:
        return None, 0
    secondary = max(first["rf_kib"], second["rf_kib"]) * 256
    required = secondary
    commands = []
    used = set(selected.values())
    for index, entry in enumerate(left):
        if index in selected:
            other = right[selected[index]]
            commands.extend(_paired(entry, other, secondary))
            for _, _, _, mma in other["chunks"]:
                instruction = mma["instruction"]
                required = max(required, secondary + instruction["a"] +
                               instruction["m"] * instruction["k"],
                               secondary + instruction["c"] +
                               instruction["m"] * instruction["n"])
        else:
            commands.extend(copy.deepcopy(entry["source"]))
    for index, entry in enumerate(right):
        if index not in used:
            commands.extend(copy.deepcopy(entry["source"]))
    return {"sm": first["sm"], "rf_kib": math.ceil(required / 256),
            "sh_kib": 0, "commands": _renumber(commands)}, len(selected)


def transform_wave(record, hardware):
    groups = record["groups"]
    by_sm = defaultdict(list)
    for group in groups:
        by_sm[group["sm"]].append(group)
    output = []
    paired = 0
    for sm in sorted(by_sm):
        pair = by_sm[sm]
        if len(pair) != 2:
            output.extend(pair)
            continue
        merged, count = _merge_groups(*pair)
        if merged is None:
            output.extend(pair)
        else:
            output.append(merged)
            paired += count
    if not paired:
        return None, 0
    validate_wave_capacity(output, hardware)
    return {"record": "wave", "groups": output}, paired


def screen(source, manifest_path, case, output):
    source, manifest_path, output = map(Path, (source, manifest_path, output))
    manifest = json.loads(manifest_path.read_text())
    if sha(source) != manifest["program_sha256"][case]:
        raise ValueError("source program changed")
    hardware = manifest["hardware"]
    records = program_records(source)
    if next(records)["hardware"] != hardware:
        raise ValueError("source hardware differs from base")
    cache = {}
    waves = changed = pairs = delta = 0
    choices = []
    for record in records:
        if record["record"] != "wave":
            continue
        try:
            candidate, count = transform_wave(record, hardware)
        except ValueError:
            candidate, count = None, 0
        if candidate is not None:
            before = estimate_wave(record["groups"], hardware, cache)
            after = estimate_wave(candidate["groups"], hardware, cache)
            if after < before:
                delta += after - before
                changed += 1
                pairs += count
                choices.append({"wave": waves, "paired_tiles": count,
                                "old_cycles": before, "new_cycles": after})
        waves += 1
        if waves % 4 == 0:
            write(output, {"case": case, "source_sha256": sha(source),
                           "waves_seen": waves, "changed_waves": changed,
                           "paired_tiles": pairs, "cycle_delta": delta,
                           "choices": choices, "complete": False})
    predicted = dict(manifest["exact_model_cycles"])
    predicted[case] += delta
    score = 1000 * math.exp(sum(weight * math.log(reference / predicted[name])
                                for name, (reference, weight) in SCORE_CASES.items()))
    result = {"case": case, "source_sha256": sha(source),
              "manifest_sha256": sha(manifest_path), "waves_seen": waves,
              "changed_waves": changed, "paired_tiles": pairs,
              "cycle_delta": delta, "choices": choices,
              "five_case_model_cycles": predicted, "five_case_model_score": score,
              "meets_grade_gate": score >= 5000, "complete": True,
              "candidate_program_generated": False, "official_score": None}
    write(output, result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("manifest", type=Path)
    parser.add_argument("case")
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    result = screen(args.source, args.manifest, args.case, args.output)
    print(json.dumps({key: result[key] for key in
                      ("changed_waves", "paired_tiles", "cycle_delta",
                       "five_case_model_score")}, indent=2))


if __name__ == "__main__":
    main()
