"""Materialize SHA-gated resident-four packing and recompute its full model cost."""

import argparse
import json
import subprocess
import sys
import tempfile
from collections import defaultdict
from pathlib import Path

from .estimate import estimate_program, estimate_wave, program_records
from .merge import _overlaps, _pipeline_footprint
from .resident4_pack_screen import _access_footprint, _independent_triple, _pack
from .tool import STARTER, sha, write


def _cross_sm_safe(groups):
    """Conservatively enforce the evaluator's per-wave cross-SM RAW/WAR/WAW rule."""
    by_sm = defaultdict(lambda: {"reads": defaultdict(list), "writes": defaultdict(list)})
    for group in groups:
        footprint = _pipeline_footprint({"groups": [group]})
        if footprint is None:
            return False
        for kind in ("reads", "writes"):
            for tensor, rows in footprint["intervals"][0][kind].items():
                by_sm[group["sm"]][kind][tensor].extend(rows)
    for access in by_sm.values():
        for kind in ("reads", "writes"):
            for rows in access[kind].values():
                rows.sort()
    sms = list(by_sm)
    for left_index, left_sm in enumerate(sms):
        left = by_sm[left_sm]
        for right_sm in sms[left_index + 1:]:
            right = by_sm[right_sm]
            for tensor in left["writes"].keys() | right["writes"].keys():
                if (_overlaps(left["writes"].get(tensor, []), right["reads"].get(tensor, [])) or
                        _overlaps(left["reads"].get(tensor, []), right["writes"].get(tensor, [])) or
                        _overlaps(left["writes"].get(tensor, []), right["writes"].get(tensor, []))):
                    return False
    return True


def materialize(source, manifest_path, hardware_screen_path, progress_path, screen_path, output):
    source, manifest_path, hardware_screen_path, progress_path, screen_path, output = map(
        Path, (source, manifest_path, hardware_screen_path, progress_path, screen_path, output))
    manifest = json.loads(manifest_path.read_text())
    hardware_screen = json.loads(hardware_screen_path.read_text())
    progress = json.loads(progress_path.read_text())
    screen = json.loads(screen_path.read_text())
    from . import resident4_pack_screen
    if (screen["source_sha256"] != sha(source) or
            screen["manifest_sha256"] != sha(manifest_path) or
            screen["hardware_screen_sha256"] != sha(hardware_screen_path) or
            screen["screen_code_sha256"] != sha(resident4_pack_screen.__file__) or
            screen["checkpoint_sha256"] != sha(progress_path) or
            screen["five_case_model_score"] < 5000 or
            not screen["meets_grade_gate"] or
            manifest["program_sha256"][screen["case"]] != sha(source)):
        raise ValueError("screen gate or immutable source identity failed")
    hardware = json.loads(Path("runs/hw-resident4-20261014/spec.json").read_text())[
        "hardware_options"][0]["hardware"]
    selected, = [item for item in hardware_screen["results"]
                 if item["name"] == "resident4_sfu17"]
    if not selected["meets_grade_gate"]:
        raise ValueError("fixed-program shared-hardware gate failed")
    output.mkdir(parents=True, exist_ok=False)
    target = output / f"{screen['case']}.jsonl"
    rows = progress["rows"]
    row_index = wave_index = source_commands = output_commands = 0
    buffer = []
    with tempfile.TemporaryDirectory(prefix="resident4-pack-") as temporary:
        expanded = Path(temporary) / "expanded.jsonl"
        with expanded.open("x") as writer:
            records = program_records(source)
            header = next(records)
            if header["hardware"] != manifest["hardware"]:
                raise ValueError("source hardware changed")
            writer.write(json.dumps(dict(header, hardware=hardware), separators=(",", ":")) + "\n")
            for record in records:
                if record.get("record") != "wave":
                    if buffer:
                        raise ValueError("candidate crosses a non-wave barrier")
                    writer.write(json.dumps(record, separators=(",", ":")) + "\n")
                    continue
                if row_index >= len(rows):
                    raise ValueError("checkpoint ended before source waves")
                row = rows[row_index]
                if not buffer and row["source_start"] != wave_index:
                    raise ValueError("checkpoint wave index differs from source")
                buffer.append(record)
                source_commands += sum(len(group["commands"]) for group in record["groups"])
                wave_index += 1
                if len(buffer) < row["source_waves"]:
                    continue
                if row["source_waves"] == 3:
                    entries = [(candidate, 0, _access_footprint(candidate), index)
                               for index, candidate in enumerate(buffer)]
                    if not _independent_triple(entries):
                        raise ValueError("chosen waves are no longer independent")
                    groups_list = _pack(buffer, hardware)
                else:
                    groups_list = [buffer[0]["groups"]]
                if len(groups_list) != row["packed_waves"]:
                    raise ValueError("packed wave count changed")
                if row["source_waves"] == 3 and any(
                        not _cross_sm_safe(groups) for groups in groups_list):
                    raise ValueError("packed wave contains a cross-SM HBM race")
                exact = sum(estimate_wave(groups, hardware) for groups in groups_list)
                if exact != row["cycles"]:
                    raise ValueError("packed wave model cost changed")
                for groups in groups_list:
                    output_commands += sum(len(group["commands"]) for group in groups)
                    writer.write(json.dumps({"record": "wave", "groups": groups},
                                            separators=(",", ":")) + "\n")
                buffer.clear()
                row_index += 1
        if buffer or row_index != len(rows) or wave_index != screen["source_waves"]:
            raise ValueError("screen/source wave coverage mismatch")
        if source_commands != output_commands:
            raise ValueError("paid command count changed during packing")
        subprocess.run([sys.executable, str(STARTER / "tools/compact_program.py"),
                        str(expanded), str(target)], check=True)
    full_cycles = estimate_program(target)["cycles"]
    if full_cycles != screen["five_case_model_cycles"][screen["case"]]:
        raise ValueError("compact candidate does not reproduce full model estimate")
    result = {"case": screen["case"], "program_sha256": sha(target),
              "source_sha256": sha(source), "screen_sha256": sha(screen_path),
              "source_commands": source_commands, "output_commands": output_commands,
              "source_waves": wave_index, "output_waves": screen["packed_waves"],
              "exact_model_cycles": full_cycles,
              "five_case_model_score": screen["five_case_model_score"],
              "hardware": hardware, "grade_allowed": True, "official_score": None}
    write(output / "manifest.json", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("manifest", type=Path)
    parser.add_argument("hardware_screen", type=Path)
    parser.add_argument("progress", type=Path)
    parser.add_argument("screen", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    print(json.dumps(materialize(args.source, args.manifest, args.hardware_screen,
                                 args.progress, args.screen, args.output), indent=2))


if __name__ == "__main__":
    main()
