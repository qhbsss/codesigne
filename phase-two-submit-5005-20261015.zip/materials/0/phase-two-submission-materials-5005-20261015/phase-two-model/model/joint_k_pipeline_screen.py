"""Choose K-panel and GEMM prefetch transforms per wave before materializing.

Each candidate retains the original group order and MMA K order.  The search
uses the existing paid-command estimator and checks RF/SH residency for every
wave.  It writes only a small checkpoint; no expanded program is generated.
"""

import argparse
import json
import math
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

from .estimate import estimate_program, estimate_wave, program_records, validate_wave_capacity
from .hardware import area, validate
from .ksplit_screen import split_group
from .pipeline_gemm import _pipeline_group
from .tool import SCORE_CASES, STARTER, sha, write


OPTIONS = ("base", "pipe", "k64", "k64_pipe", "k32", "k32_pipe",
           "k80", "k80_pipe", "k96", "k96_pipe", "k112", "k112_pipe",
           "bpipe", "k64_bpipe", "k80_bpipe", "k96_bpipe", "k112_bpipe",
           "b2", "k64_b2", "k80_b2", "k96_b2", "k112_b2")


def transformed(groups, option, hardware):
    """Return transformed groups, or None when the option is unchanged/invalid."""
    if option == "base":
        return groups
    maximum_k = int(option.split("_", 1)[0][1:]) if option.startswith("k") else None
    selected = []
    changed = False
    for group in groups:
        current = group
        if maximum_k is not None:
            current, count = split_group(current, maximum_k,
                                         split_112=maximum_k <= 64)
            changed |= count > 0
        selected.append(current)
    if option.endswith("pipe") or option.endswith("b2"):
        for index, group in enumerate(selected):
            piped, tiles, _ = _pipeline_group(group,
                                             prefetch_a=not (option.endswith("bpipe") or
                                                             option.endswith("b2")),
                                             b_distance=2 if option.endswith("b2") else 1)
            if not tiles:
                continue
            trial = list(selected)
            trial[index] = piped
            try:
                validate_wave_capacity(trial, hardware)
            except ValueError:
                continue
            selected[index] = piped
            changed = True
    if not changed:
        return None
    try:
        validate_wave_capacity(selected, hardware)
    except ValueError:
        return None
    return selected


def screen_case(source, hardware, checkpoint, case, options=OPTIONS,
                bulk_dma_approximation=True):
    progress = json.loads(checkpoint.read_text())
    rows = progress["cases"].setdefault(case, [])
    records = program_records(source)
    header = next(records)
    if header["hardware"]["tc_k_parallel"] != 1 or hardware["tc_k_parallel"] != 1:
        raise ValueError("K order requires tc_k_parallel=1")
    cache = {}
    wave_index = 0
    for record in records:
        if record["record"] != "wave":
            continue
        if wave_index < len(rows):
            wave_index += 1
            continue
        groups = record["groups"]
        validate_wave_capacity(groups, hardware)
        baseline = estimate_wave(groups, hardware, cache,
                                 bulk_dma_approximation=bulk_dma_approximation)
        costs = {"base": baseline}
        for option in options:
            if option == "base":
                continue
            candidate = transformed(groups, option, hardware)
            if candidate is not None:
                costs[option] = estimate_wave(candidate, hardware, cache,
                                              bulk_dma_approximation=bulk_dma_approximation)
        choice = min(costs, key=costs.get)
        rows.append({"option": choice, "base": baseline, "cycles": costs[choice],
                     "costs": costs if costs[choice] < baseline else {"base": baseline}})
        wave_index += 1
        if wave_index % 8 == 0:
            write(checkpoint, progress)
    write(checkpoint, progress)
    return {"waves": wave_index, "changed_waves": sum(row["option"] != "base" for row in rows),
            "base_cycles": sum(row["base"] for row in rows),
            "selected_cycles": sum(row["cycles"] for row in rows),
            "choices": {option: sum(row["option"] == option for row in rows)
                        for option in options}}


def screen(base_dir, output, options=OPTIONS):
    base_dir, output = Path(base_dir), Path(output)
    base = json.loads((base_dir / "manifest.json").read_text())
    hardware = base["hardware"]
    validate(hardware)
    output.mkdir(parents=True, exist_ok=True)
    checkpoint = output / "progress.json"
    identity = {"source_manifest_sha256": sha(base_dir / "manifest.json"),
                "estimator_sha256": sha(Path(__file__).with_name("estimate.py")),
                "split_sha256": sha(Path(__file__).with_name("ksplit_screen.py")),
                "pipeline_sha256": sha(Path(__file__).with_name("pipeline_gemm.py")),
                "options": options}
    progress = json.loads(checkpoint.read_text()) if checkpoint.exists() else {
        **identity, "cases": {}}
    if any(progress.get(key) != value for key, value in identity.items()):
        raise ValueError("checkpoint inputs changed")
    write(checkpoint, progress)
    summary = {}
    cycles = dict(base["model_cycles"])
    for case in SCORE_CASES:
        source = base_dir / "programs" / f"{case}.jsonl"
        if sha(source) != base["programs"][case]["program_sha256"]:
            raise ValueError(f"source changed: {case}")
        row = screen_case(source, hardware, checkpoint, case, options)
        cycles[case] += row["selected_cycles"] - row["base_cycles"]
        summary[case] = {**row, "predicted_cycles": cycles[case]}
        print(case, json.dumps(summary[case]), flush=True)
    score = 1000 * math.exp(sum(weight * math.log(reference / cycles[case])
        for case, (reference, weight) in SCORE_CASES.items()))
    result = {**identity, "hardware": hardware, "area_au": area(hardware),
              "cases": summary, "predicted_cycles": cycles,
              "conditional_predicted_score": score,
              "meets_grade_gate": score >= 5000,
              "candidate_program_generated": False, "official_score": None}
    write(output / "screen.json", result)
    print("score", score, flush=True)
    return result


def materialize(base_dir, screen_dir, output):
    """Build only a complete five-case model-qualified per-wave selection."""
    base_dir, screen_dir, output = map(Path, (base_dir, screen_dir, output))
    base = json.loads((base_dir / "manifest.json").read_text())
    screen_result = json.loads((screen_dir / "screen.json").read_text())
    progress = json.loads((screen_dir / "progress.json").read_text())
    if (screen_result["source_manifest_sha256"] != sha(base_dir / "manifest.json") or
            screen_result["conditional_predicted_score"] < 5000 or
            screen_result["estimator_sha256"] != sha(Path(__file__).with_name("estimate.py")) or
            screen_result["split_sha256"] != sha(Path(__file__).with_name("ksplit_screen.py")) or
            screen_result["pipeline_sha256"] != sha(Path(__file__).with_name("pipeline_gemm.py"))):
        raise ValueError("five-case model gate or input identity failed")
    hardware = base["hardware"]
    output.mkdir(parents=True, exist_ok=False)
    programs = output / "programs"
    programs.mkdir()
    hashes = {}
    for case in SCORE_CASES:
        source = base_dir / "programs" / f"{case}.jsonl"
        if sha(source) != base["programs"][case]["program_sha256"]:
            raise ValueError(f"source changed: {case}")
        choices = progress["cases"][case]
        if len(choices) != screen_result["cases"][case]["waves"]:
            raise ValueError(f"incomplete wave choices: {case}")
        destination = programs / f"{case}.jsonl"
        if not any(row["option"] != "base" for row in choices):
            shutil.copyfile(source, destination)
        else:
            with tempfile.TemporaryDirectory(prefix=f"joint-k-pipe-{case}-") as temporary:
                expanded = Path(temporary) / "expanded.jsonl"
                records = program_records(source)
                header = next(records)
                wave_index = 0
                with expanded.open("x") as writer:
                    writer.write(json.dumps(header, separators=(",", ":")) + "\n")
                    for record in records:
                        if record["record"] == "wave":
                            option = choices[wave_index]["option"]
                            wave_index += 1
                            if option != "base":
                                groups = transformed(record["groups"], option, hardware)
                                if groups is None:
                                    raise ValueError(f"selected option no longer feasible: {case} wave {wave_index}")
                                record = {"record": "wave", "groups": groups}
                        writer.write(json.dumps(record, separators=(",", ":")) + "\n")
                if wave_index != len(choices):
                    raise ValueError(f"wave count changed: {case}")
                subprocess.run([sys.executable, str(STARTER / "tools/compact_program.py"),
                                str(expanded), str(destination)], check=True)
        hashes[case] = sha(destination)
    exact = {case: estimate_program(programs / f"{case}.jsonl")["cycles"]
             for case in SCORE_CASES}
    score = 1000 * math.exp(sum(weight * math.log(reference / exact[case])
        for case, (reference, weight) in SCORE_CASES.items()))
    result = {"hardware": hardware, "area_au": area(hardware),
              "screen_sha256": sha(screen_dir / "screen.json"),
              "program_sha256": hashes, "exact_model_cycles": exact,
              "exact_model_score": score, "grade_allowed": score >= 5000,
              "official_score": None}
    write(output / "manifest.json", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("base_dir", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--options", nargs="+", choices=OPTIONS, default=OPTIONS)
    args = parser.parse_args()
    screen(args.base_dir, args.output, args.options)


if __name__ == "__main__":
    main()
