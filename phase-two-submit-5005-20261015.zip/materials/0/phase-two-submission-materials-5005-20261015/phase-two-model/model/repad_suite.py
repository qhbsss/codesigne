"""Apply a screened second K-stride transition to a five-case compact suite."""

import argparse
import json
import math
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

from .estimate import estimate_program
from .hardware import area, validate
from .pad_transposed_k import write_expanded
from .tool import SCORE_CASES, STARTER, sha, write


def materialize(base_dir, screen_path, output):
    base_dir, screen_path, output = map(Path, (base_dir, screen_path, output))
    manifest = json.loads((base_dir / "manifest.json").read_text())
    screen = json.loads(screen_path.read_text())
    hardware = manifest["hardware"]
    validate(hardware)
    target = screen["target_stride"]
    if set(target) != {"w-d1", "w-d16", "w-d4l"} or set(screen["results"]) != set(target):
        raise ValueError("screen requires all three decode cases")
    predicted = dict(manifest["model_cycles"])
    for case, result in screen["results"].items():
        if result["baseline_cycles"] != predicted[case] or result["new_stride"] != target[case]:
            raise ValueError(f"screen baseline or stride changed: {case}")
        predicted[case] = result["predicted_cycles"]
    model_score = 1000 * math.exp(sum(weight * math.log(reference / predicted[case])
        for case, (reference, weight) in SCORE_CASES.items()))
    if model_score < 5000:
        raise ValueError(f"five-case model score {model_score:.4f} below 5000 gate")
    output.mkdir(parents=True, exist_ok=False)
    programs = output / "programs"
    programs.mkdir()
    result = {"hardware": hardware, "area_au": area(hardware),
              "source_manifest_sha256": sha(base_dir / "manifest.json"),
              "screen_sha256": sha(screen_path), "predicted_cycles": predicted,
              "screen_model_score": model_score, "target_stride": target,
              "program_sha256": {}}
    for case in SCORE_CASES:
        source = base_dir / "programs" / f"{case}.jsonl"
        if sha(source) != manifest["programs"][case]["program_sha256"]:
            raise ValueError(f"source program changed: {case}")
        destination = programs / f"{case}.jsonl"
        if case not in target:
            shutil.copyfile(source, destination)
        else:
            with tempfile.TemporaryDirectory(prefix=f"phase-two-repad-{case}-") as temp:
                expanded = Path(temp) / "expanded.jsonl"
                row = screen["results"][case]
                write_expanded(source, expanded, hardware,
                               row["old_stride"], row["new_stride"])
                subprocess.run([sys.executable, str(STARTER / "tools/compact_program.py"),
                                str(expanded), str(destination)], check=True)
        result["program_sha256"][case] = sha(destination)
    exact = {case: estimate_program(programs / f"{case}.jsonl")["cycles"]
             for case in SCORE_CASES}
    exact_score = 1000 * math.exp(sum(weight * math.log(reference / exact[case])
        for case, (reference, weight) in SCORE_CASES.items()))
    result.update(exact_model_cycles=exact, exact_model_score=exact_score,
                  grade_allowed=exact_score >= 5000, official_score=None)
    write(output / "manifest.json", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("base_dir", type=Path)
    parser.add_argument("screen", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    print(json.dumps(materialize(args.base_dir, args.screen, args.output), indent=2))


if __name__ == "__main__":
    main()
