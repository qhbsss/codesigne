"""Screen group order in any wave with provably independent global accesses."""

import argparse
import json
import math
from pathlib import Path

from .estimate import estimate_wave, program_records
from .merge import _overlaps, _pipeline_footprint
from .order_groups_screen import OPTIONS, ordered
from .tool import SCORE_CASES, sha, write


def independent(groups):
    if len(groups) < 2:
        return False
    footprints = []
    for group in groups:
        footprint = _pipeline_footprint({"groups": [group]})
        if footprint is None:
            return False
        footprints.append(footprint["intervals"][0])
    for left_index, left in enumerate(footprints):
        for right in footprints[left_index + 1:]:
            for tensor in left["writes"].keys() | right["writes"].keys():
                if (_overlaps(left["writes"].get(tensor, []), right["writes"].get(tensor, [])) or
                        _overlaps(left["writes"].get(tensor, []), right["reads"].get(tensor, [])) or
                        _overlaps(left["reads"].get(tensor, []), right["writes"].get(tensor, []))):
                    return False
    return True


def screen(source, case, manifest_path, checkpoint):
    source, manifest_path, checkpoint = map(Path, (source, manifest_path, checkpoint))
    checkpoint.parent.mkdir(parents=True, exist_ok=True)
    manifest = json.loads(manifest_path.read_text())
    source_sha = sha(source)
    if (source_sha != manifest["program_sha256"][case] or
            next(program_records(source))["hardware"] != manifest["hardware"]):
        raise ValueError("source program differs from manifest")
    identity = {"case": case, "source_sha256": source_sha,
                "manifest_sha256": sha(manifest_path), "screen_code_sha256": sha(__file__)}
    state = json.loads(checkpoint.read_text()) if checkpoint.exists() else {**identity, "rows": []}
    if any(state.get(key) != value for key, value in identity.items()):
        raise ValueError("checkpoint identity changed")
    rows = state["rows"]
    cache = {}
    wave_index = 0
    for record in program_records(source):
        if record.get("record") != "wave":
            continue
        if wave_index < len(rows):
            wave_index += 1
            continue
        groups = record["groups"]
        safe = independent(groups)
        baseline = estimate_wave(groups, manifest["hardware"], cache)
        costs = {"base": baseline}
        if safe:
            for option in OPTIONS[1:]:
                candidate = ordered(groups, option)
                if candidate != groups:
                    costs[option] = estimate_wave(candidate, manifest["hardware"], cache)
        choice = min(costs, key=costs.get)
        rows.append({"option": choice, "base": baseline, "cycles": costs[choice],
                     "safe": safe})
        wave_index += 1
        if wave_index % 8 == 0:
            write(checkpoint, state)
    write(checkpoint, state)
    cycles = dict(manifest["exact_model_cycles"])
    cycles[case] += sum(row["cycles"] - row["base"] for row in rows)
    score = 1000 * math.exp(sum(weight * math.log(reference / cycles[name])
        for name, (reference, weight) in SCORE_CASES.items()))
    result = {**identity, "checkpoint_sha256": sha(checkpoint), "waves": wave_index,
              "safe_waves": sum(row["safe"] for row in rows),
              "changed_waves": sum(row["option"] != "base" for row in rows),
              "choices": {option: sum(row["option"] == option for row in rows) for option in OPTIONS},
              "five_case_model_cycles": cycles, "five_case_model_score": score,
              "meets_grade_gate": score >= 5000, "candidate_program_generated": False,
              "official_score": None}
    write(checkpoint.with_name("screen.json"), result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("case")
    parser.add_argument("manifest", type=Path)
    parser.add_argument("checkpoint", type=Path)
    args = parser.parse_args()
    print(json.dumps(screen(args.source, args.case, args.manifest, args.checkpoint), indent=2))


if __name__ == "__main__":
    main()
