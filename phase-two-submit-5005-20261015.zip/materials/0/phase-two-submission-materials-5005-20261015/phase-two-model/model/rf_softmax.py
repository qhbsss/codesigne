"""Keep score rows in paid RF and perform one stable softmax before AV."""

import math

from .estimate import validate_wave_capacity
from .online_attention import _emit, _imm, _load, _reg, _vector, _view


def _rf_group(start, rows, context, head_index, hidden_width, head_width,
              key_block, query_tensor, key_tensor, value_tensor, output_tensor,
              key_layout, sm):
    query_base = 0
    output_base = query_base + rows * head_width
    scores_base = output_base + rows * head_width
    tile_base = scores_base + rows * context
    keys_base = tile_base + rows * key_block
    values_base = keys_base + head_width * key_block
    scalar_base = values_base + key_block * head_width
    scratch_base = scalar_base + 8
    words = scratch_base + context
    commands = []
    _load(commands, query_tensor,
          _view(start * 3 * hidden_width + head_index * head_width,
                rows, head_width, 3 * hidden_width),
          _view(query_base, rows, head_width, head_width))
    _emit(commands, "fill", dst=output_base, len=rows * head_width, value=0.0)
    end = min(start + rows, context)
    for begin in range(0, end, key_block):
        count = min(key_block, end - begin)
        key_view = (_view(head_index * head_width * context + begin,
                          head_width, count, context)
                    if key_layout == "transposed" else
                    _view(begin * hidden_width + head_index * head_width,
                          head_width, count, 1, hidden_width))
        _load(commands, key_tensor, key_view,
              _view(keys_base, head_width, count, count))
        _emit(commands, "fill", dst=tile_base, len=rows * count, value=0.0)
        _emit(commands, "mma", a=query_base, b=keys_base, c=tile_base,
              m=rows, n=count, k=head_width)
        for row in range(rows):
            _vector(commands, "add", scores_base + row * context + begin, count,
                    _reg(tile_base + row * count), _imm(0.0))
    for row in range(rows):
        row_start = scores_base + row * context
        valid = start + row + 1
        _vector(commands, "mul", row_start, valid, _reg(row_start),
                _imm(1.0 / math.sqrt(head_width)))
        if valid < end:
            _emit(commands, "fill", dst=row_start + valid, len=end - valid, value=-1e30)
        _emit(commands, "reduce", scratch=scratch_base, dst=scalar_base,
              src=row_start, len=end, max=True)
        _vector(commands, "sub", row_start, end,
                _reg(row_start), _reg(scalar_base, 0))
        _vector(commands, "exp", row_start, end, _reg(row_start), _imm(0.0))
        _emit(commands, "reduce", scratch=scratch_base, dst=scalar_base,
              src=row_start, len=end, max=False)
        _vector(commands, "div", row_start, end,
                _reg(row_start), _reg(scalar_base, 0))
    for begin in range(0, end, key_block):
        count = min(key_block, end - begin)
        _load(commands, value_tensor,
              _view(begin * hidden_width + head_index * head_width,
                    count, head_width, hidden_width),
              _view(values_base, count, head_width, head_width))
        for row in range(rows):
            _vector(commands, "add", tile_base + row * count, count,
                    _reg(scores_base + row * context + begin), _imm(0.0))
        _emit(commands, "mma", a=tile_base, b=values_base, c=output_base,
              m=rows, n=head_width, k=count)
    _emit(commands, "store", tensor=output_tensor,
          **{"global": _view(start * hidden_width + head_index * head_width,
                            rows, head_width, hidden_width),
             "local": _view(output_base, rows, head_width, head_width)})
    return {"sm": sm, "rf_kib": (words + 255) // 256, "sh_kib": 0,
            "commands": commands}


def rf_waves(header, query_tensor, key_tensor, value_tensor, output_tensor,
             key_layout, row_tile, key_block):
    shape = header["shape"]
    context = shape["prefill"]
    head_width = shape["d"] // shape["heads"]
    sms = header["hardware"]["sms"]
    if head_width > 64 or key_block > 64 or row_tile > 64:
        raise ValueError("RF template only supports head, row and key tiles <=64")
    for head_index in range(shape["heads"]):
        starts = list(range(0, context, row_tile))
        for offset in range(0, len(starts), sms):
            groups = [
                _rf_group(start, min(row_tile, context - start), context, head_index,
                          shape["d"], head_width, key_block, query_tensor, key_tensor,
                          value_tensor, output_tensor, key_layout, sm)
                for sm, start in enumerate(starts[offset:offset + sms])
            ]
            validate_wave_capacity(groups, header["hardware"])
            yield {"record": "wave", "groups": groups}
