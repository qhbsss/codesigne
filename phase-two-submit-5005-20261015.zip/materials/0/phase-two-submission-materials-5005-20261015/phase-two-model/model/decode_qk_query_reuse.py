"""Remove duplicate QK query loads while retaining their original RF slots.

The first query DMA remains in place and is waited on before its first MMA.
A later identical load is removed only if no instruction has written the same
RF words.  K DMA, MMA, stores, group placement, and wave order stay unchanged.
Candidate generation requires a complete five-case model score above 5000.
"""

import argparse
import json
import math
import shutil
import subprocess
import sys
import tempfile
from collections import Counter
from pathlib import Path

from .decode_qk_query_hoist import _key_tensors, _query_key
from .estimate import estimate_program, estimate_wave, program_records, validate_wave_capacity
from .tool import SCORE_CASES, STARTER, sha, write


def _span(view):
    return (view["base"], view["base"] +
            (view["rows"] - 1) * view["row_stride"] +
            (view["cols"] - 1) * view["col_stride"] + 1)


def _overlaps(left, right):
    return left[0] < right[1] and right[0] < left[1]


def reuse_group(group, key_tensors):
    """Return the group and number of genuinely eliminated query DMAs."""
    if group["sh_kib"]:
        return group, 0
    commands = group["commands"]
    operations = Counter(command.get("instruction", {}).get("op") for command in commands)
    if (not operations["mma"] or
            any(operation not in (None, "fill", "load", "mma", "store")
                for operation in operations)):
        return group, 0
    if any(command.get("instruction", {}).get("op") == "mma" and
           (command["instruction"]["m"] != 1 or
            command["instruction"]["n"] not in (1, 32) or
            command["instruction"]["k"] not in (64, 128))
           for command in commands):
        return group, 0
    has_k = any(command.get("instruction", {}).get("op") == "load" and
                command["instruction"]["tensor"] in key_tensors for command in commands)
    if not has_k:
        return group, 0

    # Each resident query panel has its own RF slot and a token recording
    # whether its initial DMA has completed.  A later writer invalidates it.
    resident = {}
    eliminated = set()
    transformed = []
    for command in commands:
        kind = command["command"]
        instruction = command.get("instruction", {})
        operation = instruction.get("op")
        if kind == "wait":
            tokens = [token for token in command["tokens"] if token not in eliminated]
            for base, item in tuple(resident.items()):
                if item[1] in tokens:
                    resident[base] = (item[0], item[1], True, item[3])
            if tokens:
                transformed.append(dict(command, tokens=tokens))
            continue
        if operation == "load":
            if kind != "async":
                return group, 0
            view = instruction["local"]
            interval = _span(view)
            if instruction["tensor"] in key_tensors:
                for base, item in tuple(resident.items()):
                    if _overlaps(item[3], interval):
                        del resident[base]
                transformed.append(command)
                continue
            global_view = instruction["global"]
            if (global_view["rows"] != 1 or global_view["cols"] not in (64, 128) or
                    view["rows"] != 1 or view["cols"] != global_view["cols"] or
                    view["col_stride"] != 1):
                return group, 0
            key = _query_key(instruction)
            base = view["base"]
            if resident.get(base, (None, None, False))[0] == key and resident[base][2]:
                eliminated.add(command["token"])
                continue
            for other, item in tuple(resident.items()):
                if _overlaps(item[3], interval):
                    del resident[other]
            resident[base] = (key, command["token"], False, interval)
            transformed.append(command)
            continue
        if operation == "fill":
            if kind != "run":
                return group, 0
            interval = (instruction["dst"], instruction["dst"] + instruction["len"])
        elif operation == "mma":
            if kind != "run" or not resident.get(instruction["a"], (None, None, False))[2]:
                return group, 0
            interval = (instruction["c"], instruction["c"] +
                        instruction["m"] * instruction["n"])
        elif operation == "store":
            if kind != "run":
                return group, 0
            transformed.append(command)
            continue
        else:
            return group, 0
        for base, item in tuple(resident.items()):
            if _overlaps(item[3], interval):
                del resident[base]
        transformed.append(command)
    if not eliminated:
        return group, 0
    return dict(group, commands=transformed), len(eliminated)


def _wave(record, key_tensors, hardware):
    groups = []
    removed = changed = 0
    for group in record["groups"]:
        selected, count = reuse_group(group, key_tensors)
        groups.append(selected)
        removed += count
        changed += count > 0
    if changed:
        validate_wave_capacity(groups, hardware)
    return {"record": "wave", "groups": groups}, changed, removed


def screen(source, manifest_path, case, output):
    source, manifest_path, output = map(Path, (source, manifest_path, output))
    manifest = json.loads(manifest_path.read_text())
    if case != "w-d4l" or sha(source) != manifest["program_sha256"][case]:
        raise ValueError("source or case differs from five-case manifest")
    hardware = manifest["hardware"]
    records = program_records(source)
    if next(records)["hardware"] != hardware:
        raise ValueError("shared hardware differs")
    key_tensors = _key_tensors(source)
    old = new = groups = waves = removed = 0
    cache = {}
    for record in records:
        if record["record"] != "wave":
            continue
        selected, changed, count = _wave(record, key_tensors, hardware)
        if not changed:
            continue
        old += estimate_wave(record["groups"], hardware, cache)
        new += estimate_wave(selected["groups"], hardware, cache)
        groups += changed
        waves += 1
        removed += count
    if not groups:
        raise ValueError("no reusable QK query loads found")
    cycles = dict(manifest["model_cycles"])
    cycles[case] += new - old
    score = 1000 * math.exp(sum(weight * math.log(reference / cycles[name])
                                for name, (reference, weight) in SCORE_CASES.items()))
    result = {"case": case, "source_sha256": sha(source),
              "manifest_sha256": sha(manifest_path),
              "screen_code_sha256": sha(__file__),
              "helper_code_sha256": sha(Path(__file__).with_name("decode_qk_query_hoist.py")),
              "estimator_sha256": sha(Path(__file__).with_name("estimate.py")),
              "key_tensors": sorted(key_tensors),
              "changed_waves": waves, "changed_groups": groups,
              "removed_query_dma": removed,
              "original_affected_cycles": old,
              "replacement_affected_cycles": new,
              "cycle_delta": new - old,
              "five_case_model_cycles": cycles,
              "five_case_model_score": score,
              "meets_grade_gate": score >= 5000,
              "candidate_program_generated": False, "official_score": None}
    output.parent.mkdir(parents=True, exist_ok=True)
    write(output, result)
    return result


def materialize(source, manifest_path, screen_path, output_dir):
    source, manifest_path, screen_path, output_dir = map(
        Path, (source, manifest_path, screen_path, output_dir))
    result = json.loads(screen_path.read_text())
    if (not result["meets_grade_gate"] or result["five_case_model_score"] < 5000 or
            sha(source) != result["source_sha256"] or
            sha(manifest_path) != result["manifest_sha256"] or
            sha(__file__) != result["screen_code_sha256"] or
            sha(Path(__file__).with_name("decode_qk_query_hoist.py")) != result["helper_code_sha256"] or
            sha(Path(__file__).with_name("estimate.py")) != result["estimator_sha256"]):
        raise ValueError("five-case model gate or screened inputs changed")
    manifest = json.loads(manifest_path.read_text())
    case = result["case"]
    hardware = manifest["hardware"]
    key_tensors = _key_tensors(source)
    if (manifest["program_sha256"][case] != result["source_sha256"] or
            sorted(key_tensors) != result["key_tensors"]):
        raise ValueError("source tensor identity changed")
    with tempfile.TemporaryDirectory(prefix="decode-qk-query-reuse-", dir="/tmp") as temporary:
        expanded = Path(temporary) / "expanded.jsonl"
        compact = Path(temporary) / f"{case}.jsonl"
        changed_groups = removed = 0
        records = program_records(source)
        header = next(records)
        with expanded.open("x") as writer:
            writer.write(json.dumps(header, separators=(",", ":")) + "\n")
            for record in records:
                if record["record"] == "wave":
                    record, changed, count = _wave(record, key_tensors, hardware)
                    changed_groups += changed
                    removed += count
                writer.write(json.dumps(record, separators=(",", ":")) + "\n")
        if changed_groups != result["changed_groups"] or removed != result["removed_query_dma"]:
            raise ValueError("materialized QK groups differ from screen")
        subprocess.run([sys.executable, str(STARTER / "tools/compact_program.py"),
                        str(expanded), str(compact)], check=True)
        exact = estimate_program(compact)["cycles"]
        if exact != result["five_case_model_cycles"][case]:
            raise ValueError("materialized full model differs from in-memory screen")
        output_dir.mkdir(parents=True, exist_ok=False)
        destination = output_dir / f"{case}.jsonl"
        shutil.move(str(compact), destination)
    receipt = {"case": case, "source_sha256": sha(source),
               "program_sha256": sha(destination), "screen_sha256": sha(screen_path),
               "changed_groups": changed_groups, "removed_query_dma": removed,
               "exact_model_cycles": exact,
               "five_case_model_score": result["five_case_model_score"],
               "grade_allowed": True, "official_score": None}
    write(output_dir / "manifest.json", receipt)
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    probe = sub.add_parser("screen")
    probe.add_argument("source", type=Path)
    probe.add_argument("manifest", type=Path)
    probe.add_argument("case")
    probe.add_argument("output", type=Path)
    emit = sub.add_parser("materialize")
    emit.add_argument("source", type=Path)
    emit.add_argument("manifest", type=Path)
    emit.add_argument("screen", type=Path)
    emit.add_argument("output_dir", type=Path)
    args = parser.parse_args()
    if args.command == "screen":
        print(json.dumps(screen(args.source, args.manifest, args.case, args.output), indent=2))
    else:
        print(json.dumps(materialize(args.source, args.manifest, args.screen,
                                     args.output_dir), indent=2))


if __name__ == "__main__":
    main()
