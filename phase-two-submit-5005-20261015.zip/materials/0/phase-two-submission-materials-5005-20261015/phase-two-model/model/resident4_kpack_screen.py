"""Jointly screen smaller GEMM K panels and packing of independent waves."""

import argparse
import json
import math
from collections import deque
from pathlib import Path

from .estimate import estimate_wave, program_records
from .ksplit_screen import split_group
from .resident4_pack_screen import _access_footprint, _pack
from .resident4_window_screen import choose, independent
from .tool import SCORE_CASES, sha, write


def screen(source, case, manifest_path, output, k_options=(32, 48, 56, 64)):
    source, manifest_path, output = map(Path, (source, manifest_path, output))
    output.parent.mkdir(parents=True, exist_ok=True)
    manifest = json.loads(manifest_path.read_text())
    if sha(source) != manifest["program_sha256"][case]:
        raise ValueError("program SHA changed")
    records = program_records(source)
    hardware = manifest["hardware"]
    if next(records)["hardware"] != hardware or hardware["tc_k_parallel"] != 1:
        raise ValueError("hardware mismatch or unsupported K order")
    cache = {}
    rows = []
    buffer = deque()
    wave_index = commit_cycles = changed_windows = 0

    def flush(force=False):
        nonlocal changed_windows
        while buffer and (force or len(buffer) >= 3):
            first = buffer[0]
            choices = []
            for width in range(2, min(len(buffer), 3) + 1):
                entries = list(buffer)[:width]
                if not independent(entries):
                    continue
                base = sum(entry[1] for entry in entries)
                for maximum in k_options:
                    transformed = []
                    changed = 0
                    for entry in entries:
                        groups = []
                        for group in entry[0]["groups"]:
                            converted, count = split_group(group, maximum,
                                                           split_112=maximum <= 64)
                            groups.append(converted)
                            changed += count
                        transformed.append({"groups": groups})
                    if not changed:
                        continue
                    packed = _pack(transformed, hardware)
                    if len(packed) >= width:
                        continue
                    changed_windows += 1
                    cycles = sum(estimate_wave(groups, hardware, cache) for groups in packed)
                    if cycles < base:
                        choices.append({"source_waves": width, "packed_waves": len(packed),
                                        "cycles": cycles, "base": base, "max_k": maximum,
                                        "split_quartets": changed})
            rows.append({"base": first[1], "options": choices})
            buffer.popleft()
            if len(rows) % 64 == 0:
                print(case, "screened", len(rows), "feasible_packings", changed_windows, flush=True)
                write(output.with_name("progress.json"),
                      {"case": case, "source_sha256": sha(source),
                       "screened_waves": len(rows), "feasible_packings": changed_windows,
                       "beneficial_options": sum(len(row["options"]) for row in rows)})

    for record in records:
        if record.get("record") != "wave":
            flush(force=True)
            if record.get("record") == "commit":
                commit_cycles += 1
            continue
        buffer.append((record, estimate_wave(record["groups"], hardware, cache),
                       _access_footprint(record), wave_index))
        wave_index += 1
        flush()
    flush(force=True)
    baseline = commit_cycles + sum(row["base"] for row in rows)
    if len(rows) != wave_index or baseline != manifest["model_cycles"][case]:
        raise ValueError("source differs from complete model baseline")
    selected, wave_cycles = choose(rows)
    cycles = dict(manifest["model_cycles"])
    cycles[case] = commit_cycles + wave_cycles
    score = 1000 * math.exp(sum(weight * math.log(reference / cycles[name])
                              for name, (reference, weight) in SCORE_CASES.items()))
    result = {"case": case, "source_sha256": sha(source),
              "manifest_sha256": sha(manifest_path), "k_options": k_options,
              "source_waves": wave_index,
              "packed_waves": sum(row["packed_waves"] for row in selected),
              "chosen": [row for row in selected if row["source_waves"] > 1],
              "feasible_packings": changed_windows,
              "beneficial_options": sum(len(row["options"]) for row in rows),
              "base_cycles": baseline, "selected_cycles": cycles[case],
              "cycle_delta": cycles[case] - baseline,
              "five_case_model_cycles": cycles, "five_case_model_score": score,
              "meets_grade_gate": score >= 5000,
              "candidate_program_generated": False, "official_score": None}
    write(output, result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("case")
    parser.add_argument("manifest", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--k-options", type=int, nargs="+",
                        default=[32, 48, 56, 64, 80, 96, 110])
    args = parser.parse_args()
    result = screen(args.source, args.case, args.manifest, args.output, tuple(args.k_options))
    print(json.dumps({key: result[key] for key in ("case", "source_waves", "packed_waves",
                                                   "feasible_packings", "beneficial_options",
                                                   "cycle_delta", "five_case_model_score")},
                     indent=2))


if __name__ == "__main__":
    main()
