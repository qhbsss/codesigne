"""Build a reproducible shared-hardware MIP domain from existing prepared programs."""

import argparse
import hashlib
import json
from pathlib import Path

from .hardware import area, validate
from .tool import MODEL, ROOT, SCORE_CASES, STARTER, sha, write


def build_spec(base_spec, manifests):
    if set(base_spec) != {"target_score", "hardware_options"}:
        raise ValueError("unexpected base portfolio specification")
    manifests = list(manifests)
    groups = {}
    seen = {}
    for design in base_spec["hardware_options"]:
        for case_name, programs in design["programs"].items():
            for path in programs:
                program = ROOT / path
                with program.open() as source:
                    header = json.loads(next(source))
                key = json.dumps(header["hardware"], sort_keys=True)
                group = groups.setdefault(key, {case: [] for case in SCORE_CASES})
                seen.setdefault((key, case_name), set())
                digest = sha(program)
                if digest not in seen[key, case_name]:
                    group[case_name].append(path)
                    seen[key, case_name].add(digest)
    rejected = []
    added = 0
    expected_cases = {
        case_name: json.loads((STARTER / "configs/reference" / f"{case_name}.json").read_text())
        for case_name in SCORE_CASES
    }
    for manifest_path in sorted(map(Path, manifests)):
        manifest = json.loads(manifest_path.read_text())
        case_name = manifest.get("case")
        if manifest.get("status") != "unverified" or case_name not in SCORE_CASES:
            continue
        program = manifest_path.with_name("program.jsonl")
        config = manifest_path.with_name("config.json")
        if (not program.is_file() or not config.is_file() or
                (MODEL / manifest["program"]).resolve() != program.resolve() or
                manifest["program_sha256"] != sha(program) or
                manifest["config_sha256"] != sha(config)):
            rejected.append({"manifest": str(manifest_path), "reason": "missing or changed artifact"})
            continue
        with program.open() as source:
            header = json.loads(next(source))
        configuration = json.loads(config.read_text())
        expected = expected_cases[case_name]
        if (any(header[field] != expected[field] or
                header[field] != configuration[field]
                for field in ("shape", "batch", "decode")) or
                header["hardware"] != configuration["hardware"]):
            rejected.append({"manifest": str(manifest_path), "reason": "workload or hardware mismatch"})
            continue
        try:
            validate(header["hardware"])
        except ValueError as error:
            rejected.append({"manifest": str(manifest_path), "reason": str(error)})
            continue
        if area(header["hardware"]) > 100:
            rejected.append({"manifest": str(manifest_path), "reason": "area exceeds budget"})
            continue
        key = json.dumps(header["hardware"], sort_keys=True)
        group = groups.setdefault(key, {case: [] for case in SCORE_CASES})
        hashes = seen.setdefault((key, case_name), set())
        digest = manifest["program_sha256"]
        if digest in hashes:
            continue
        group[case_name].append(str(program.relative_to(ROOT)))
        hashes.add(digest)
        added += 1
    hardware_options = []
    for key, programs in sorted(groups.items()):
        if all(programs.values()):
            fingerprint = hashlib.sha256(key.encode()).hexdigest()[:12]
            hardware_options.append({"name": f"prepared-{fingerprint}", "programs": programs})
    spec = {"target_score": base_spec["target_score"], "hardware_options": hardware_options}
    report = {"manifest_count": len(manifests), "added_programs": added,
              "complete_hardware": len(hardware_options),
              "program_options": sum(len(paths) for design in hardware_options
                                     for paths in design["programs"].values()),
              "rejected": rejected}
    return spec, report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("base_spec", type=Path)
    parser.add_argument("destination", type=Path)
    args = parser.parse_args()
    if args.destination.exists():
        raise FileExistsError(args.destination)
    manifests = list((MODEL / "runs").glob("*/hardware-*/*/option-*/prepared.json"))
    spec, report = build_spec(json.loads(args.base_spec.read_text()), manifests)
    write(args.destination, spec)
    write(args.destination.with_name(args.destination.stem + "-discovery.json"), report)
    print(json.dumps({key: value for key, value in report.items() if key != "rejected"}, indent=2))


if __name__ == "__main__":
    main()
