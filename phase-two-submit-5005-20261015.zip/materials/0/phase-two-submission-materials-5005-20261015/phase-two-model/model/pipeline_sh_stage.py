"""Stage the second pipelined B panel in SH to lower RF residency."""

import copy

from .pipeline_k_retile import retile_group


def stage_group(group, direct_tc=False):
    """Preserve K64+64 and HBM reads while staging the second B panel in SH."""
    _, tiles = retile_group(group, 48)
    if not tiles:
        return group, 0
    commands = []
    for pos in range(0, len(group["commands"]), 10):
        fill, a0, b0, wait0, a1, b1, mma0, wait1, mma1, store = (
            copy.deepcopy(group["commands"][pos:pos + 10]))
        a1["instruction"]["local"]["base"] = 2144
        b1["instruction"]["op"] = "load_shared"
        b1["instruction"]["local"] = {
            "base": 0, "rows": 64, "cols": 32,
            "row_stride": 32, "col_stride": 1}
        mma1["instruction"]["a"] = 2144
        mma1["instruction"]["b"] = 96
        copy_back = {"command": "run", "instruction": {
            "op": "shared_read",
            "shared": {"base": 0, "rows": 64, "cols": 32,
                       "row_stride": 32, "col_stride": 1},
            "local": {"base": 96, "rows": 64, "cols": 32,
                      "row_stride": 32, "col_stride": 1}}}
        if direct_tc:
            mma1["instruction"]["op"] = "mma_shared"
            mma1["instruction"]["b"] = copy.deepcopy(copy_back["instruction"]["shared"])
            commands.extend((fill, a0, b0, wait0, a1, b1, mma0,
                             wait1, mma1, store))
        else:
            commands.extend((fill, a0, b0, wait0, a1, b1, mma0,
                             wait1, copy_back, mma1, store))
    return dict(group, rf_kib=9, sh_kib=8, commands=commands), tiles
