"""Remove persistent-K transposes and read the original K tensor directly."""

import argparse
import copy
import json
from pathlib import Path

from .estimate import estimate_wave, program_records
from .tool import sha, write


def _tensor_table(source):
    tensors = []
    for record in program_records(source):
        if record["record"] in ("input", "alloc"):
            tensors.append({"source": record.get("source"), "len": record["len"],
                            "kind": record["record"]})
        elif record["record"] == "release":
            if record["tensor"] != len(tensors) - 1:
                raise ValueError("unexpected tensor release order")
            tensors.pop()
    return tensors


def _transposed_pairs(source):
    records = program_records(source)
    header = next(records)
    tensors = []
    pairs = set()
    for record in records:
        if record["record"] in ("input", "alloc"):
            tensors.append({"source": record.get("source"), "len": record["len"],
                            "kind": record["record"]})
            continue
        if record["record"] == "release":
            if record["tensor"] != len(tensors) - 1:
                raise ValueError("unexpected tensor release order")
            tensors.pop()
            continue
        if record["record"] != "wave":
            continue
        loads = set()
        stores = set()
        operations = set()
        for group in record["groups"]:
            for command in group["commands"]:
                instruction = command.get("instruction", {})
                operation = instruction.get("op")
                if operation:
                    operations.add(operation)
                if operation == "load":
                    loads.add(instruction["tensor"])
                elif operation == "store":
                    stores.add(instruction["tensor"])
        if operations <= {"load", "store"} and len(loads) == len(stores) == 1:
            source_id = next(iter(loads))
            target_id = next(iter(stores))
            if (source_id < len(tensors) and target_id < len(tensors) and
                    tensors[source_id]["kind"] == "input" and
                    str(tensors[source_id]["source"]).endswith("past_k") and
                    tensors[target_id]["kind"] == "alloc" and
                    tensors[source_id]["len"] == tensors[target_id]["len"]):
                pairs.add((source_id, target_id))
    if len(pairs) != header["shape"]["layers"]:
        raise ValueError(f"expected one persistent-K pair per layer, found {pairs}")
    return header, dict((target, source_id) for source_id, target in pairs)


def _source_view_origin(view, header):
    shape = header["shape"]
    head_width = shape["d"] // shape["heads"]
    capacity = shape["history"] + shape["steps"]
    if (view["row_stride"] != capacity or view["col_stride"] != 1 or
            not 1 <= view["rows"] <= head_width or
            not 1 <= view["cols"] <= capacity):
        raise ValueError(f"unexpected persistent-K view: {view}")
    batch_head_row, context_start = divmod(view["base"], capacity)
    batch_head, row_start = divmod(batch_head_row, head_width)
    batch, head = divmod(batch_head, shape["heads"])
    if (not 0 <= batch < header["batch"] or
            row_start + view["rows"] > head_width or
            context_start + view["cols"] > capacity):
        raise ValueError(f"persistent-K view exceeds tensor: {view}")
    base = (context_start * header["batch"] * shape["d"] +
            batch * shape["d"] +
            head * head_width + row_start)
    return base, header["batch"] * shape["d"]


def _direct_view(view, header):
    base, width = _source_view_origin(view, header)
    return {"base": base,
            "rows": view["rows"], "cols": view["cols"],
            "row_stride": 1, "col_stride": width}


def _on_demand_views(global_view, local_view, header):
    if (local_view["rows"] != global_view["rows"] or
            local_view["cols"] != global_view["cols"]):
        raise ValueError("persistent-K global/local shapes differ")
    base, width = _source_view_origin(global_view, header)
    return (
        {"base": base, "rows": global_view["cols"],
         "cols": global_view["rows"], "row_stride": width,
         "col_stride": 1},
        {"base": local_view["base"], "rows": local_view["cols"],
         "cols": local_view["rows"],
         "row_stride": local_view["col_stride"],
         "col_stride": local_view["row_stride"]},
    )


def _shared_on_demand_views(global_view, local_view, header):
    if (local_view["rows"] != global_view["rows"] or
            local_view["cols"] != global_view["cols"]):
        raise ValueError("persistent-K global/local shapes differ")
    base, width = _source_view_origin(global_view, header)
    context = global_view["cols"]
    head_rows = global_view["rows"]
    return (
        {"base": base, "rows": context, "cols": head_rows,
         "row_stride": width, "col_stride": 1},
        {"base": 0, "rows": context, "cols": head_rows,
         "row_stride": head_rows, "col_stride": 1},
        {"base": 0, "rows": head_rows, "cols": context,
         "row_stride": 1, "col_stride": head_rows},
    )


def _shared_staged_views(global_view, local_view, header):
    if (local_view["rows"] != global_view["rows"] or
            local_view["cols"] != global_view["cols"]):
        raise ValueError("persistent-K global/local shapes differ")
    base, width = _source_view_origin(global_view, header)
    context = global_view["cols"]
    head_rows = global_view["rows"]
    stride = head_rows + 1
    return (
        {"base": base, "rows": context, "cols": head_rows,
         "row_stride": width, "col_stride": 1},
        {"base": 0, "rows": context, "cols": head_rows,
         "row_stride": stride, "col_stride": 1},
        {"base": 0, "rows": head_rows, "cols": context,
         "row_stride": 1, "col_stride": stride},
        copy.deepcopy(local_view),
    )


def _rewrite_wave_shared(record, header, pairs):
    changed = False
    rewritten = copy.deepcopy(record)
    for group in rewritten["groups"]:
        pending = {}
        maximum_words = 0
        for command in group["commands"]:
            instruction = command.get("instruction", {})
            if instruction.get("op") == "load" and instruction["tensor"] in pairs:
                source_tensor = pairs[instruction["tensor"]]
                rf_base = instruction["local"]["base"]
                global_view, shared_load, shared_mma = _shared_on_demand_views(
                    instruction["global"], instruction["local"], header)
                instruction.clear()
                instruction.update({"op": "load_shared", "tensor": source_tensor})
                instruction["global"] = global_view
                instruction["local"] = shared_load
                pending[rf_base] = shared_mma
                maximum_words = max(maximum_words,
                                    shared_load["rows"] * shared_load["cols"])
                changed = True
            elif instruction.get("op") == "mma" and instruction.get("b") in pending:
                instruction["op"] = "mma_shared"
                instruction["b"] = pending.pop(instruction["b"])
        if pending:
            raise ValueError("shared K load has no matching MMA")
        if maximum_words:
            required_kib = ((maximum_words + 1023) // 1024) * 4
            group["sh_kib"] = max(group["sh_kib"], required_kib)
    return rewritten, changed


def _rewrite_wave_shared_staged(record, header, pairs):
    changed = False
    rewritten = copy.deepcopy(record)
    for group in rewritten["groups"]:
        pending = {}
        maximum_words = 0
        commands = []
        for command in group["commands"]:
            instruction = command.get("instruction", {})
            if instruction.get("op") == "load" and instruction["tensor"] in pairs:
                source_tensor = pairs[instruction["tensor"]]
                rf_base = instruction["local"]["base"]
                global_view, shared_load, shared_read, rf_view = _shared_staged_views(
                    instruction["global"], instruction["local"], header)
                replacement = copy.deepcopy(command)
                replacement["instruction"] = {
                    "op": "load_shared", "tensor": source_tensor,
                    "global": global_view, "local": shared_load}
                commands.append(replacement)
                pending[rf_base] = {"op": "shared_read", "shared": shared_read,
                                    "local": rf_view}
                maximum_words = max(maximum_words,
                                    (shared_load["rows"] - 1) * shared_load["row_stride"] +
                                    shared_load["cols"])
                changed = True
                continue
            if instruction.get("op") == "mma" and instruction.get("b") in pending:
                commands.append({"command": "run",
                                 "instruction": pending.pop(instruction["b"])})
            commands.append(command)
        if pending:
            raise ValueError("staged shared K load has no matching MMA")
        group["commands"] = commands
        if maximum_words:
            required_kib = ((maximum_words + 1023) // 1024) * 4
            group["sh_kib"] = max(group["sh_kib"], required_kib)
    return rewritten, changed


def _rewrite_wave(record, header, pairs, mode):
    if mode == "shared-on-demand":
        return _rewrite_wave_shared(record, header, pairs)
    if mode == "shared-staged":
        return _rewrite_wave_shared_staged(record, header, pairs)
    changed = False
    rewritten = copy.deepcopy(record)
    for group in rewritten["groups"]:
        for command in group["commands"]:
            instruction = command.get("instruction", {})
            if instruction.get("op") == "load" and instruction["tensor"] in pairs:
                instruction["tensor"] = pairs[instruction["tensor"]]
                if mode == "strided":
                    instruction["global"] = _direct_view(
                        instruction["global"], header)
                elif mode == "on-demand-transpose":
                    instruction["global"], instruction["local"] = _on_demand_views(
                        instruction["global"], instruction["local"], header)
                else:
                    raise ValueError(f"unknown direct-K mode {mode}")
                changed = True
    return rewritten, changed


def _is_transpose(record, pairs):
    loads = set()
    stores = set()
    operations = set()
    for group in record["groups"]:
        for command in group["commands"]:
            instruction = command.get("instruction", {})
            operation = instruction.get("op")
            if operation:
                operations.add(operation)
            if operation == "load":
                loads.add(instruction["tensor"])
            elif operation == "store":
                stores.add(instruction["tensor"])
    return (operations <= {"load", "store"} and len(loads) == len(stores) == 1 and
            next(iter(stores)) in pairs and pairs[next(iter(stores))] == next(iter(loads)))


def _shared_transpose_waves(header, source, target, feature_tile, context_tile,
                            output_stride=None):
    if (not 1 <= feature_tile <= header["shape"]["d"] or
            not 1 <= context_tile <= 256 or
            feature_tile * context_tile > 16384):
        raise ValueError("invalid shared transpose tile")
    hardware = header["hardware"]
    maximum_words = context_tile * (feature_tile + 1)
    group_sh_kib = ((maximum_words + 1023) // 1024) * 4
    groups_per_sm = min(hardware["resident_groups"],
                        hardware["sh_kib"] // group_sh_kib)
    if groups_per_sm == 0:
        raise ValueError("shared transpose tile exceeds SH capacity")
    shape = header["shape"]
    capacity = shape["history"] + shape["steps"] if output_stride is None else output_stride
    if capacity < shape["history"] + shape["steps"]:
        raise ValueError("transposed K output stride is smaller than logical capacity")
    # The bound input initializes history.  Future rows are added by decode.
    initialized_context = shape["history"]
    tasks = []
    for batch in range(header["batch"]):
        for feature in range(0, shape["d"], feature_tile):
            rows = min(feature_tile, shape["d"] - feature)
            for context in range(0, initialized_context, context_tile):
                cols = min(context_tile, initialized_context - context)
                tasks.append((batch, feature, context, rows, cols))
    slots = hardware["sms"] * groups_per_sm
    # Each task writes at most feature_tile disjoint global row intervals.
    # Keep a wave below the compact evaluator's 262144 interval admission.
    maximum_tasks = min(16384 // 3, 262144 // feature_tile)
    waves = []
    for offset in range(0, len(tasks), maximum_tasks):
        selected = tasks[offset:offset + maximum_tasks]
        groups = [{"sm": index % hardware["sms"], "rf_kib": 1,
                   "sh_kib": group_sh_kib, "commands": []}
                  for index in range(min(slots, len(selected)))]
        tokens = [0] * len(groups)
        for task_index, (batch, feature, context, rows, cols) in enumerate(selected):
            group_index = task_index % len(groups)
            group = groups[group_index]
            tokens[group_index] += 1
            token = tokens[group_index]
            stride = rows + 1
            group["commands"].extend([
                {"command": "async", "token": token, "instruction": {
                    "op": "load_shared", "tensor": source,
                    "global": {"base": context * header["batch"] * shape["d"] +
                               batch * shape["d"] + feature,
                               "rows": cols, "cols": rows,
                               "row_stride": header["batch"] * shape["d"], "col_stride": 1},
                    "local": {"base": 0, "rows": cols, "cols": rows,
                              "row_stride": stride, "col_stride": 1}}},
                {"command": "wait", "tokens": [token]},
                {"command": "run", "instruction": {
                    "op": "store_shared", "tensor": target,
                    "global": {"base": (batch * shape["d"] + feature) * capacity +
                               context,
                               "rows": rows, "cols": cols,
                               "row_stride": capacity, "col_stride": 1},
                    "local": {"base": 0, "rows": rows, "cols": cols,
                              "row_stride": 1, "col_stride": stride}}},
            ])
        waves.append({"record": "wave", "groups": groups})
    return waves, len(tasks), group_sh_kib


def rewrite_shared_transpose(source, destination, feature_tile=128, context_tile=32):
    header, pairs = _transposed_pairs(source)
    if not header["decode"]:
        raise ValueError("shared K transpose applies only to decode programs")
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    emitted = set()
    removed_waves = new_waves = tasks = 0
    records = program_records(source)
    with destination.open("x") as output:
        output.write(json.dumps(next(records), separators=(",", ":")) + "\n")
        for record in records:
            if record["record"] == "wave" and _is_transpose(record, pairs):
                loads = {command["instruction"]["tensor"]
                         for group in record["groups"] for command in group["commands"]
                         if command.get("instruction", {}).get("op") == "load"}
                stores = {command["instruction"]["tensor"]
                          for group in record["groups"] for command in group["commands"]
                          if command.get("instruction", {}).get("op") == "store"}
                pair = next(iter(loads)), next(iter(stores))
                removed_waves += 1
                if pair not in emitted:
                    waves, pair_tasks, _ = _shared_transpose_waves(
                        header, *pair, feature_tile, context_tile)
                    for wave in waves:
                        output.write(json.dumps(wave, separators=(",", ":")) + "\n")
                    emitted.add(pair)
                    new_waves += len(waves)
                    tasks += pair_tasks
                continue
            output.write(json.dumps(record, separators=(",", ":")) + "\n")
    if len(emitted) != len(pairs):
        raise ValueError("shared transpose did not replace every layer")
    return {"source_sha256": sha(source), "program_sha256": sha(destination),
            "feature_tile": feature_tile, "context_tile": context_tile,
            "removed_transpose_waves": removed_waves,
            "replacement_waves": new_waves, "replacement_tasks": tasks}


def screen_shared_transpose_grid(source, baseline_cycles, feature_tiles,
                                 context_tiles, hardware_override=None):
    header, pairs = _transposed_pairs(source)
    if hardware_override is not None:
        header = {**header, "hardware": hardware_override}
    if not header["decode"]:
        raise ValueError("shared K transpose applies only to decode programs")
    if not isinstance(baseline_cycles, (int, float)) or baseline_cycles <= 0:
        raise ValueError("baseline_cycles must be positive")
    feature_tiles = tuple(feature_tiles)
    context_tiles = tuple(context_tiles)
    if not feature_tiles or not context_tiles:
        raise ValueError("shared transpose grid cannot be empty")

    cache = {}
    original = 0
    removed_waves = 0
    records = program_records(source)
    next(records)
    for record in records:
        if record["record"] == "wave" and _is_transpose(record, pairs):
            original += estimate_wave(record["groups"], header["hardware"], cache)
            removed_waves += 1
    if removed_waves == 0:
        raise ValueError("shared transpose grid found no source transpose waves")

    candidates = []
    rejected = []
    for feature_tile in feature_tiles:
        for context_tile in context_tiles:
            replacement = replacement_waves = replacement_tasks = 0
            group_sh_kib = set()
            try:
                for target, source_tensor in sorted(pairs.items()):
                    waves, tasks, sh_kib = _shared_transpose_waves(
                        header, source_tensor, target, feature_tile, context_tile)
                    replacement += sum(
                        estimate_wave(wave["groups"], header["hardware"], cache)
                        for wave in waves)
                    replacement_waves += len(waves)
                    replacement_tasks += tasks
                    group_sh_kib.add(sh_kib)
            except ValueError as error:
                if str(error) not in ("invalid shared transpose tile",
                                      "shared transpose tile exceeds SH capacity"):
                    raise
                rejected.append({"feature_tile": feature_tile,
                                 "context_tile": context_tile,
                                 "reason": str(error)})
                continue
            predicted_cycles = baseline_cycles - original + replacement
            if predicted_cycles <= 0:
                raise ValueError("invalid shared transpose cycle estimate")
            candidates.append({
                "feature_tile": feature_tile,
                "context_tile": context_tile,
                "group_sh_kib": max(group_sh_kib),
                "removed_transpose_waves": removed_waves,
                "replacement_waves": replacement_waves,
                "replacement_tasks": replacement_tasks,
                "original_affected_cycles": original,
                "replacement_affected_cycles": replacement,
                "baseline_cycles": baseline_cycles,
                "predicted_cycles": predicted_cycles,
            })
    candidates.sort(key=lambda item: (item["predicted_cycles"],
                                      item["feature_tile"],
                                      item["context_tile"]))
    return {"program_sha256": sha(source),
            "estimator_scope": "affected-wave delta over declared tile grid",
            "candidates": candidates, "rejected": rejected,
            "numerical_correctness": "not_checked",
            "official_score": None}


def screen_direct_k(source, baseline_cycles, mode="strided"):
    header, pairs = _transposed_pairs(source)
    if not header["decode"]:
        raise ValueError("direct K applies only to decode programs")
    original = replacement = 0
    removed_waves = rewritten_waves = 0
    cache = {}
    records = program_records(source)
    next(records)
    for record in records:
        if record["record"] != "wave":
            continue
        if _is_transpose(record, pairs):
            original += estimate_wave(record["groups"], header["hardware"], cache)
            removed_waves += 1
            continue
        rewritten, changed = _rewrite_wave(record, header, pairs, mode)
        if changed:
            original += estimate_wave(record["groups"], header["hardware"], cache)
            replacement += estimate_wave(rewritten["groups"], header["hardware"], cache)
            rewritten_waves += 1
    predicted_cycles = baseline_cycles - original + replacement
    if predicted_cycles <= 0:
        raise ValueError("invalid direct-K cycle estimate")
    return {"program_sha256": sha(source), "estimator_scope": "affected-wave delta",
            "mode": mode,
            "removed_transpose_waves": removed_waves,
            "rewritten_qk_waves": rewritten_waves,
            "original_affected_cycles": original,
            "replacement_affected_cycles": replacement,
            "baseline_cycles": baseline_cycles,
            "predicted_cycles": predicted_cycles,
            "numerical_correctness": "not_checked", "official_score": None}


def rewrite_program(source, destination, mode="on-demand-transpose"):
    header, pairs = _transposed_pairs(source)
    if not header["decode"]:
        raise ValueError("direct K applies only to decode programs")
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    removed_waves = rewritten_waves = 0
    records = program_records(source)
    with destination.open("w") as output:
        output.write(json.dumps(next(records), separators=(",", ":")) + "\n")
        for record in records:
            if record["record"] == "wave" and _is_transpose(record, pairs):
                removed_waves += 1
                continue
            if record["record"] == "wave":
                record, changed = _rewrite_wave(record, header, pairs, mode)
                rewritten_waves += int(changed)
            output.write(json.dumps(record, separators=(",", ":")) + "\n")
    if removed_waves == 0 or rewritten_waves == 0:
        raise ValueError("direct-K rewrite changed no program work")
    return {"source_sha256": sha(source),
            "program_sha256": sha(destination), "mode": mode,
            "removed_transpose_waves": removed_waves,
            "rewritten_qk_waves": rewritten_waves}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--baseline-cycles", type=int, required=True)
    parser.add_argument("--mode", choices=("strided", "on-demand-transpose",
                                            "shared-on-demand", "shared-staged"),
                        default="strided")
    parser.add_argument("--program-output", type=Path)
    args = parser.parse_args()
    result = screen_direct_k(args.source, args.baseline_cycles, args.mode)
    if args.program_output is not None:
        result["rewrite"] = rewrite_program(
            args.source, args.program_output, args.mode)
    write(args.output, result)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
