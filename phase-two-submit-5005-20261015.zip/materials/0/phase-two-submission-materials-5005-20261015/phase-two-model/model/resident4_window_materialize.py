"""Build a wider-window candidate only after the five-case model gate."""

import argparse
import json
import subprocess
import sys
import tempfile
from pathlib import Path

from .estimate import estimate_program, estimate_wave, program_records
from .resident4_pack_screen import _access_footprint, _pack
from .resident4_pack_materialize import _cross_sm_safe
from .resident4_window_screen import independent
from .tool import STARTER, sha, write


def materialize(source, manifest_path, screen_path, output):
    source, manifest_path, screen_path, output = map(
        Path, (source, manifest_path, screen_path, output))
    manifest = json.loads(manifest_path.read_text())
    screen = json.loads(screen_path.read_text())
    case = screen["case"]
    if (screen["source_sha256"] != sha(source) or
            screen["manifest_sha256"] != sha(manifest_path) or
            manifest["program_sha256"][case] != sha(source) or
            screen["five_case_model_score"] < 5000 or
            not screen["meets_grade_gate"]):
        raise ValueError("screen gate or source identity failed")
    hardware = manifest["hardware"]
    choices = {row["source_start"]: row for row in screen["chosen"]}
    output.mkdir(parents=True, exist_ok=False)
    target = output / f"{case}.jsonl"
    wave_index = source_commands = output_commands = output_waves = 0
    with tempfile.TemporaryDirectory(prefix="resident4-window-") as temporary:
        expanded = Path(temporary) / "expanded.jsonl"
        with expanded.open("x") as writer:
            records = program_records(source)
            header = next(records)
            if header["hardware"] != hardware:
                raise ValueError("source hardware changed")
            writer.write(json.dumps(header, separators=(",", ":")) + "\n")
            for record in records:
                if record.get("record") != "wave":
                    writer.write(json.dumps(record, separators=(",", ":")) + "\n")
                    continue
                row = choices.get(wave_index)
                group_records = [record]
                if row is not None:
                    for _ in range(row["source_waves"] - 1):
                        extra = next(records)
                        if extra.get("record") != "wave":
                            raise ValueError("chosen window crosses a barrier")
                        group_records.append(extra)
                    entries = [(item, 0, _access_footprint(item), index)
                               for index, item in enumerate(group_records)]
                    if not independent(entries):
                        raise ValueError("chosen window has a tensor dependency")
                    packed = _pack(group_records, hardware)
                    if (len(packed) != row["packed_waves"] or
                            any(not _cross_sm_safe(groups) for groups in packed) or
                            sum(estimate_wave(groups, hardware) for groups in packed) != row["cycles"]):
                        raise ValueError("candidate differs from screened window")
                else:
                    packed = [record["groups"]]
                source_commands += sum(len(group["commands"])
                                       for item in group_records for group in item["groups"])
                for groups in packed:
                    output_commands += sum(len(group["commands"]) for group in groups)
                    writer.write(json.dumps({"record": "wave", "groups": groups},
                                            separators=(",", ":")) + "\n")
                wave_index += len(group_records)
                output_waves += len(packed)
        if (wave_index != screen["source_waves"] or
                output_waves != screen["packed_waves"] or
                source_commands != output_commands):
            raise ValueError("candidate coverage or paid command count changed")
        subprocess.run([sys.executable, str(STARTER / "tools/compact_program.py"),
                        str(expanded), str(target)], check=True)
    exact = estimate_program(target)["cycles"]
    if exact != screen["selected_cycles"]:
        raise ValueError("compact candidate differs from complete model screen")
    result = {"case": case, "source_sha256": sha(source),
              "screen_sha256": sha(screen_path), "program_sha256": sha(target),
              "source_waves": wave_index, "output_waves": output_waves,
              "source_commands": source_commands, "output_commands": output_commands,
              "exact_model_cycles": exact,
              "five_case_model_score": screen["five_case_model_score"],
              "hardware": hardware, "grade_allowed": True, "official_score": None}
    write(output / "manifest.json", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("manifest", type=Path)
    parser.add_argument("screen", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    print(json.dumps(materialize(args.source, args.manifest, args.screen, args.output), indent=2))


if __name__ == "__main__":
    main()
