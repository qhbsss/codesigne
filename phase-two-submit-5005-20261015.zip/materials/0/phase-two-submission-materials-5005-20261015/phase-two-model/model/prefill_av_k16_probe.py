"""Probe RF16 causal AV panels in memory, without writing a candidate program.

The existing AV workgroups reserve 32 KiB for an output tile and a K64 panel.
This probe keeps the output tile, splits the ascending K accumulation into K16
panels, and reuses the same score and value elements. Its first purpose is to
price the extra commands against pairing two formerly RF32 waves.
"""

import argparse
import copy
import json
from collections import Counter
from pathlib import Path

from .estimate import estimate_wave, program_records, validate_wave_capacity
from .resident4_pack_screen import _access_footprint, _pack
from .resident4_window_screen import independent
from .tool import sha, write


def _addresses(commands):
    addresses = Counter()
    for command in commands:
        instruction = command.get("instruction", {})
        if instruction.get("op") != "load":
            continue
        view = instruction["global"]
        tensor = instruction["tensor"]
        for row in range(view["rows"]):
            start = view["base"] + row * view["row_stride"]
            for col in range(view["cols"]):
                addresses[tensor, start + col * view["col_stride"]] += 1
    return addresses


def _segments(commands):
    segment = []
    for command in commands:
        segment.append(command)
        if command.get("instruction", {}).get("op") == "store":
            yield segment
            segment = []
    if segment:
        raise ValueError("AV workgroup has commands after the last store")


def retile_segment(segment, context, next_token, check_addresses=False):
    if (not segment or segment[0] != {"command": "run", "instruction":
            {"op": "fill", "dst": 0, "len": 2048, "value": 0.0}} or
            segment[-1]["command"] != "run" or
            segment[-1]["instruction"].get("op") != "store"):
        return None
    store = segment[-1]["instruction"]
    output = store["global"]
    if (output["rows"], output["cols"], output["col_stride"]) != (32, 64, 1):
        return None
    if store["local"] != {"base": 0, "rows": 32, "cols": 64,
                           "row_stride": 64, "col_stride": 1}:
        return None
    query_start, output_col = divmod(output["base"], output["row_stride"])
    if (query_start % 32 or output_col % 64 or
            query_start + 32 > context):
        return None

    scores, values, k_sizes = [], [], []
    for command in segment[1:-1]:
        op = command.get("instruction", {}).get("op")
        if op == "load":
            instruction = command["instruction"]
            local_base = instruction["local"]["base"]
            if 2048 <= local_base < 4096:
                scores.append(instruction)
            elif 4096 <= local_base < 14336:
                values.append(instruction)
            else:
                return None
        elif op == "mma":
            mma = command["instruction"]
            if ((mma["m"], mma["n"], mma["c"]) != (32, 64, 0)
                    or mma["k"] not in (32, 64, 128)):
                return None
            k_sizes.append(mma["k"])
        elif op not in ("fill", None) or (op is None and command["command"] != "wait"):
            return None
    if not scores or not values or sum(k_sizes) != query_start + 32:
        return None
    score_tensors = {instruction["tensor"] for instruction in scores}
    value_tensors = {instruction["tensor"] for instruction in values}
    if len(score_tensors) != 1 or len(value_tensors) != 1:
        return None
    score_tensor = next(iter(score_tensors))
    value_tensor = next(iter(value_tensors))
    value_stride = values[0]["global"]["row_stride"]
    value_col = values[0]["global"]["base"] % value_stride
    if value_col != output_col or value_stride != output["row_stride"]:
        return None

    def issue(instruction):
        nonlocal next_token
        token = next_token
        next_token += 1
        return {"command": "async", "token": token,
                "instruction": instruction}

    rewritten = [copy.deepcopy(segment[0])]
    for panel in range((query_start + 32) // 16):
        key_start = panel * 16
        valid = [max(0, min(16, query_start + row - key_start + 1))
                 for row in range(32)]
        value = issue({
            "op": "load", "tensor": value_tensor,
            "global": {"base": key_start * value_stride + value_col,
                       "rows": 16, "cols": 64,
                       "row_stride": value_stride, "col_stride": 1},
            "local": {"base": 2560, "rows": 16, "cols": 64,
                      "row_stride": 64, "col_stride": 1},
        })
        rewritten.append(value)
        pending = [value["token"]]
        row = 0
        while row < 32:
            if valid[row] == 16:
                end = row + 1
                while end < 32 and valid[end] == 16:
                    end += 1
                score = issue({
                    "op": "load", "tensor": score_tensor,
                    "global": {"base": (query_start + row) * context + key_start,
                               "rows": end - row, "cols": 16,
                               "row_stride": context, "col_stride": 1},
                    "local": {"base": 2048 + row * 16, "rows": end - row,
                              "cols": 16, "row_stride": 16, "col_stride": 1},
                })
                rewritten.append(score)
                pending.append(score["token"])
                row = end
            elif valid[row] > 0:
                count = valid[row]
                score = issue({
                    "op": "load", "tensor": score_tensor,
                    "global": {"base": (query_start + row) * context + key_start,
                               "rows": 1, "cols": count,
                               "row_stride": count, "col_stride": 1},
                    "local": {"base": 2048 + row * 16, "rows": 1,
                              "cols": count, "row_stride": count,
                              "col_stride": 1},
                })
                rewritten.append(score)
                pending.append(score["token"])
                row += 1
            else:
                row += 1
            if len(pending) >= 6:
                rewritten.append({"command": "wait", "tokens": pending})
                pending = []
        if pending:
            rewritten.append({"command": "wait", "tokens": pending})
        for row, count in enumerate(valid):
            if count < 16:
                rewritten.append({"command": "run", "instruction": {
                    "op": "fill", "dst": 2048 + row * 16 + count,
                    "len": 16 - count, "value": 0.0}})
        rewritten.append({"command": "run", "instruction": {
            "op": "mma", "a": 2048, "b": 2560, "c": 0,
            "m": 32, "n": 64, "k": 16}})
    rewritten.append(copy.deepcopy(segment[-1]))
    if check_addresses and _addresses(segment) != _addresses(rewritten):
        raise ValueError("RF16 AV candidate changed score or value addresses")
    return rewritten, next_token


def retile_group(group, context, check_addresses=False):
    if group["rf_kib"] != 32 or group["sh_kib"]:
        return None
    commands = []
    next_token = 1
    try:
        for segment in _segments(group["commands"]):
            result = retile_segment(segment, context, next_token,
                                    check_addresses=check_addresses)
            if result is None:
                return None
            changed, next_token = result
            commands.extend(changed)
    except ValueError:
        return None
    changed_group = dict(group, rf_kib=16, commands=commands)
    return changed_group


def probe(source, wave_index, output):
    source, output = Path(source), Path(output)
    records = program_records(source)
    header = next(records)
    hardware = header["hardware"]
    context = header["shape"]["prefill"]
    windows = []
    index = 0
    for record in records:
        if record.get("record") != "wave":
            continue
        if wave_index <= index <= wave_index + 1:
            windows.append(record)
        index += 1
        if index > wave_index + 1:
            break
    if len(windows) != 2:
        raise ValueError("two adjacent waves are required")
    changed = []
    for wave in windows:
        groups = [retile_group(group, context, check_addresses=True)
                  for group in wave["groups"]]
        if any(group is None for group in groups):
            raise ValueError("wave has a non-AV group")
        validate_wave_capacity(groups, hardware)
        changed.append(dict(wave, groups=groups))
    entries = [(wave, 0, _access_footprint(wave), wave_index + i)
               for i, wave in enumerate(windows)]
    if not independent(entries):
        raise ValueError("cross-wave address dependency prevents packing")
    packed = _pack(changed, hardware)
    if len(packed) != 1:
        raise ValueError("RF16 workgroups do not pack into one wave")
    original = sum(estimate_wave(wave["groups"], hardware)
                   for wave in windows)
    separate = sum(estimate_wave(wave["groups"], hardware)
                   for wave in changed)
    combined = estimate_wave(packed[0], hardware)
    result = {
        "source_sha256": sha(source), "wave_index": wave_index,
        "original_cycles": original, "rf16_separate_cycles": separate,
        "rf16_packed_cycles": combined,
        "model_delta": combined - original,
        "input_address_multisets_equal": True,
        "candidate_program_generated": False,
        "official_score": None,
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    write(output, result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("wave_index", type=int)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    print(json.dumps(probe(args.source, args.wave_index, args.output), indent=2))


if __name__ == "__main__":
    main()
