"""Screen RF staging for the initial decode K transpose without emitting programs.

The source and destination HBM views are unchanged.  Each SH DMA becomes the
corresponding RF DMA, and independent adjacent transpose waves may share a
wave when the RF reservation permits it.  A complete five-case model score is
recorded before the separate materialization command can emit a candidate.
"""

import argparse
import json
import math
import shutil
import subprocess
import sys
import tempfile
from collections import defaultdict
from pathlib import Path

from .estimate import estimate_program, estimate_wave, validate_wave_capacity
from .padded_k_transpose_screen import _records
from .resident4_pack_screen import _pack
from .tool import SCORE_CASES, STARTER, sha, write


MAX_ACCESS_INTERVALS = 262_144


def rf_wave(record, hardware):
    """Move a pure SH transpose to RF, retaining every HBM address and token."""
    groups = []
    for group in record["groups"]:
        if group["rf_kib"] != 1 or not group["sh_kib"]:
            raise ValueError("unexpected transpose reservation")
        commands = []
        local_end = 0
        for command in group["commands"]:
            if command["command"] == "wait":
                commands.append(command)
                continue
            instruction = command["instruction"]
            operation = instruction["op"]
            if operation not in ("load_shared", "store_shared"):
                raise ValueError("non-transpose instruction")
            local = instruction["local"]
            local_end = max(local_end, local["base"] +
                (local["rows"] - 1) * local["row_stride"] +
                (local["cols"] - 1) * local["col_stride"] + 1)
            changed = dict(instruction, op="load" if operation == "load_shared" else "store")
            commands.append(dict(command, instruction=changed))
        rf_kib = max(1, math.ceil(local_end / 256))
        groups.append(dict(group, rf_kib=rf_kib, sh_kib=0, commands=commands))
    validate_wave_capacity(groups, hardware)
    return {"record": "wave", "groups": groups}


def independent_transposes(left, right, pair):
    """Require distinct 64-byte target lines across the proposed wave merger."""
    source, target, pitch = pair
    if source == target or pitch % 16:
        return False
    seen = set()
    for side, record in enumerate((left, right)):
        lines = set()
        for group in record["groups"]:
            for command in group["commands"]:
                instruction = command.get("instruction", {})
                operation = instruction.get("op")
                if operation in ("load_shared", "load"):
                    if instruction["tensor"] != source:
                        return False
                elif operation in ("store_shared", "store"):
                    if instruction["tensor"] != target:
                        return False
                    view = instruction["global"]
                    if (view["cols"] != 16 or view["col_stride"] != 1 or
                            view["base"] % 16 or view["row_stride"] != pitch):
                        return False
                    start = view["base"] // 16
                    step = pitch // 16
                    lines.update(start + row * step for row in range(view["rows"]))
                elif operation is not None:
                    return False
        if side == 1 and not seen.isdisjoint(lines):
            return False
        seen = lines
    return True


def transpose_admission(record, pair):
    """Count compact admission intervals and conservatively reject SM races.

    A contiguous context run within one feature row coalesces to one interval
    in the evaluator's ``(tensor, SM, write, stride)`` bucket.  This shortcut
    is exact for disjoint feature blocks, which is the layout screened here.
    """
    source, target, pitch = pair
    if source == target or pitch % 16:
        raise ValueError("invalid transpose tensors or pitch")
    buckets = defaultdict(list)
    for group in record["groups"]:
        sm = group["sm"]
        for command in group["commands"]:
            instruction = command.get("instruction", {})
            operation = instruction.get("op")
            if operation in ("load", "load_shared"):
                if instruction["tensor"] != source:
                    raise ValueError("transpose reads a non-input tensor")
            elif operation in ("store", "store_shared"):
                if instruction["tensor"] != target:
                    raise ValueError("transpose writes an unexpected tensor")
                view = instruction["global"]
                if (view["col_stride"] != 1 or view["row_stride"] != pitch or
                        view["base"] % pitch + view["cols"] > pitch):
                    raise ValueError("unsupported transpose output view")
                feature = view["base"] // pitch
                context = view["base"] % pitch
                buckets[(sm, feature, view["rows"])].append(
                    (context, context + view["cols"]))
            elif operation is not None:
                raise ValueError("unexpected transpose instruction")
    blocks = sorted((feature, feature + rows, sm, intervals)
                    for (sm, feature, rows), intervals in buckets.items())
    # Reject any feature overlap across different SMs.  Context-disjoint
    # overlaps could be legal, but are outside this compact retile family.
    for index, (start, end, sm, _) in enumerate(blocks):
        for other_start, other_end, other_sm, _ in blocks[index + 1:]:
            if other_start >= end:
                break
            if sm != other_sm and start < other_end:
                raise ValueError("overlapping feature rows across SMs")
    intervals = 0
    for start, end, _, segments in blocks:
        merged = []
        for left, right in sorted(segments):
            if merged and left <= merged[-1][1]:
                merged[-1] = (merged[-1][0], max(right, merged[-1][1]))
            else:
                merged.append((left, right))
        intervals += (end - start) * len(merged)
    if intervals > MAX_ACCESS_INTERVALS:
        raise ValueError("wave distinct access intervals exceed 262144")
    return intervals


def _stage_choice(entries, hardware, pair, cache):
    original = [estimate_wave(record["groups"], hardware, cache)
                for _, record in entries]
    converted = [rf_wave(record, hardware) for _, record in entries]
    rf_cost = [estimate_wave(record["groups"], hardware, cache)
               for record in converted]
    pair_cost = {}
    for index in range(len(entries) - 1):
        if not independent_transposes(entries[index][1], entries[index + 1][1], pair):
            continue
        packed = _pack(converted[index:index + 2], hardware)
        if len(packed) != 1:
            continue
        try:
            transpose_admission({"groups": packed[0]}, pair)
        except ValueError:
            continue
        pair_cost[index] = estimate_wave(packed[0], hardware, cache)

    best = [0] * (len(entries) + 1)
    selection = [None] * len(entries)
    for index in range(len(entries) - 1, -1, -1):
        options = [(original[index], "base", 1, 1)]
        options.append((rf_cost[index], "rf", 1, 1))
        if index in pair_cost:
            options.append((pair_cost[index], "rf_pair", 2, 1))
        cost, mode, width, output_waves = min(
            options, key=lambda item: item[0] + best[index + item[2]])
        best[index] = cost + best[index + width]
        selection[index] = (cost, mode, width, output_waves)

    actions = []
    index = 0
    while index < len(entries):
        cost, mode, width, output_waves = selection[index]
        actions.append({"source_start": entries[index][0], "source_waves": width,
                        "output_waves": output_waves, "mode": mode,
                        "original_cycles": sum(original[index:index + width]),
                        "selected_cycles": cost})
        index += width
    return {"source": pair[0], "target": pair[1], "pitch": pair[2],
            "source_waves": len(entries),
            "original_cycles": sum(original), "selected_cycles": best[0],
            "independent_adjacent_pairs": len(pair_cost),
            "actions": actions}


def screen(source, manifest_path, case, output):
    source, manifest_path, output = map(Path, (source, manifest_path, output))
    manifest = json.loads(manifest_path.read_text())
    if (case not in ("w-d1", "w-d16", "w-d4l") or
            sha(source) != manifest["program_sha256"][case]):
        raise ValueError("case or source SHA mismatch")
    hardware = manifest["hardware"]
    stages = []
    pending = []
    active_pair = None
    wave_index = 0
    cache = {}

    def flush():
        nonlocal pending, active_pair
        if pending:
            stages.append(_stage_choice(pending, hardware, active_pair, cache))
            pending = []
            active_pair = None

    for header, record, pair in _records(source):
        if header["hardware"] != hardware:
            raise ValueError("shared hardware mismatch")
        if pair != active_pair:
            flush()
        if pair is not None:
            pending.append((wave_index, record))
            active_pair = pair
        if record["record"] == "wave":
            wave_index += 1
    flush()
    if len(stages) != 2:
        raise ValueError("expected one initial K transpose per decode layer")
    original = sum(stage["original_cycles"] for stage in stages)
    selected = sum(stage["selected_cycles"] for stage in stages)
    cycles = dict(manifest["model_cycles"])
    cycles[case] += selected - original
    score = 1000 * math.exp(sum(weight * math.log(reference / cycles[name])
                            for name, (reference, weight) in SCORE_CASES.items()))
    result = {"case": case, "source_sha256": sha(source),
              "manifest_sha256": sha(manifest_path),
              "screen_code_sha256": sha(__file__),
              "estimator_sha256": sha(Path(__file__).with_name("estimate.py")),
              "hardware": hardware, "stages": stages,
              "original_affected_cycles": original,
              "selected_affected_cycles": selected,
              "cycle_delta": selected - original,
              "five_case_model_cycles": cycles,
              "five_case_model_score": score,
              "meets_grade_gate": score >= 5000,
              "candidate_program_generated": False, "official_score": None}
    output.parent.mkdir(parents=True, exist_ok=True)
    write(output, result)
    return result


def materialize(source, manifest_path, screen_path, output_dir):
    source, manifest_path, screen_path, output_dir = map(
        Path, (source, manifest_path, screen_path, output_dir))
    result = json.loads(screen_path.read_text())
    case = result["case"]
    if (not result["meets_grade_gate"] or
            result["five_case_model_score"] < 5000 or
            sha(source) != result["source_sha256"] or
            sha(manifest_path) != result["manifest_sha256"] or
            sha(__file__) != result["screen_code_sha256"] or
            sha(Path(__file__).with_name("estimate.py")) != result["estimator_sha256"]):
        raise ValueError("five-case model gate or screened inputs changed")
    manifest = json.loads(manifest_path.read_text())
    if (manifest["hardware"] != result["hardware"] or
            manifest["program_sha256"][case] != result["source_sha256"]):
        raise ValueError("source manifest mismatch")
    hardware = result["hardware"]
    stage_index = 0
    pending = []
    active_pair = None

    def emit_stage(writer):
        nonlocal stage_index, pending, active_pair
        if not pending:
            return
        stage = result["stages"][stage_index]
        if (list(active_pair) != [stage["source"], stage["target"], stage["pitch"]] or
                len(pending) != stage["source_waves"]):
            raise ValueError("transpose stage differs from screen")
        position = 0
        for action in stage["actions"]:
            width = action["source_waves"]
            selected = pending[position:position + width]
            if len(selected) != width:
                raise ValueError("incomplete action")
            if action["mode"] == "base":
                waves = selected
            elif action["mode"] == "rf":
                waves = [rf_wave(selected[0], hardware)]
            elif action["mode"] == "rf_pair":
                if not independent_transposes(selected[0], selected[1], active_pair):
                    raise ValueError("unsafe cross-wave transpose")
                packed = _pack([rf_wave(item, hardware) for item in selected], hardware)
                if len(packed) != 1:
                    raise ValueError("pair no longer fits one wave")
                transpose_admission({"groups": packed[0]}, active_pair)
                waves = [{"record": "wave", "groups": packed[0]}]
            else:
                raise ValueError("unknown action")
            for wave in waves:
                writer.write(json.dumps(wave, separators=(",", ":")) + "\n")
            position += width
        if position != len(pending):
            raise ValueError("not all transpose waves emitted")
        stage_index += 1
        pending = []
        active_pair = None

    with tempfile.TemporaryDirectory(prefix="decode-rf-transpose-", dir="/tmp") as temporary:
        expanded = Path(temporary) / "expanded.jsonl"
        compact = Path(temporary) / f"{case}.jsonl"
        with expanded.open("x") as writer:
            first_header = None
            for header, record, pair in _records(source):
                if first_header is None:
                    first_header = header
                    writer.write(json.dumps(header, separators=(",", ":")) + "\n")
                if pair != active_pair:
                    emit_stage(writer)
                if pair is not None:
                    pending.append(record)
                    active_pair = pair
                else:
                    writer.write(json.dumps(record, separators=(",", ":")) + "\n")
            emit_stage(writer)
        if stage_index != len(result["stages"]):
            raise ValueError("missing transpose stage")
        subprocess.run([sys.executable, str(STARTER / "tools/compact_program.py"),
                        str(expanded), str(compact)], check=True)
        exact = estimate_program(compact)["cycles"]
        if exact != result["five_case_model_cycles"][case]:
            raise ValueError("materialized full model differs from screened model")
        output_dir.mkdir(parents=True, exist_ok=False)
        destination = output_dir / f"{case}.jsonl"
        shutil.move(str(compact), destination)
    receipt = {"case": case, "program_sha256": sha(destination),
               "source_sha256": sha(source), "screen_sha256": sha(screen_path),
               "exact_model_cycles": exact,
               "five_case_model_score": result["five_case_model_score"],
               "grade_allowed": True, "official_score": None}
    write(output_dir / "manifest.json", receipt)
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    probe = sub.add_parser("screen")
    probe.add_argument("source", type=Path)
    probe.add_argument("manifest", type=Path)
    probe.add_argument("case")
    probe.add_argument("output", type=Path)
    emit = sub.add_parser("materialize")
    emit.add_argument("source", type=Path)
    emit.add_argument("manifest", type=Path)
    emit.add_argument("screen", type=Path)
    emit.add_argument("output_dir", type=Path)
    args = parser.parse_args()
    if args.command == "screen":
        result = screen(args.source, args.manifest, args.case, args.output)
        print(json.dumps({key: result[key] for key in (
            "case", "cycle_delta", "five_case_model_score", "meets_grade_gate")}, indent=2))
    else:
        print(json.dumps(materialize(args.source, args.manifest,
                                     args.screen, args.output_dir), indent=2))


if __name__ == "__main__":
    main()
