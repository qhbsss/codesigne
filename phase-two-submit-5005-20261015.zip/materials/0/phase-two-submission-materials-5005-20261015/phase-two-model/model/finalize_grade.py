"""Finish a five-case grade from completed SHA-checked local evaluations."""

import argparse
import hashlib
import json
import math
from pathlib import Path

from .tool import SCORE_CASES, write


def finalize(grade_dir):
    grade_dir = Path(grade_dir)
    contract = json.loads((grade_dir / "contract" / "result.json").read_text())
    cases = contract["evaluation"]["cases"]
    if set(cases) != set(SCORE_CASES):
        raise ValueError("contract does not contain the five score cases")
    hardware = None
    rows = {}
    host_seconds = 0.0
    log_score = 0.0
    for name, case in cases.items():
        standard = grade_dir / "workers" / name / "evaluation" / "result.json"
        resumed = grade_dir / f"resume-{name}" / "result.json"
        path = standard if standard.exists() else resumed
        result = json.loads(path.read_text())
        if result["status"] != "complete" or result["seed"] != contract["seed"]:
            raise ValueError(f"evaluation incomplete or seed mismatch: {name}")
        evaluation = result["evaluation"]
        program = grade_dir / "programs" / f"{name}.jsonl"
        with program.open("rb") as reader:
            digest = hashlib.file_digest(reader, "sha256").hexdigest()
        if evaluation["program_sha256"] != digest:
            raise ValueError(f"program SHA mismatch: {name}")
        if (result["source_sha256"] != contract["source_sha256"] or
                result["contract"] != contract["contract"] or
                result["model"] != contract["model"]):
            raise ValueError(f"evaluator version changed: {name}")
        header = evaluation["header"]
        if any(header[key] != case[key] for key in ("shape", "batch", "decode")):
            raise ValueError(f"workload mismatch: {name}")
        if hardware is not None and header["hardware"] != hardware:
            raise ValueError("shared hardware mismatch")
        hardware = header["hardware"]
        report = evaluation["report"]
        if evaluation.get("comparison") is None or not report["power_pass"] or report["area_au"] > 100:
            raise ValueError(f"numerical check, power or area failed: {name}")
        cycles = report["stats"]["cycles"]
        log_score += case["weight"] * math.log(case["reference_cycles"] / cycles)
        host_seconds += result["host_seconds"]
        rows[name] = {"cycles": cycles, "program_sha256": digest,
                      "evaluation_path": str(path)}
    receipt = {"status": "complete", "contract": contract["contract"],
               "model": contract["model"], "source_sha256": contract["source_sha256"],
               "seed": contract["seed"], "score": 1000 * math.exp(log_score),
               "cases": rows, "hardware": hardware, "host_seconds": host_seconds,
               "note": "Local reproducible result assembled from SHA-checked evaluations."}
    write(grade_dir / "grade.json", receipt)
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("grade_dir", type=Path)
    args = parser.parse_args()
    print(json.dumps(finalize(args.grade_dir), indent=2))


if __name__ == "__main__":
    main()
