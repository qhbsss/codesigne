"""Analytical shared-NoC and local-SH service screen for compact programs.

The ordinary wave estimator charges each DMA for its own global-NoC transfer,
but parallel DMAs compete for one global link. This independent screen counts
the line requests in a program and enforces aggregate global and per-SM service
time in each fenced wave. It does not call the timing backend.

With multicast, the number of merged read returns depends on concurrent
execution. ``merge_fraction`` is an explicit assumption: 0 means no returns
merge, while a ratio measured from a prior run can be used for a fixed program
body. For shared-memory DMA, this screen also counts exact local bank service
per coalesced line and places it on optimistic group dependency paths. The
resulting cycle number is a screening surrogate, not a bound unless the
assumed traffic and dependency durations are proven minima.
"""

import argparse
from functools import lru_cache
import json
import math
from pathlib import Path

from .estimate import (
    _compute_cycles, _dma_lines, estimate_wave, program_records,
    validate_wave_capacity,
)
from .hardware import validate


DMA_OPS = frozenset(("load", "store", "load_shared", "store_shared"))
WRITE_OPS = frozenset(("store", "store_shared"))
SH_DMA_OPS = frozenset(("load_shared", "store_shared"))
# The v09 memory scheduler allows 128 pending line requests per SM. With no
# cache, an unmerged request cannot return earlier than its first NoC tick,
# six-cycle hop, 250-cycle HBM-ready delay, two-cycle HBM service, return NoC
# tick and six-cycle hop: 1 + 6 + 250 + 2 + 1 + 6 = 266 cycles.
PENDING_PER_SM = 128
MIN_MISS_ROUND_TRIP = 266
MIN_HBM_SLOT_RESIDENCE = 259
STEP_FIELDS = (
    "model_cycles", "shared_noc_cycles", "hbm_queue_noc_cycles",
    "credit_noc_cycles", "sh_bank_noc_cycles", "waves", "read_requests",
    "write_requests", "limited_waves", "hbm_queue_limited_waves",
    "credit_limited_waves", "sh_bank_limited_waves",
)


def dma_line_counts(instruction, hardware):
    view = instruction["global"]
    counts, _ = _dma_lines(
        view["base"] % (64 * hardware["hbm_channels"]),
        view["rows"], view["cols"],
        view["row_stride"], view["col_stride"],
        hardware["hbm_channels"],
    )
    return counts


def dma_line_requests(instruction, hardware):
    return sum(dma_line_counts(instruction, hardware))


@lru_cache(maxsize=8192)
def _sh_bank_cycles(global_base_mod_line, rows, cols, global_row_stride,
                    global_col_stride, local_base_mod_banks,
                    local_row_stride, local_col_stride, banks, ports, read):
    """Exact SH port work for the coalesced lines in 16-word DMA batches.

    A load writes every returned word. A store reads SH and broadcasts
    duplicate local addresses within a single global-line transaction.
    """
    cycles = 0
    for start in range(0, rows * cols, 16):
        packets = {}
        for logical in range(start, min(start + 16, rows * cols)):
            row, col = divmod(logical, cols)
            line = (global_base_mod_line + row * global_row_stride
                    + col * global_col_stride) // 16
            local = (local_base_mod_banks + row * local_row_stride
                     + col * local_col_stride)
            packets.setdefault(line, []).append(local)
        for words in packets.values():
            counts = [0] * banks
            seen = set()
            for word in words:
                if not read or word not in seen:
                    counts[word % banks] += 1
                    seen.add(word)
            cycles += max(1, math.ceil(max(counts) / ports))
    return cycles


def sh_bank_cycles(instruction, hardware):
    """Exact local SH read/write port demand for one DMA instruction."""
    operation = instruction["op"]
    if operation not in SH_DMA_OPS:
        return 0
    global_view = instruction["global"]
    local_view = instruction["local"]
    if ((global_view["rows"], global_view["cols"])
            != (local_view["rows"], local_view["cols"])):
        raise ValueError("DMA global/local views have different shapes")
    banks = hardware["sh_banks"]
    if not banks:
        raise ValueError("shared DMA requires SH banks")
    read = operation == "store_shared"
    return _sh_bank_cycles(
        global_view["base"] % 16,
        global_view["rows"], global_view["cols"],
        global_view["row_stride"], global_view["col_stride"],
        local_view["base"] % banks,
        local_view["row_stride"], local_view["col_stride"],
        banks, hardware["shared_ports"] if read else 1, read,
    )


def wave_sh_port_service(groups, hardware):
    """Wave service floor from each SM's independent SH read/write ports."""
    by_sm = [[0, 0] for _ in range(hardware["sms"])]
    for group in groups:
        sm = group["sm"]
        for command in group["commands"]:
            instruction = command.get("instruction")
            if instruction is None or instruction["op"] not in SH_DMA_OPS:
                continue
            read = instruction["op"] == "store_shared"
            by_sm[sm][int(read)] += sh_bank_cycles(instruction, hardware)
    return max((max(ports) for ports in by_sm), default=0)


def wave_traffic(groups, hardware):
    """Return exact unmerged NoC byte demand from a wave's DMA line requests."""
    reads = writes = 0
    endpoint_by_sm = [0] * hardware["sms"]
    read_by_channel = [0] * hardware["hbm_channels"]
    write_by_channel = [0] * hardware["hbm_channels"]
    for group in groups:
        sm = group["sm"]
        for command in group["commands"]:
            if command["command"] == "wait":
                continue
            instruction = command["instruction"]
            if instruction["op"] not in DMA_OPS:
                continue
            counts = dma_line_counts(instruction, hardware)
            requests = sum(counts)
            if instruction["op"] in WRITE_OPS:
                writes += requests
                endpoint_by_sm[sm] += 80 * requests
                for channel, count in enumerate(counts):
                    write_by_channel[channel] += count
            else:
                reads += requests
                endpoint_by_sm[sm] += 72 * requests
                for channel, count in enumerate(counts):
                    read_by_channel[channel] += count
    return {
        "read_requests": reads,
        "write_requests": writes,
        "endpoint_bytes": 72 * reads + 80 * writes,
        "endpoint_by_sm": endpoint_by_sm,
        "read_by_channel": read_by_channel,
        "write_by_channel": write_by_channel,
    }


def hbm_queue_service_cycles(traffic, hardware, merge_fraction=0.0):
    """Wave capacity floor for bounded HBM channel slots, assuming miss count.

    With no cache, each unmerged read or write holds one channel slot for at
    least 259 cycles, from enqueue to local acknowledgement. The read merge
    fraction is distributed uniformly over channels as a screening assumption.
    """
    if hardware["cache_mib"]:
        return 0
    if not 0 <= merge_fraction <= 1:
        raise ValueError("merge_fraction must be between zero and one")
    return max((
        math.ceil((writes + reads * (1 - merge_fraction)) / hardware["hbm_queue"])
        * MIN_HBM_SLOT_RESIDENCE
        for reads, writes in zip(traffic["read_by_channel"],
                                 traffic["write_by_channel"])
    ), default=0)


def dma_credit_duration(instruction, hardware, merge_fraction=0.0):
    """DMA duration floor under an assumed count of unmerged read requests.

    An assumed fraction of read requests can merge into an earlier miss; a
    merged reader may return in less than one HBM round trip. All writes are
    independent HBM transactions. The frontend submits at most two lines and
    generates at most one 16-word address batch per SM per cycle.
    """
    if hardware["cache_mib"]:
        raise ValueError("credit diagnostic requires cache_mib=0")
    if not 0 <= merge_fraction <= 1:
        raise ValueError("merge_fraction must be between zero and one")
    lines = dma_line_requests(instruction, hardware)
    if not lines:
        return 0
    originals = lines if instruction["op"] in WRITE_OPS else lines * (1 - merge_fraction)
    elements = instruction["global"]["rows"] * instruction["global"]["cols"]
    return max(
        math.ceil(originals / PENDING_PER_SM) * MIN_MISS_ROUND_TRIP,
        math.ceil(lines / 2),
        math.ceil(elements / 16),
    )


def group_credit_path(group, hardware, merge_fraction=0.0, cache=None,
                      banked_shared=False):
    """Optimistic dependency path with finite-credit DMA durations.

    Independent DMA commands may start together. Only explicit waits and
    blocking commands serialize them; shared engines and ports are left to the
    original estimator. ``banked_shared`` adds the exact local SH bank work
    of each DMA, but still allows overlap with its HBM and NoC work. This is
    a diagnostic, not a substitute scheduler.
    """
    cache = {} if cache is None else cache
    ready = 0
    tokens = {}
    for command in group["commands"]:
        if command["command"] == "wait":
            ready = max(ready, *(tokens[token] for token in command["tokens"])) + 1
            continue
        instruction = command["instruction"]
        if instruction["op"] in DMA_OPS:
            duration = dma_credit_duration(instruction, hardware, merge_fraction)
            if banked_shared:
                duration = max(duration, sh_bank_cycles(instruction, hardware))
            completed = ready + duration
            if command["command"] == "async":
                tokens[command["token"]] = completed
                ready += 1
            else:
                ready = completed
        else:
            ready += _compute_cycles(instruction, hardware, cache)
    return ready


def wave_credit_path(groups, hardware, merge_fraction=0.0, cache=None,
                     banked_shared=False):
    if hardware["cache_mib"]:
        return 0
    return max(
        (group_credit_path(group, hardware, merge_fraction, cache,
                           banked_shared=banked_shared)
         for group in groups),
        default=0,
    )


def service_cycles(traffic, hardware, merge_fraction=0.0):
    """Rate floor for assumed shared-trunk traffic and exact endpoint traffic."""
    if not 0 <= merge_fraction <= 1:
        raise ValueError("merge_fraction must be between zero and one")
    trunk_bytes = traffic["endpoint_bytes"] - 64 * merge_fraction * traffic["read_requests"]
    global_service = math.ceil(trunk_bytes / hardware["global_noc"])
    endpoint_service = max(
        (math.ceil(byte_count / hardware["sm_noc"])
         for byte_count in traffic["endpoint_by_sm"]),
        default=0,
    )
    return {
        "assumed_trunk_bytes": trunk_bytes,
        "global_service_cycles": global_service,
        "endpoint_service_cycles": endpoint_service,
        "service_cycles": max(global_service, endpoint_service),
    }


def screen_program(path, merge_fraction=0.0, hardware_override=None):
    """Apply fenced-wave shared-link service floors to the existing model."""
    records = program_records(path)
    header = next(records)
    hardware = header["hardware"] if hardware_override is None else hardware_override
    validate(hardware)
    cache = {}
    summary = {
        "program": str(path),
        "hardware": hardware,
        "merge_fraction": merge_fraction,
        "model_cycles": 0,
        "shared_noc_cycles": 0,
        "hbm_queue_noc_cycles": 0,
        "credit_noc_cycles": 0,
        "sh_bank_noc_cycles": 0,
        "waves": 0,
        "limited_waves": 0,
        "hbm_queue_limited_waves": 0,
        "credit_limited_waves": 0,
        "sh_bank_limited_waves": 0,
        "read_requests": 0,
        "write_requests": 0,
        "endpoint_bytes": 0,
        "assumed_trunk_bytes": 0,
        "sum_global_service_cycles": 0,
        "sum_endpoint_service_cycles": 0,
        "largest_wave_uplift": 0,
        "steps": [],
    }
    step = {field: 0 for field in STEP_FIELDS}
    for record in records:
        if record["record"] == "wave":
            groups = record["groups"]
            validate_wave_capacity(groups, hardware)
            old = estimate_wave(groups, hardware, cache)
            traffic = wave_traffic(groups, hardware)
            service = service_cycles(traffic, hardware, merge_fraction)
            corrected = max(old, service["service_cycles"])
            hbm_queue_floor = hbm_queue_service_cycles(
                traffic, hardware, merge_fraction,
            )
            hbm_queue_corrected = max(corrected, hbm_queue_floor)
            credit_path = wave_credit_path(groups, hardware, merge_fraction, cache)
            credit_corrected = max(corrected, credit_path)
            if any(command.get("instruction", {}).get("op") in SH_DMA_OPS
                   for group in groups for command in group["commands"]):
                sh_port = wave_sh_port_service(groups, hardware)
                sh_path = wave_credit_path(groups, hardware, merge_fraction,
                                           cache, banked_shared=True)
            else:
                sh_port = 0
                sh_path = credit_path
            sh_corrected = max(corrected, sh_port, sh_path)
            summary["waves"] += 1
            summary["model_cycles"] += old
            summary["shared_noc_cycles"] += corrected
            summary["hbm_queue_noc_cycles"] += hbm_queue_corrected
            summary["credit_noc_cycles"] += credit_corrected
            summary["sh_bank_noc_cycles"] += sh_corrected
            summary["limited_waves"] += corrected > old
            summary["hbm_queue_limited_waves"] += hbm_queue_corrected > corrected
            summary["credit_limited_waves"] += credit_corrected > corrected
            summary["sh_bank_limited_waves"] += sh_corrected > credit_corrected
            summary["read_requests"] += traffic["read_requests"]
            summary["write_requests"] += traffic["write_requests"]
            summary["endpoint_bytes"] += traffic["endpoint_bytes"]
            summary["assumed_trunk_bytes"] += service["assumed_trunk_bytes"]
            summary["sum_global_service_cycles"] += service["global_service_cycles"]
            summary["sum_endpoint_service_cycles"] += service["endpoint_service_cycles"]
            summary["largest_wave_uplift"] = max(
                summary["largest_wave_uplift"], corrected - old,
            )
            for field, value in (
                ("model_cycles", old),
                ("shared_noc_cycles", corrected),
                ("hbm_queue_noc_cycles", hbm_queue_corrected),
                ("credit_noc_cycles", credit_corrected),
                ("sh_bank_noc_cycles", sh_corrected),
                ("waves", 1),
                ("read_requests", traffic["read_requests"]),
                ("write_requests", traffic["write_requests"]),
                ("limited_waves", corrected > old),
                ("hbm_queue_limited_waves", hbm_queue_corrected > corrected),
                ("credit_limited_waves", credit_corrected > corrected),
                ("sh_bank_limited_waves", sh_corrected > credit_corrected),
            ):
                step[field] += value
        elif record["record"] == "commit":
            summary["model_cycles"] += 1
            summary["shared_noc_cycles"] += 1
            summary["hbm_queue_noc_cycles"] += 1
            summary["credit_noc_cycles"] += 1
            summary["sh_bank_noc_cycles"] += 1
            for field in STEP_FIELDS[:5]:
                step[field] += 1
            summary["steps"].append(step)
            step = {field: 0 for field in STEP_FIELDS}
        elif record["record"] not in ("alloc", "release", "input"):
            raise ValueError("unsupported record")
    if step["waves"]:
        summary["steps"].append(step)
    summary["uplift_cycles"] = summary["shared_noc_cycles"] - summary["model_cycles"]
    summary["hbm_queue_uplift_cycles"] = (
        summary["hbm_queue_noc_cycles"] - summary["shared_noc_cycles"]
    )
    summary["credit_uplift_cycles"] = summary["credit_noc_cycles"] - summary["shared_noc_cycles"]
    summary["sh_bank_uplift_cycles"] = (
        summary["sh_bank_noc_cycles"] - summary["credit_noc_cycles"]
    )
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("program", type=Path)
    parser.add_argument("--merge-fraction", type=float, default=0.0)
    args = parser.parse_args()
    print(json.dumps(screen_program(args.program, args.merge_fraction), indent=2))


if __name__ == "__main__":
    main()
