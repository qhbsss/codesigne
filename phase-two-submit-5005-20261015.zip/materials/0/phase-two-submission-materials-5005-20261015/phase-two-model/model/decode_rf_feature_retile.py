"""Model-screen a feature-major RF transpose of the initial decode K history.

One workgroup owns a whole feature block and writes its context slices in
order.  The evaluator can coalesce those adjacent target intervals, allowing
large independent transpose stages to share a wave.  Programs are emitted
only by ``materialize`` after a complete five-case model score clears 5000.
"""

import argparse
import json
import math
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

from .decode_rf_transpose_screen import transpose_admission
from .estimate import estimate_program, estimate_wave, program_records, validate_wave_capacity
from .padded_k_transpose_screen import _records
from .resident4_pack_screen import _pack
from .tool import SCORE_CASES, STARTER, sha, write


FEATURE_TILES = (192, 256, 384, 496)
CONTEXT_TILE = 16


def _view(base, rows, cols, row_stride, col_stride=1):
    return {"base": base, "rows": rows, "cols": cols,
            "row_stride": row_stride, "col_stride": col_stride}


def feature_waves(header, pair, feature_tile, context_tile=CONTEXT_TILE):
    """Generate one complete history transpose with ordered context slices."""
    source, target, pitch = pair
    shape = header["shape"]
    hardware = header["hardware"]
    if (not header["decode"] or feature_tile < 1 or context_tile < 1 or
            source == target or pitch < shape["history"] + shape["steps"] or
            shape["d"] % shape["heads"]):
        raise ValueError("unsupported decode transpose")
    groups = []
    tasks = 0
    input_pitch = header["batch"] * shape["d"]
    for batch in range(header["batch"]):
        for feature in range(0, shape["d"], feature_tile):
            rows = min(feature_tile, shape["d"] - feature)
            local_stride = rows + 1
            commands = []
            for context in range(0, shape["history"], context_tile):
                cols = min(context_tile, shape["history"] - context)
                token = 1 + len(commands) // 3
                commands.extend((
                    {"command": "async", "token": token, "instruction": {
                        "op": "load", "tensor": source,
                        "global": _view(context * input_pitch + batch * shape["d"] + feature,
                                        cols, rows, input_pitch),
                        "local": _view(0, cols, rows, local_stride)}},
                    {"command": "wait", "tokens": [token]},
                    {"command": "run", "instruction": {
                        "op": "store", "tensor": target,
                        "global": _view((batch * shape["d"] + feature) * pitch + context,
                                        rows, cols, pitch),
                        "local": _view(0, rows, cols, 1, local_stride)}},
                ))
                tasks += 1
            maximum_words = context_tile * local_stride
            groups.append({"sm": len(groups) % hardware["sms"],
                           "rf_kib": math.ceil(maximum_words / 256),
                           "sh_kib": 0, "commands": commands})
    # _pack enforces RF, group-slot, SH and command budgets.  Since each group
    # owns unique feature rows, any partition preserves data independence.
    packed = _pack([{"groups": groups}], hardware)
    waves = []
    intervals = []
    for selected in packed:
        validate_wave_capacity(selected, hardware)
        wave = {"record": "wave", "groups": selected}
        intervals.append(transpose_admission(wave, pair))
        waves.append(wave)
    return waves, {"feature_tile": feature_tile, "context_tile": context_tile,
                   "feature_groups": len(groups), "tasks": tasks,
                   "waves": len(waves), "access_intervals_per_wave": intervals,
                   "maximum_rf_kib": max(group["rf_kib"] for group in groups)}


def screen(source, manifest_path, case, output, feature_tiles=FEATURE_TILES):
    source, manifest_path, output = map(Path, (source, manifest_path, output))
    manifest = json.loads(manifest_path.read_text())
    if (case not in ("w-d1", "w-d16", "w-d4l") or
            sha(source) != manifest["program_sha256"][case]):
        raise ValueError("case or source SHA mismatch")
    header = next(program_records(source))
    hardware = manifest["hardware"]
    if header["hardware"] != hardware:
        raise ValueError("shared hardware mismatch")
    cache = {}
    stage_waves = {}
    for _, record, pair in _records(source):
        if pair is not None:
            stage_waves.setdefault(pair, []).append(record)
    if len(stage_waves) != shape_layers(header):
        raise ValueError("initial K transpose pair count differs from layer count")
    original = sum(estimate_wave(wave["groups"], hardware, cache)
                   for waves in stage_waves.values() for wave in waves)
    rows = []
    for feature_tile in feature_tiles:
        try:
            total = 0
            stages = []
            for pair in stage_waves:
                waves, details = feature_waves(header, pair, feature_tile)
                cost = sum(estimate_wave(wave["groups"], hardware, cache)
                           for wave in waves)
                total += cost
                stages.append({"source": pair[0], "target": pair[1],
                               "pitch": pair[2], "model_cycles": cost, **details})
            cycles = dict(manifest["model_cycles"])
            cycles[case] += total - original
            score = 1000 * math.exp(sum(weight * math.log(reference / cycles[name])
                                    for name, (reference, weight) in SCORE_CASES.items()))
            rows.append({"feature_tile": feature_tile,
                         "replacement_cycles": total, "cycle_delta": total - original,
                         "stages": stages, "five_case_model_cycles": cycles,
                         "five_case_model_score": score,
                         "meets_grade_gate": score >= 5000})
        except ValueError as error:
            rows.append({"feature_tile": feature_tile, "infeasible": str(error)})
        output.parent.mkdir(parents=True, exist_ok=True)
        write(output, {"case": case, "source_sha256": sha(source),
                       "manifest_sha256": sha(manifest_path),
                       "screen_code_sha256": sha(__file__),
                       "estimator_sha256": sha(Path(__file__).with_name("estimate.py")),
                       "admission_code_sha256": sha(Path(__file__).with_name(
                           "decode_rf_transpose_screen.py")),
                       "hardware": hardware, "original_affected_cycles": original,
                       "original_affected_waves": sum(map(len, stage_waves.values())),
                       "options": rows, "candidate_program_generated": False,
                       "official_score": None})
        print(case, feature_tile, rows[-1].get("replacement_cycles"),
              rows[-1].get("five_case_model_score"), flush=True)
    return rows


def shape_layers(header):
    return header["shape"]["layers"]


def materialize(source, manifest_path, screen_path, feature_tile, output_dir):
    source, manifest_path, screen_path, output_dir = map(
        Path, (source, manifest_path, screen_path, output_dir))
    result = json.loads(screen_path.read_text())
    matches = [option for option in result["options"]
               if option["feature_tile"] == feature_tile]
    if len(matches) != 1:
        raise ValueError("feature tile was not screened")
    option = matches[0]
    if (not option.get("meets_grade_gate") or
            option["five_case_model_score"] < 5000 or
            sha(source) != result["source_sha256"] or
            sha(manifest_path) != result["manifest_sha256"] or
            sha(__file__) != result["screen_code_sha256"] or
            sha(Path(__file__).with_name("estimate.py")) != result["estimator_sha256"] or
            sha(Path(__file__).with_name("decode_rf_transpose_screen.py")) !=
            result["admission_code_sha256"]):
        raise ValueError("five-case model gate or screened inputs changed")
    manifest = json.loads(manifest_path.read_text())
    case = result["case"]
    if (manifest["hardware"] != result["hardware"] or
            manifest["program_sha256"][case] != result["source_sha256"]):
        raise ValueError("source manifest mismatch")
    with tempfile.TemporaryDirectory(prefix="decode-rf-feature-", dir="/tmp") as temporary:
        expanded = Path(temporary) / "expanded.jsonl"
        compact = Path(temporary) / f"{case}.jsonl"
        emitted = set()
        header_written = False
        with expanded.open("x") as writer:
            for header, record, pair in _records(source):
                if not header_written:
                    writer.write(json.dumps(header, separators=(",", ":")) + "\n")
                    header_written = True
                if pair is None:
                    writer.write(json.dumps(record, separators=(",", ":")) + "\n")
                elif pair not in emitted:
                    emitted.add(pair)
                    waves, details = feature_waves(header, pair, feature_tile)
                    screened = next((stage for stage in option["stages"]
                                     if (stage["source"], stage["target"], stage["pitch"]) == pair), None)
                    if screened is None or any(details[key] != screened[key] for key in details):
                        raise ValueError("retiled stage differs from screen")
                    for wave in waves:
                        writer.write(json.dumps(wave, separators=(",", ":")) + "\n")
        if len(emitted) != shape_layers(header):
            raise ValueError("missing initial K transpose")
        subprocess.run([sys.executable, str(STARTER / "tools/compact_program.py"),
                        str(expanded), str(compact)], check=True)
        exact = estimate_program(compact)["cycles"]
        if exact != option["five_case_model_cycles"][case]:
            raise ValueError("materialized full model differs from in-memory screen")
        output_dir.mkdir(parents=True, exist_ok=False)
        destination = output_dir / f"{case}.jsonl"
        shutil.move(str(compact), destination)
    receipt = {"case": case, "source_sha256": sha(source),
               "program_sha256": sha(destination), "screen_sha256": sha(screen_path),
               "feature_tile": feature_tile, "context_tile": CONTEXT_TILE,
               "exact_model_cycles": exact,
               "five_case_model_score": option["five_case_model_score"],
               "grade_allowed": True, "official_score": None}
    write(output_dir / "manifest.json", receipt)
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    probe = sub.add_parser("screen")
    probe.add_argument("source", type=Path)
    probe.add_argument("manifest", type=Path)
    probe.add_argument("case")
    probe.add_argument("output", type=Path)
    probe.add_argument("--feature-tiles", type=int, nargs="+", default=FEATURE_TILES)
    emit = sub.add_parser("materialize")
    emit.add_argument("source", type=Path)
    emit.add_argument("manifest", type=Path)
    emit.add_argument("screen", type=Path)
    emit.add_argument("feature_tile", type=int)
    emit.add_argument("output_dir", type=Path)
    args = parser.parse_args()
    if args.command == "screen":
        screen(args.source, args.manifest, args.case, args.output,
               tuple(args.feature_tiles))
    else:
        print(json.dumps(materialize(args.source, args.manifest, args.screen,
                                     args.feature_tile, args.output_dir), indent=2))


if __name__ == "__main__":
    main()
