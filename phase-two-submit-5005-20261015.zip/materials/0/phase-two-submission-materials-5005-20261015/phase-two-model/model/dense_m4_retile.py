"""Retile complete M4 dense GEMM K ranges while retaining fused epilogues."""

import copy
import math

from .ksplit_screen import _end


def _tile(commands):
    if (len(commands) < 35 or
            commands[0].get("instruction", {}).get("op") != "fill" or
            commands[-1].get("instruction", {}).get("op") != "store"):
        return None
    accumulator = commands[0]["instruction"]["dst"]
    quartets = []
    pos = 1
    while pos + 3 < len(commands):
        a, b, wait, mma = commands[pos:pos + 4]
        ia, ib, im = (item.get("instruction", {}) for item in (a, b, mma))
        if (a.get("command") != "async" or b.get("command") != "async"
                or wait != {"command": "wait", "tokens": [a.get("token"), b.get("token")]}
                or mma.get("command") != "run"
                or (ia.get("op"), ib.get("op"), im.get("op")) != ("load", "load", "mma")
                or (im.get("m"), im.get("n"), im.get("k"), im.get("c")) !=
                (4, 32, 128, accumulator)):
            break
        quartets.append((ia, ib, im))
        pos += 4
    if len(quartets) < 8 or pos >= len(commands):
        return None
    first_a, first_b, first_mma = quartets[0]
    if (first_a["global"]["rows"] != 4 or first_a["global"]["cols"] != 128
            or first_b["global"]["rows"] != 128 or first_b["global"]["cols"] != 32
            or first_a["global"]["col_stride"] != 1 or
            first_b["global"]["col_stride"] != 1):
        return None
    for index, (a, b, mma) in enumerate(quartets):
        offset = index * 128
        if (a["tensor"] != first_a["tensor"] or b["tensor"] != first_b["tensor"]
                or a["global"]["base"] != first_a["global"]["base"] + offset
                or b["global"]["base"] !=
                first_b["global"]["base"] + offset * first_b["global"]["row_stride"]
                or a["global"]["row_stride"] != first_a["global"]["row_stride"]
                or b["global"]["row_stride"] != first_b["global"]["row_stride"]
                or a["global"]["rows"] != 4 or a["global"]["cols"] != 128
                or b["global"]["rows"] != 128 or b["global"]["cols"] != 32
                or mma["a"] != a["local"]["base"]
                or mma["b"] != b["local"]["base"]):
            return None
    return first_a, first_b, first_mma, len(quartets) * 128, pos


def retile_group(group, panel_k):
    if not 16 <= panel_k <= 110 or group["sh_kib"]:
        return group, 0
    commands = group["commands"]
    tiles = []
    start = 0
    for index, command in enumerate(commands):
        if command.get("instruction", {}).get("op") != "store":
            continue
        tile = commands[start:index + 1]
        parsed = _tile(tile)
        if parsed is None:
            return group, 0
        tiles.append((tile, parsed))
        start = index + 1
    if not tiles or start != len(commands):
        return group, 0
    output = []
    token = 1
    for tile, (first_a, first_b, first_mma, total_k, epilogue_start) in tiles:
        output.append(copy.deepcopy(tile[0]))
        for offset in range(0, total_k, panel_k):
            length = min(panel_k, total_k - offset)
            a = copy.deepcopy(first_a)
            b = copy.deepcopy(first_b)
            mma = copy.deepcopy(first_mma)
            a["global"]["base"] += offset
            a["global"]["cols"] = length
            a["local"].update(base=128, cols=length, row_stride=length)
            b["global"]["base"] += offset * b["global"]["row_stride"]
            b["global"]["rows"] = length
            b["local"].update(base=128 + 4 * panel_k, rows=length)
            mma.update(a=128, b=128 + 4 * panel_k, k=length)
            output.extend((
                {"command": "async", "token": token, "instruction": a},
                {"command": "async", "token": token + 1, "instruction": b},
                {"command": "wait", "tokens": [token, token + 1]},
                {"command": "run", "instruction": mma},
            ))
            token += 2
        output.extend(copy.deepcopy(tile[epilogue_start:]))
    words = max((_end(command["instruction"]) for command in output
                 if "instruction" in command), default=1)
    return dict(group, rf_kib=math.ceil(words / 256), commands=output), len(tiles)
