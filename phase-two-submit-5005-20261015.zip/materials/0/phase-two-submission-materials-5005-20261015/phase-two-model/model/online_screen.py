"""Independently price a fused attention stage before exporting large programs."""

import argparse
import json
from pathlib import Path

from .causal import _score_tensors
from .estimate import estimate_wave, program_records
from .online_attention import _online_waves
from .tool import MODEL, SCORE_CASES, sha, write


def screen(source, output, row_tile, key_block, base_solution,
           reuse_original=None, algorithm="online"):
    source = Path(source)
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    source_hash = sha(source)
    estimator_hash = sha(Path(__file__).with_name("estimate.py"))
    baseline = json.loads(Path(base_solution).read_text())
    selected = baseline["selected_programs"]["a-p"]
    if selected["program_sha256"] != source_hash:
        raise ValueError("screen must replace the SHA-pinned MIP-selected a-p program")
    records = program_records(source)
    header = next(records)
    shape = header["shape"]
    score_ids = _score_tensors(source, shape["prefill"], shape["heads"], shape["layers"])
    if algorithm == "online":
        wave_factory = _online_waves
    elif algorithm == "rf":
        from .rf_softmax import rf_waves
        wave_factory = rf_waves
    elif algorithm == "two-pass":
        from .two_pass_attention import two_pass_waves
        wave_factory = two_pass_waves
    else:
        raise ValueError(f"unknown attention algorithm: {algorithm}")
    identity = {"source_sha256": source_hash, "estimator_sha256": estimator_hash,
                "row_tile": row_tile, "key_block": key_block, "algorithm": algorithm}
    old_path = output / "original-stage-progress.json"
    progress = (json.loads(old_path.read_text()) if old_path.exists() else
                {**identity, "processed_waves": 0, "stage_waves": 0, "cycles": 0,
                 "stages": []})
    progress.setdefault("algorithm", "online")
    if any(progress[key] != value for key, value in identity.items()):
        raise ValueError("original attention checkpoint differs from source/model")
    if reuse_original is not None and not old_path.exists():
        reuse = json.loads(Path(reuse_original).read_text())
        if (reuse["source_sha256"] != source_hash or
                reuse["estimator_sha256"] != estimator_hash or
                len(reuse["stages"]) != shape["layers"]):
            raise ValueError("reused attention stage has different source/model or is incomplete")
        progress = {**reuse, **identity}
        write(old_path, progress)
    cache = {}
    active = None
    wave_index = 0
    tensor_lengths = []
    for record in ([] if reuse_original is not None and progress["stages"] else records):
        if record["record"] in ("input", "alloc"):
            tensor_lengths.append(record["len"])
        elif record["record"] == "release":
            if record["tensor"] != len(tensor_lengths) - 1:
                raise ValueError("unexpected tensor release order")
            tensor_lengths.pop()
        if record["record"] != "wave":
            if active is not None:
                if active["value"] is None:
                    raise ValueError("attention stage ends without AV")
                if wave_index >= progress["processed_waves"]:
                    progress["stages"].append(active)
            active = None
            continue
        reads = set()
        writes = set()
        for group in record["groups"]:
            for command in group["commands"]:
                instruction = command.get("instruction", {})
                if instruction.get("op") == "load":
                    reads.add(instruction["tensor"])
                elif instruction.get("op") == "store":
                    writes.add(instruction["tensor"])
        if (reads | writes) & score_ids:
            if active is None:
                active = {"stage_start": wave_index, "query": None, "key": None,
                          "value": None, "output": None, "key_layout": None}
                starts = reads - score_ids
                candidate = [index for index in starts
                             if index < len(tensor_lengths) and
                             tensor_lengths[index] == 3 * shape["prefill"] * shape["d"]]
                if len(candidate) != 1 or len(starts) != 2:
                    raise ValueError("ambiguous online QKV/K input")
                active["query"] = candidate[0]
                active["key"] = (starts - set(candidate)).pop()
                key_views = {tuple(instruction["global"][field]
                                   for field in ("row_stride", "col_stride"))
                             for group in record["groups"]
                             for command in group["commands"]
                             for instruction in [command.get("instruction", {})]
                             if (instruction.get("op") == "load" and
                                 instruction["tensor"] == active["key"])}
                if key_views == {(shape["prefill"], 1)}:
                    active["key_layout"] = "transposed"
                elif key_views == {(1, shape["d"])}:
                    active["key_layout"] = "strided"
                else:
                    raise ValueError(f"unsupported K layout: {key_views}")
            outputs = writes - score_ids
            if outputs:
                values = reads - score_ids
                if len(values) != 1 or len(outputs) != 1:
                    raise ValueError("ambiguous AV output")
                active["value"] = values.pop()
                active["output"] = outputs.pop()
            if wave_index >= progress["processed_waves"]:
                progress["cycles"] += estimate_wave(record["groups"], header["hardware"], cache)
                progress["stage_waves"] += 1
        elif active is not None:
            if active["value"] is None:
                raise ValueError("attention stage ends without AV")
            if wave_index >= progress["processed_waves"]:
                progress["stages"].append(active)
            active = None
        wave_index += 1
        if wave_index > progress["processed_waves"]:
            progress["processed_waves"] = wave_index
            write(old_path, progress)
    if active is not None:
        if active["value"] is None:
            raise ValueError("attention stage ends without AV")
        progress["stages"].append(active)
    write(old_path, progress)
    if len(progress["stages"]) != shape["layers"]:
        raise ValueError("expected one complete attention stage per layer")
    new_path = output / "online-stage-progress.json"
    replacement = (json.loads(new_path.read_text()) if new_path.exists() else
                   {**identity, "processed_waves": 0, "cycles": 0})
    replacement.setdefault("algorithm", "online")
    if any(replacement[key] != value for key, value in identity.items()):
        raise ValueError("replacement attention checkpoint differs from source/model")
    wave_index = 0
    for stage in progress["stages"]:
        for record in wave_factory(header, stage["query"], stage["key"],
                                   stage["value"], stage["output"],
                                   stage["key_layout"], row_tile, key_block):
            if wave_index >= replacement["processed_waves"]:
                replacement["cycles"] += estimate_wave(record["groups"], header["hardware"], cache)
                replacement["processed_waves"] = wave_index + 1
                write(new_path, replacement)
            wave_index += 1
            if replacement["cycles"] >= progress["cycles"]:
                cycle_floor = (selected["estimated_cycles"] - progress["cycles"] +
                               replacement["cycles"])
                score_ceiling = (baseline["conditional_predicted_score"] *
                                 (selected["estimated_cycles"] / cycle_floor) **
                                 SCORE_CASES["a-p"][1])
                result = {
                    **identity,
                    "scope": "fixed four cases and one shared hardware",
                    "status": "dominated_by_existing_a_p_in_additive_estimator",
                    "original_stage_cycles": progress["cycles"],
                    "replacement_paid_cycles_so_far": replacement["cycles"],
                    "stage_waves_priced": replacement["processed_waves"],
                    "case_cycle_floor_in_estimator": cycle_floor,
                    "conditional_score_ceiling_in_estimator": score_ceiling,
                    "meets_grade_gate": False,
                    "official_score": None,
                }
                write(output / "screen.json", result)
                return result
    predicted_cycles = selected["estimated_cycles"] - progress["cycles"] + replacement["cycles"]
    if predicted_cycles <= 0:
        raise ValueError("invalid independent replacement estimate")
    weight = SCORE_CASES["a-p"][1]
    predicted_score = (baseline["conditional_predicted_score"] *
                       (selected["estimated_cycles"] / predicted_cycles) ** weight)
    grade_threshold = max(5000, baseline["conditional_predicted_score"] + 500)
    result = {**identity, "original_stage_cycles": progress["cycles"],
              "replacement_stage_cycles": replacement["cycles"],
              "original_case_cycles": selected["estimated_cycles"],
              "predicted_case_cycles": predicted_cycles,
              "conditional_score_if_replaced": predicted_score,
              "minimum_full_grade_prediction": grade_threshold,
              "meets_grade_gate": predicted_score >= grade_threshold,
              "not_an_independent_validated_full_program": True,
              "numerical_correctness": "not_checked", "official_score": None}
    write(output / "screen.json", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--row-tile", type=int, default=16)
    parser.add_argument("--key-block", type=int, default=64)
    parser.add_argument("--base-solution", type=Path,
                        default=MODEL / "runs/portfolio-mip-20261012/solution.json")
    parser.add_argument("--reuse-original", type=Path)
    parser.add_argument("--algorithm", choices=("online", "rf", "two-pass"),
                        default="online")
    args = parser.parse_args()
    print(json.dumps(screen(args.source, args.output, args.row_tile,
                            args.key_block, args.base_solution, args.reuse_original,
                            args.algorithm), indent=2))


if __name__ == "__main__":
    main()
