"""Screen moving attention score scaling to each Q vector once per layer."""

import argparse
import json
import math
from pathlib import Path

from .estimate import estimate_wave, program_records, validate_wave_capacity
from .ksplit_screen import _pack_waves, split_group
from .tool import sha, write


def _view(base, rows, cols, stride):
    return {"base": base, "rows": rows, "cols": cols,
            "row_stride": stride, "col_stride": 1}


def _q_scale_wave(shape, hardware, tensor, scale):
    d, rows = shape["d"], shape["prefill"]
    tile = min(16, 8192 // d, 16384 // d, 8192 // d)
    if tile < 1:
        raise ValueError("Q vector too wide for paid vector instruction")
    groups = []
    count = min(hardware["sms"] * hardware["resident_groups"],
                math.ceil(rows / tile))
    for index in range(count):
        start = index * math.ceil(rows / count / tile) * tile
        end = min(rows, start + math.ceil(rows / count / tile) * tile)
        if start >= end:
            continue
        commands = []
        token = 0
        for row in range(start, end, tile):
            height = min(tile, end - row)
            token += 1
            commands.extend((
                {"command": "async", "token": token,
                 "instruction": {"op": "load", "tensor": tensor,
                                 "global": _view(row * 3 * d, height, d, 3 * d),
                                 "local": _view(0, height, d, d)}},
                {"command": "wait", "tokens": [token]},
                {"command": "run", "instruction": {
                    "op": "vector", "kind": "mul", "dst": 0, "len": height * d,
                    "a": {"kind": "reg", "base": 0, "stride": 1},
                    "b": {"kind": "imm", "value": scale}}},
                {"command": "run", "instruction": {"op": "store", "tensor": tensor,
                    "global": _view(row * 3 * d, height, d, 3 * d),
                    "local": _view(0, height, d, d)}},
            ))
        groups.append({"sm": index % hardware["sms"],
                       "rf_kib": math.ceil(tile * d * 4 / 1024),
                       "sh_kib": 0, "commands": commands})
    validate_wave_capacity(groups, hardware)
    return groups


def _scaled_group(group, scale):
    commands = group["commands"]
    exps = sum(command.get("instruction", {}).get("kind") == "exp"
               for command in commands)
    if not exps:
        return group, 0
    output = []
    removed = 0
    for command in commands:
        instruction = command.get("instruction", {})
        left = instruction.get("a", {})
        right = instruction.get("b", {})
        if (instruction.get("op") == "vector" and
                instruction.get("kind") == "mul" and
                left.get("kind") == "reg" and left.get("stride") == 1 and
                left.get("base") == instruction["dst"] and
                right == {"kind": "imm", "value": scale}):
            removed += 1
            continue
        output.append(command)
    if removed != exps:
        raise ValueError("softmax scale/exp rows are not in one-to-one form")
    return dict(group, commands=output), removed


def screen_case(source, hardware, baseline_cycles, max_k):
    records = program_records(source)
    header = next(records)
    if header["decode"] or header["batch"] != 1:
        raise ValueError("query scaling requires batch-one prefill")
    shape = header["shape"]
    expected_scale = 1 / math.sqrt(shape["d"] // shape["heads"])
    scale = None
    score_savings = 0
    removed_commands = softmax_waves = 0
    qkv_allocations = []
    cache = {}
    for record in records:
        if record["record"] == "alloc" and record["len"] == 3 * shape["prefill"] * shape["d"]:
            qkv_allocations.append(record)
        if record["record"] != "wave":
            continue
        original = record["groups"]
        if not any(command.get("instruction", {}).get("kind") == "exp"
                   for group in original for command in group["commands"]):
            continue
        constants = {command["instruction"]["b"]["value"]
                     for group in original for command in group["commands"]
                     if command.get("instruction", {}).get("op") == "vector"
                     and command["instruction"].get("kind") == "mul"
                     and command["instruction"]["b"].get("kind") == "imm"
                     and math.isclose(command["instruction"]["b"]["value"],
                                      expected_scale, rel_tol=1e-6)}
        if len(constants) != 1:
            raise ValueError(f"expected one score scale constant, got {constants}")
        wave_scale = constants.pop()
        if scale is not None and scale != wave_scale:
            raise ValueError("score scales differ between waves")
        scale = wave_scale
        replacement = []
        count = 0
        for group in original:
            changed, n = _scaled_group(group, wave_scale)
            replacement.append(changed)
            count += n
        if not count:
            continue
        original = [split_group(group, max_k, False)[0] for group in original]
        replacement = [split_group(group, max_k, False)[0] for group in replacement]
        old = sum(estimate_wave(batch, hardware, cache)
                  for batch in _pack_waves(original, hardware))
        new = sum(estimate_wave(batch, hardware, cache)
                  for batch in _pack_waves(replacement, hardware))
        score_savings += old - new
        removed_commands += count
        softmax_waves += 1
    if len(qkv_allocations) != shape["layers"]:
        raise ValueError(f"expected {shape['layers']} QKV allocations, found {len(qkv_allocations)}")
    if scale is None:
        raise ValueError("no score scale found")
    # Tensor ID does not affect the paid DMA equations; actual placement is
    # resolved when materializing the qualified static program.
    group_wave = _q_scale_wave(shape, hardware, 0, scale)
    q_scale_cycles = estimate_wave(group_wave, hardware, cache) * shape["layers"]
    predicted = baseline_cycles - score_savings + q_scale_cycles
    return {"source_sha256": sha(source), "scale": scale,
            "softmax_waves": softmax_waves,
            "score_scale_commands_removed": removed_commands,
            "score_scale_cycles_saved": score_savings,
            "query_scale_cycles_added": q_scale_cycles,
            "delta_cycles": predicted - baseline_cycles,
            "predicted_cycles": predicted,
            "numerical_correctness": "not_checked; FP32 accumulation order changes"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("base_solution", type=Path)
    parser.add_argument("ksplit_screen", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    base = json.loads(args.base_solution.read_text())
    prior = json.loads(args.ksplit_screen.read_text())
    result = {}
    for case in ("w-p", "a-p"):
        source = base["selected_programs"][case]["program"]
        max_k = prior.get("case_max_k", {}).get(case, prior["max_k"])
        result[case] = screen_case(source, prior["hardware"],
                                   prior["cases"][case]["cycles"], max_k)
        print(case, result[case], flush=True)
    write(args.output, {"cases": result, "candidate_program_generated": False,
                        "official_score": None})


if __name__ == "__main__":
    main()
