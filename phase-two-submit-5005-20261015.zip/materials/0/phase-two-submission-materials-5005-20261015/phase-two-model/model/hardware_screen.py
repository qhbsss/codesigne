"""Screen shared hardware against SHA-pinned program bodies without copying JSONL."""

import argparse
import json
import math
from pathlib import Path

from .estimate import InfeasibleProgramError, estimate_program
from .hardware import area, validate
from .tool import SCORE_CASES, sha, write


def _read(path):
    return json.loads(Path(path).read_text())


def _save(path, value):
    temporary = path.with_suffix(".json.tmp")
    write(temporary, value)
    temporary.replace(path)


def screen(spec_path, output, max_new=None):
    spec_path, output = Path(spec_path), Path(output)
    spec = _read(spec_path)
    if set(spec) != {"base_solution", "target_score", "hardware_options"}:
        raise ValueError("screen spec requires base_solution, target_score and hardware_options")
    if spec["target_score"] < 5000:
        raise ValueError("real-grade screen threshold must be at least 5000")
    if max_new is not None and max_new < 0:
        raise ValueError("max_new must be nonnegative")
    base_path = Path(spec["base_solution"])
    base = _read(base_path)
    if set(base["selected_programs"]) != set(SCORE_CASES):
        raise ValueError("base solution must cover all five cases")
    identity = {"spec_sha256": sha(spec_path), "base_solution_sha256": sha(base_path),
                "estimator_sha256": sha(Path(__file__).with_name("estimate.py"))}
    output.mkdir(parents=True, exist_ok=True)
    checkpoint = output / "progress.json"
    progress = _read(checkpoint) if checkpoint.exists() else {**identity, "estimates": {}}
    if any(progress.get(key) != value for key, value in identity.items()):
        raise ValueError("screen checkpoint differs from spec, solution or estimator")
    sources = {}
    for case, selected in base["selected_programs"].items():
        program = Path(selected["program"])
        if sha(program) != selected["program_sha256"]:
            raise ValueError(f"selected program changed: {case}")
        sources[case] = program
    names = set()
    new = 0
    for option in spec["hardware_options"]:
        if set(option) != {"name", "hardware"} or option["name"] in names:
            raise ValueError("each hardware option needs a unique name and hardware")
        name, hardware = option["name"], option["hardware"]
        names.add(name)
        validate(hardware)
        for case in SCORE_CASES:
            key = f"{name}:{case}"
            if key in progress["estimates"]:
                continue
            if max_new is not None and new >= max_new:
                break
            try:
                result = estimate_program(sources[case], hardware_override=hardware)
                entry = {"cycles": result["cycles"], "waves": result["waves"]}
            except InfeasibleProgramError as error:
                entry = {"infeasible": str(error)}
            progress["estimates"][key] = entry
            _save(checkpoint, progress)
            new += 1
        if max_new is not None and new >= max_new:
            break
    results = []
    for option in spec["hardware_options"]:
        name = option["name"]
        entries = {case: progress["estimates"].get(f"{name}:{case}")
                   for case in SCORE_CASES}
        completed = all(entry is not None for entry in entries.values())
        feasible = completed and all("cycles" in entry for entry in entries.values())
        score = (1000 * math.exp(sum(weight * math.log(reference / entries[case]["cycles"])
                   for case, (reference, weight) in SCORE_CASES.items())) if feasible else None)
        results.append({"name": name, "area_au": area(option["hardware"]),
                        "completed": completed, "feasible": feasible,
                        "predicted_cycles": {case: entry["cycles"] for case, entry in entries.items()
                                             if entry is not None and "cycles" in entry},
                        "conditional_predicted_score": score,
                        "meets_grade_gate": score is not None and score >= spec["target_score"]})
    summary = {**identity,
               "scope": "fixed five command bodies and declared shared-hardware choices",
               "source_program_sha256": {case: base["selected_programs"][case]["program_sha256"]
                                         for case in SCORE_CASES},
               "base_conditional_predicted_score":
               base["conditional_predicted_score"], "target_score": spec["target_score"],
               "new_estimates": new, "results": results,
               "numerical_correctness": "not_checked", "power": "not_checked",
               "official_score": None}
    _save(output / "screen.json", summary)
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("spec", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--max-new", type=int)
    args = parser.parse_args()
    print(json.dumps(screen(args.spec, args.output, args.max_new), indent=2))


if __name__ == "__main__":
    main()
