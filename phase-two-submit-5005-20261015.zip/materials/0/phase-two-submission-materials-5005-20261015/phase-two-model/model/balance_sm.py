"""Price SM reassignment of independent GEMM groups without exporting JSONL."""

import argparse
import json
from collections import defaultdict
from pathlib import Path

from .estimate import estimate_wave, program_records, validate_wave_capacity
from .hardware import validate
from .tool import sha, write


def _independent_gemm(groups):
    """Conservatively require disjoint stores and no in-wave read-after-write."""
    outputs = set()
    reads = set()
    intervals = defaultdict(list)
    mma = False
    for index, group in enumerate(groups):
        for command in group["commands"]:
            instruction = command.get("instruction", {})
            op = instruction.get("op")
            mma |= op in ("mma", "mma_shared")
            if op in ("load", "load_shared"):
                reads.add(instruction["tensor"])
            elif op in ("store", "store_shared"):
                tensor = instruction["tensor"]
                outputs.add(tensor)
                view = instruction["global"]
                if view["col_stride"] != 1 or view["row_stride"] < view["cols"]:
                    return False
                for row in range(view["rows"]):
                    start = view["base"] + row * view["row_stride"]
                    intervals[tensor].append((start, start + view["cols"] - 1, index))
    if not mma or not outputs or outputs & reads:
        return False
    for tensor_intervals in intervals.values():
        tensor_intervals.sort()
        previous_end = -1
        for start, end, _ in tensor_intervals:
            if start <= previous_end:
                return False
            previous_end = end
    return True


def _work(group):
    """Only a packing heuristic; the final comparison uses estimate_wave."""
    return sum(1 for command in group["commands"]
               if command.get("instruction", {}).get("op") is not None)


def balance_wave(groups, hardware):
    if len(groups) < 2 or not _independent_gemm(groups):
        return groups
    loads = [0] * hardware["sms"]
    count = [0] * hardware["sms"]
    rf = [0] * hardware["sms"]
    sh = [0] * hardware["sms"]
    assigned = [None] * len(groups)
    indexed = sorted(enumerate(groups), key=lambda item: (-_work(item[1]), item[0]))
    for index, group in indexed:
        choices = [sm for sm in range(hardware["sms"])
                   if count[sm] < hardware["resident_groups"] and
                   rf[sm] + group["rf_kib"] <= hardware["rf_kib"] and
                   sh[sm] + group["sh_kib"] <= hardware["sh_kib"]]
        if not choices:
            return groups
        sm = min(choices, key=lambda candidate: (loads[candidate], count[candidate], candidate))
        assigned[index] = dict(group, sm=sm)
        count[sm] += 1
        rf[sm] += group["rf_kib"]
        sh[sm] += group["sh_kib"]
        loads[sm] += _work(group)
    if all(old["sm"] == new["sm"] for old, new in zip(groups, assigned)):
        return groups
    validate_wave_capacity(assigned, hardware)
    return assigned


def screen(source, hardware, base_cycles, output=None):
    source = Path(source)
    validate(hardware)
    records = program_records(source)
    next(records)
    cache = {}
    stats = {"waves": 0, "changed_waves": 0, "changed_wave_indices": [],
             "changed_groups": 0,
             "original_affected_cycles": 0, "replacement_affected_cycles": 0}
    for record in records:
        if record["record"] != "wave":
            continue
        wave_index = stats["waves"]
        stats["waves"] += 1
        groups = record["groups"]
        balanced = balance_wave(groups, hardware)
        if balanced is groups:
            continue
        original = estimate_wave(groups, hardware, cache)
        replacement = estimate_wave(balanced, hardware, cache)
        # This is an optimization variable: reject an adverse reassignment.
        if replacement >= original:
            continue
        stats["changed_waves"] += 1
        stats["changed_wave_indices"].append(wave_index)
        stats["changed_groups"] += sum(a["sm"] != b["sm"]
                                        for a, b in zip(groups, balanced))
        stats["original_affected_cycles"] += original
        stats["replacement_affected_cycles"] += replacement
    result = {"scope": "independent GEMM group-to-SM assignment",
              "source_sha256": sha(source),
              "estimator_sha256": sha(Path(__file__).with_name("estimate.py")),
              "model_sha256": sha(Path(__file__)),
              "hardware": hardware, "base_cycles": base_cycles, **stats,
              "predicted_cycles": (base_cycles - stats["original_affected_cycles"] +
                                   stats["replacement_affected_cycles"]),
              "candidate_program_generated": False,
              "numerical_correctness": "not_checked", "official_score": None}
    if output is not None:
        Path(output).parent.mkdir(parents=True, exist_ok=True)
        write(output, result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("hardware", type=Path)
    parser.add_argument("base_cycles", type=int)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    document = json.loads(args.hardware.read_text())
    hardware = document.get("hardware", document)
    result = screen(args.source, hardware, args.base_cycles, args.output)
    print(json.dumps({key: result[key] for key in
                      ("changed_waves", "changed_groups", "predicted_cycles")},
                     indent=2))


if __name__ == "__main__":
    main()
