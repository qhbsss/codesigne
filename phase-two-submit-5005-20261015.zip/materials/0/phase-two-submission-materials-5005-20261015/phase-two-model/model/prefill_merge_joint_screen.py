"""Reprice independent softmax wave pairs after Q scaling and SFU retargeting."""

import argparse
import copy
import json
from pathlib import Path

from .estimate import estimate_wave, program_records, validate_wave_capacity
from .ksplit_screen import _pack_waves, split_group
from .ksplit_single_k_screen import _compact
from .merge import (_adaptive_footprint, _pipeline_footprint, _append_commands,
                    _pipeline_and_combine)
from .query_scale_screen import _scaled_group
from .tool import write


def converted(record, hardware, max_k, scale, compact=False):
    groups = []
    for group in record["groups"]:
        if scale is not None:
            group, _ = _scaled_group(group, scale)
        if compact:
            group, _ = _compact(group)
        groups.append(split_group(group, max_k)[0])
    batches = _pack_waves(groups, hardware)
    if len(batches) != 1:
        raise ValueError("softmax wave unexpectedly partitions")
    return {"record": "wave", "groups": batches[0]}


def pair_saving(left, right, mode, hardware, cache):
    footprint = _adaptive_footprint if mode == "adaptive" else _pipeline_footprint
    a, b = footprint(left), footprint(right)
    if a is None or b is None or a["key"] != b["key"]:
        raise ValueError("selected softmax pair is no longer mergeable")
    if _pipeline_and_combine(a["intervals"], b["intervals"]) is None:
        raise ValueError("selected softmax pair has cross-group dependency")
    merged = copy.deepcopy(left)
    _append_commands(merged, copy.deepcopy(right))
    merged["groups"] = [dict(group, rf_kib=max(group["rf_kib"], extra["rf_kib"]))
                        for group, extra in zip(merged["groups"], right["groups"])]
    validate_wave_capacity(merged["groups"], hardware)
    return (estimate_wave(left["groups"], hardware, cache) +
            estimate_wave(right["groups"], hardware, cache) -
            estimate_wave(merged["groups"], hardware, cache))


def screen_case(source, selections, hardware, max_k, scale, single_k):
    pairs = {row["left"]: row for row in selections}
    cache = {}
    records = program_records(source)
    next(records)
    pending = None
    index = -1
    accepted = []
    rejected = []
    for record in records:
        if record["record"] != "wave":
            continue
        index += 1
        if pending is not None and index == pending[0]:
            right = converted(record, hardware, max_k, scale, index in single_k)
            try:
                saving = pair_saving(pending[1], right, pending[2], hardware, cache)
            except ValueError as error:
                rejected.append({"left": index - 1, "reason": str(error)})
                saving = 0
            if saving > 0:
                accepted.append({"left": index - 1, "right": index,
                                 "mode": pending[2], "saving": saving})
            pending = None
        elif index in pairs:
            choice = pairs[index]
            if choice["right"] != index + 1:
                raise ValueError("only adjacent selected waves are supported")
            pending = (index + 1, converted(record, hardware, max_k, scale,
                                          index in single_k), choice["mode"])
    if pending is not None:
        raise ValueError("incomplete selected pair")
    return {"accepted": accepted, "rejected": rejected,
            "saving_cycles": sum(x["saving"] for x in accepted)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("base_solution", type=Path)
    parser.add_argument("ksplit_screen", type=Path)
    parser.add_argument("merge_screen", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    base = json.loads(args.base_solution.read_text())
    prior = json.loads(args.ksplit_screen.read_text())
    choices = json.loads(args.merge_screen.read_text())
    single = json.loads((args.merge_screen.parent / "single-k-screen.json").read_text())
    hardware = dict(prior["hardware"], sfu=27)
    result = {}
    for case in ("w-p", "a-p"):
        source = base["selected_programs"][case]["program"]
        result[case] = screen_case(source, choices["cases"][case]["selected"],
                                   hardware, prior["max_k"],
                                   0.125 if case == "a-p" else None,
                                   {row["wave"] for row in single["cases"][case]["accepted_waves"]})
        print(case, result[case]["saving_cycles"], len(result[case]["accepted"]),
              flush=True)
    write(args.output, {"cases": result, "candidate_program_generated": False,
                        "official_score": None})


if __name__ == "__main__":
    main()
