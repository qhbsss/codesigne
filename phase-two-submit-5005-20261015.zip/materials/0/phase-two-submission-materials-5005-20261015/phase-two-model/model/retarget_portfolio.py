"""Retarget static program bodies onto declared shared-hardware alternatives."""

import argparse
import json
import shutil
from pathlib import Path

from .hardware import area, validate
from .tool import ROOT, SCORE_CASES, STARTER, fresh, sha, write


def build(spec_path, output):
    spec_path, output = Path(spec_path), Path(output)
    spec = json.loads(spec_path.read_text())
    if set(spec) != {"target_score", "hardware_choices", "programs"}:
        raise ValueError("retarget specification has unexpected fields")
    if set(spec["programs"]) != set(SCORE_CASES):
        raise ValueError("retarget specification requires all five cases")
    if not spec["hardware_choices"] or any(not paths for paths in spec["programs"].values()):
        raise ValueError("retarget specification has an empty decision domain")
    fresh(output)
    expected = {case: json.loads(
        (STARTER / "configs/reference" / f"{case}.json").read_text())
        for case in SCORE_CASES}
    sources = {}
    for case, paths in spec["programs"].items():
        sources[case] = []
        for source_string in paths:
            source = ROOT / source_string
            with source.open() as reader:
                header = json.loads(next(reader))
            if any(header[field] != expected[case][field]
                   for field in ("shape", "batch", "decode")):
                raise ValueError(f"source workload mismatch: {source}")
            sources[case].append((source, sha(source)))
    hardware_options = []
    manifest = []
    names = set()
    for hardware_index, choice in enumerate(spec["hardware_choices"]):
        if set(choice) != {"name", "hardware"} or choice["name"] in names:
            raise ValueError("hardware choice requires a unique name and hardware")
        names.add(choice["name"])
        hardware = choice["hardware"]
        validate(hardware)
        if area(hardware) > 100:
            raise ValueError("hardware exceeds area budget")
        programs = {}
        for case, alternatives in sources.items():
            programs[case] = []
            for option_index, (source, source_hash) in enumerate(alternatives):
                directory = output / f"hardware-{hardware_index:04d}" / case / f"option-{option_index:04d}"
                directory.mkdir(parents=True)
                destination = directory / "program.jsonl"
                with source.open("rb") as reader, destination.open("xb") as writer:
                    header = json.loads(reader.readline())
                    header["hardware"] = hardware
                    writer.write(json.dumps(header, separators=(",", ":")).encode() + b"\n")
                    shutil.copyfileobj(reader, writer)
                destination_string = (str(destination.relative_to(ROOT))
                                      if destination.is_relative_to(ROOT)
                                      else str(destination.resolve()))
                programs[case].append(destination_string)
                manifest.append({"hardware": choice["name"], "case": case,
                                 "source": str(source), "source_sha256": source_hash,
                                 "program": destination_string,
                                 "program_sha256": sha(destination)})
        hardware_options.append({"name": choice["name"], "programs": programs})
    portfolio = {"target_score": spec["target_score"],
                 "hardware_options": hardware_options}
    write(output / "source-spec.json", spec)
    write(output / "portfolio.json", portfolio)
    write(output / "manifest.json", manifest)
    return portfolio


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("spec", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    result = build(args.spec, args.output)
    print(json.dumps({"hardware_options": len(result["hardware_options"]),
                      "program_options": sum(len(paths) for hardware in result["hardware_options"]
                                             for paths in hardware["programs"].values())},
                     indent=2))


if __name__ == "__main__":
    main()
