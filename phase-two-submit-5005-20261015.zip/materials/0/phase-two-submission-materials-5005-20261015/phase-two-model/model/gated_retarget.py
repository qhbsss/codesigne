"""Retarget five SHA-pinned compact programs only after the model score gate."""

import argparse
import json
import math
import shutil
from pathlib import Path

from .hardware import area, validate
from .tool import SCORE_CASES, sha, write


def retarget(base_path, spec_path, progress_path, option_name, output):
    base = json.loads(Path(base_path).read_text())
    spec = json.loads(Path(spec_path).read_text())
    progress = json.loads(Path(progress_path).read_text())
    if progress["spec_sha256"] != sha(spec_path) or progress["base_solution_sha256"] != sha(base_path):
        raise ValueError("screen inputs changed after estimation")
    if progress["estimator_sha256"] != sha(Path(__file__).with_name("estimate.py")):
        raise ValueError("estimator changed after estimation")
    if spec["target_score"] < 5000:
        raise ValueError("model gate must be at least 5000")
    option, = [item for item in spec["hardware_options"] if item["name"] == option_name]
    hardware = option["hardware"]
    validate(hardware)
    cycles = {case: progress["estimates"][f"{option_name}:{case}"]["cycles"]
              for case in SCORE_CASES}
    score = 1000 * math.exp(sum(weight * math.log(reference / cycles[case])
                                for case, (reference, weight) in SCORE_CASES.items()))
    if score < spec["target_score"]:
        raise ValueError(f"model score {score:.6f} below gate {spec['target_score']}")
    output = Path(output)
    output.mkdir(parents=True, exist_ok=False)
    programs = output / "programs"
    programs.mkdir()
    manifest = {"hardware": hardware, "area_au": area(hardware),
                "model_score": score, "model_cycles": cycles,
                "model_gate": spec["target_score"], "source_spec_sha256": sha(spec_path),
                "screen_sha256": sha(progress_path), "programs": {}}
    for case in SCORE_CASES:
        selected = base["selected_programs"][case]
        source = Path(selected["program"])
        if sha(source) != selected["program_sha256"]:
            raise ValueError(f"source program changed: {case}")
        destination = programs / f"{case}.jsonl"
        with source.open("rb") as reader, destination.open("xb") as writer:
            header = json.loads(reader.readline())
            header["hardware"] = hardware
            writer.write(json.dumps(header, separators=(",", ":")).encode() + b"\n")
            shutil.copyfileobj(reader, writer)
        manifest["programs"][case] = {"source_sha256": selected["program_sha256"],
                                      "program_sha256": sha(destination),
                                      "bytes": destination.stat().st_size}
    write(output / "manifest.json", manifest)
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("base", type=Path)
    parser.add_argument("spec", type=Path)
    parser.add_argument("progress", type=Path)
    parser.add_argument("option_name")
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    result = retarget(args.base, args.spec, args.progress, args.option_name, args.output)
    print(json.dumps({"model_score": result["model_score"],
                      "area_au": result["area_au"], "programs": result["programs"]}, indent=2))


if __name__ == "__main__":
    main()
