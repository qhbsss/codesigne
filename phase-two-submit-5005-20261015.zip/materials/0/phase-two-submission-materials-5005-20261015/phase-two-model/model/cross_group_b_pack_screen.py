"""Screen B-panel sharing paired with two-wave packing to preserve residency."""

import argparse
import json
import math
from collections import defaultdict, deque
from pathlib import Path

from .estimate import estimate_wave, program_records, validate_wave_capacity
from .resident_b32_screen import _combine_pair
from .resident4_pack_screen import _access_footprint, _pack
from .resident4_window_screen import choose, independent
from .reuse_b_within import _renumber
from .tool import SCORE_CASES, sha, write


def merge_wave(record, hardware):
    by_sm = defaultdict(list)
    for group in record["groups"]:
        by_sm[group["sm"]].append(group)
    merged = []
    paired_tiles = 0
    for sm, groups in sorted(by_sm.items()):
        if len(groups) != 2:
            return None, 0
        halves, count = _combine_pair(groups[0], groups[1])
        if halves is None or count == 0:
            return None, 0
        commands = _renumber(halves[0]["commands"] + halves[1]["commands"])
        merged.append({"sm": sm, "rf_kib": 32, "sh_kib": 0,
                       "commands": commands})
        paired_tiles += count
    validate_wave_capacity(merged, hardware)
    return {"record": "wave", "groups": merged}, paired_tiles


def screen(source, case, manifest_path, output):
    source, manifest_path, output = map(Path, (source, manifest_path, output))
    output.parent.mkdir(parents=True, exist_ok=True)
    manifest = json.loads(manifest_path.read_text())
    if sha(source) != manifest["program_sha256"][case]:
        raise ValueError("program SHA changed")
    hardware = manifest["hardware"]
    records = program_records(source)
    if next(records)["hardware"] != hardware:
        raise ValueError("hardware changed")
    cache = {}
    rows = []
    pending = deque()
    wave_index = commit_cycles = eligible_pairs = 0

    def flush(force=False):
        nonlocal eligible_pairs
        while pending and (force or len(pending) >= 2):
            first = pending[0]
            choices = []
            if len(pending) >= 2 and independent(list(pending)[:2]):
                left, right = list(pending)[:2]
                try:
                    merged_left, pairs_left = merge_wave(left[0], hardware)
                    merged_right, pairs_right = merge_wave(right[0], hardware)
                    if merged_left is not None and merged_right is not None:
                        packed = _pack([merged_left, merged_right], hardware)
                        if len(packed) == 1:
                            eligible_pairs += 1
                            cycles = estimate_wave(packed[0], hardware, cache)
                            base = left[1] + right[1]
                            if cycles < base:
                                choices.append({"source_waves": 2, "packed_waves": 1,
                                                "cycles": cycles, "base": base,
                                                "paired_tiles": pairs_left + pairs_right})
                except ValueError:
                    pass
            rows.append({"base": first[1], "options": choices})
            pending.popleft()
            if len(rows) % 16 == 0:
                write(output.with_name("progress.json"),
                      {"case": case, "source_sha256": sha(source),
                       "screened_waves": len(rows), "eligible_pairs": eligible_pairs,
                       "beneficial_pairs": sum(bool(row["options"]) for row in rows)})
                print(case, "screened", len(rows), "eligible", eligible_pairs, flush=True)

    for record in records:
        if record.get("record") != "wave":
            flush(force=True)
            if record.get("record") == "commit":
                commit_cycles += 1
            continue
        pending.append((record, estimate_wave(record["groups"], hardware, cache),
                        _access_footprint(record), wave_index))
        wave_index += 1
        flush()
    flush(force=True)
    baseline = commit_cycles + sum(row["base"] for row in rows)
    if len(rows) != wave_index or baseline != manifest["model_cycles"][case]:
        raise ValueError("source differs from complete model baseline")
    selected, wave_cycles = choose(rows)
    cycles = dict(manifest["model_cycles"])
    cycles[case] = commit_cycles + wave_cycles
    score = 1000 * math.exp(sum(weight * math.log(reference / cycles[name])
                              for name, (reference, weight) in SCORE_CASES.items()))
    result = {"case": case, "source_sha256": sha(source),
              "manifest_sha256": sha(manifest_path), "source_waves": wave_index,
              "packed_waves": sum(row["packed_waves"] for row in selected),
              "eligible_pairs": eligible_pairs,
              "beneficial_pairs": sum(bool(row["options"]) for row in rows),
              "chosen": [row for row in selected if row["source_waves"] == 2],
              "base_cycles": baseline, "selected_cycles": cycles[case],
              "cycle_delta": cycles[case] - baseline,
              "five_case_model_cycles": cycles, "five_case_model_score": score,
              "meets_grade_gate": score >= 5000,
              "candidate_program_generated": False, "official_score": None}
    write(output, result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("case")
    parser.add_argument("manifest", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    result = screen(args.source, args.case, args.manifest, args.output)
    print(json.dumps({key: result[key] for key in ("case", "source_waves", "packed_waves",
                                                   "eligible_pairs", "beneficial_pairs",
                                                   "cycle_delta", "five_case_model_score")},
                     indent=2))


if __name__ == "__main__":
    main()
