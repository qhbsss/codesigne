"""Screen safe within-wave GEMM group orders before materializing a program."""

import argparse
import json
import math
import subprocess
import sys
import tempfile
from pathlib import Path

from .balance_sm import _independent_gemm
from .estimate import estimate_program, estimate_wave, program_records
from .tool import SCORE_CASES, STARTER, sha, write


def ordered(groups, option):
    if option == "base":
        return groups
    if option == "reverse":
        return list(reversed(groups))
    if option == "heavy_first":
        return sorted(groups, key=lambda group: -len(group["commands"]))
    if option == "light_first":
        return sorted(groups, key=lambda group: len(group["commands"]))
    if option == "sm_interleave":
        return sorted(groups, key=lambda group: group["sm"])
    if option == "sm_reverse":
        return sorted(groups, key=lambda group: -group["sm"])
    raise ValueError(option)


OPTIONS = ("base", "reverse", "heavy_first", "light_first", "sm_interleave", "sm_reverse")


def screen(source, case, base_manifest, checkpoint):
    source, base_manifest, checkpoint = map(Path, (source, base_manifest, checkpoint))
    base = json.loads(base_manifest.read_text())
    records = program_records(source)
    header = next(records)
    hardware = header["hardware"]
    if hardware != base["hardware"] or sha(source) != base["program_sha256"][case]:
        raise ValueError("source and shared hardware identity changed")
    identity = {"case": case, "source_sha256": sha(source),
                "base_manifest_sha256": sha(base_manifest), "screen_code_sha256": sha(__file__)}
    state = json.loads(checkpoint.read_text()) if checkpoint.exists() else {**identity, "rows": []}
    if any(state.get(key) != value for key, value in identity.items()):
        raise ValueError("checkpoint identity changed")
    rows = state["rows"]
    cache = {}
    wave_index = 0
    for record in records:
        if record["record"] != "wave":
            continue
        if wave_index < len(rows):
            wave_index += 1
            continue
        groups = record["groups"]
        original = estimate_wave(groups, hardware, cache)
        costs = {"base": original}
        if len(groups) > 1 and _independent_gemm(groups):
            for option in OPTIONS[1:]:
                trial = ordered(groups, option)
                if trial != groups:
                    costs[option] = estimate_wave(trial, hardware, cache)
        choice = min(costs, key=costs.get)
        rows.append({"option": choice, "base": original, "cycles": costs[choice]})
        wave_index += 1
        if wave_index % 16 == 0:
            write(checkpoint, state)
    write(checkpoint, state)
    cycles = dict(base["exact_model_cycles"])
    cycles[case] += sum(row["cycles"] - row["base"] for row in rows)
    score = 1000 * math.exp(sum(weight * math.log(reference / cycles[name])
        for name, (reference, weight) in SCORE_CASES.items()))
    result = {**identity, "checkpoint_sha256": sha(checkpoint), "waves": wave_index,
              "changed_waves": sum(row["option"] != "base" for row in rows),
              "choices": {option: sum(row["option"] == option for row in rows) for option in OPTIONS},
              "five_case_model_cycles": cycles, "five_case_model_score": score,
              "meets_grade_gate": score >= 5000, "candidate_program_generated": False,
              "official_score": None}
    write(checkpoint.with_name("screen.json"), result)
    return result


def materialize(source, checkpoint, screen_path, output):
    source, checkpoint, screen_path, output = map(Path, (source, checkpoint, screen_path, output))
    result = json.loads(screen_path.read_text())
    if (not result["meets_grade_gate"] or result["five_case_model_score"] < 5000 or
            result["source_sha256"] != sha(source) or
            result["checkpoint_sha256"] != sha(checkpoint) or
            result["screen_code_sha256"] != sha(__file__)):
        raise ValueError("five-case model gate or source identity failed")
    choices = json.loads(checkpoint.read_text())["rows"]
    output.mkdir(parents=True, exist_ok=False)
    destination = output / f"{result['case']}.jsonl"
    with tempfile.TemporaryDirectory(prefix="order-groups-") as temporary:
        expanded = Path(temporary) / "expanded.jsonl"
        records = program_records(source)
        header = next(records)
        wave_index = 0
        with expanded.open("x") as writer:
            writer.write(json.dumps(header, separators=(",", ":")) + "\n")
            for record in records:
                if record["record"] == "wave":
                    choice = choices[wave_index]["option"]
                    wave_index += 1
                    if choice != "base":
                        if not _independent_gemm(record["groups"]):
                            raise ValueError("unsafe reorder in checkpoint")
                        record = dict(record, groups=ordered(record["groups"], choice))
                writer.write(json.dumps(record, separators=(",", ":")) + "\n")
        if wave_index != len(choices):
            raise ValueError("checkpoint wave count mismatch")
        subprocess.run([sys.executable, str(STARTER / "tools/compact_program.py"),
                        str(expanded), str(destination)], check=True)
    exact = estimate_program(destination)["cycles"]
    if exact != result["five_case_model_cycles"][result["case"]]:
        raise ValueError("materialized model cycles differ from screen")
    manifest = {"case": result["case"], "program_sha256": sha(destination),
                "source_sha256": sha(source), "screen_sha256": sha(screen_path),
                "exact_model_cycles": exact, "five_case_model_score": result["five_case_model_score"],
                "grade_allowed": True, "official_score": None}
    write(output / "manifest.json", manifest)
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="mode", required=True)
    first = sub.add_parser("screen")
    first.add_argument("source", type=Path)
    first.add_argument("case")
    first.add_argument("base_manifest", type=Path)
    first.add_argument("checkpoint", type=Path)
    second = sub.add_parser("materialize")
    second.add_argument("source", type=Path)
    second.add_argument("checkpoint", type=Path)
    second.add_argument("screen", type=Path)
    second.add_argument("output", type=Path)
    args = parser.parse_args()
    result = screen(args.source, args.case, args.base_manifest, args.checkpoint) if args.mode == "screen" else materialize(args.source, args.checkpoint, args.screen, args.output)
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main()
