"""Screen changed-SM hardware by virtual workgroup remapping."""

import argparse
import json
import math
from pathlib import Path

from .estimate import estimate_wave, program_records
from .hardware import area, validate
from .rebalance_screen import split_wave
from .tool import SCORE_CASES, sha, write


def screen_case(source, hardware):
    records = program_records(source)
    next(records)
    cache = {}
    cycles = source_waves = output_waves = split_waves = 0
    for record in records:
        if record["record"] == "wave":
            source_waves += 1
            groups = [dict(group, sm=(group["sm"] % hardware["sms"]
                                      if hardware["sms"] < 8 else index % hardware["sms"]))
                      for index, group in enumerate(record["groups"])]
            rounds = split_wave(groups, hardware)
            output_waves += len(rounds)
            split_waves += len(rounds) > 1
            cycles += sum(estimate_wave(part, hardware, cache) for part in rounds)
        elif record["record"] == "commit":
            cycles += 1
    return {"cycles": cycles, "source_waves": source_waves,
            "output_waves": output_waves, "split_waves": split_waves}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("base", type=Path)
    parser.add_argument("hardware", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    base = json.loads(args.base.read_text())
    hardware = json.loads(args.hardware.read_text())
    hardware = hardware.get("hardware", hardware)
    validate(hardware)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    current = json.loads(args.output.read_text()) if args.output.exists() else {
        "hardware": hardware, "area_au": area(hardware), "cases": {},
        "candidate_program_generated": False, "official_score": None}
    if current["hardware"] != hardware:
        raise ValueError("hardware changed during screen")
    for case in SCORE_CASES:
        if case in current["cases"]:
            continue
        selected = base["selected_programs"][case]
        source = Path(selected["program"])
        if sha(source) != selected["program_sha256"]:
            raise ValueError(f"source changed: {case}")
        current["cases"][case] = screen_case(source, hardware)
        write(args.output, current)
        print(case, current["cases"][case], flush=True)
    cycles = {case: current["cases"][case]["cycles"] for case in SCORE_CASES}
    score = 1000 * math.exp(sum(weight * math.log(reference / cycles[case])
                                for case, (reference, weight) in SCORE_CASES.items()))
    current.update(conditional_predicted_score=score, target_score=5000,
                   meets_grade_gate=score >= 5000,
                   numerical_correctness="not_checked")
    write(args.output, current)
    print("score", score, flush=True)


if __name__ == "__main__":
    main()
