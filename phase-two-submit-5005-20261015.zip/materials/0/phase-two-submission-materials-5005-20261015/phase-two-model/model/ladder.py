"""Gate costly five-case grading on a model-score gain and archive real gains."""

import argparse
import hashlib
import json
import math
import subprocess
import zipfile
from pathlib import Path

from .tool import MODEL, OFFICIAL, ROOT, SCORE_CASES, STARTER, sha, write


STEP = 500
TARGET = 5000
BASE_PREDICTION = MODEL / "runs/portfolio-mip-20261012/solution.json"
BASE_GRADE = STARTER / "runs/k4-rf-causal-rf-reuse-joint-grade-20261011/grade.json"


def read(path):
    return json.loads(Path(path).read_text())


def save_ledger(path, ledger):
    temporary = path.with_suffix(".json.tmp")
    write(temporary, ledger)
    temporary.replace(path)


def qualifies_for_archive(score, ledger):
    return score >= ledger["last_archived_score"] + ledger["step"]


def initial_ledger():
    estimate = read(BASE_PREDICTION)
    receipt = read(BASE_GRADE)
    if receipt["status"] != "complete" or receipt["seed"] != 7:
        raise ValueError("baseline grade is not complete")
    return {"step": STEP, "target": TARGET,
            "last_predicted_score": estimate["conditional_predicted_score"],
            "last_archived_score": receipt["score"],
            "baseline_estimate": str(BASE_PREDICTION),
            "baseline_receipt": str(BASE_GRADE),
            "source_sha256": receipt["source_sha256"],
            "attempts": [], "archives": []}


def candidate_identity(solution):
    selected = solution["selected_programs"]
    if set(selected) != set(SCORE_CASES):
        raise ValueError("proposal must select all five official cases")
    hardware = solution["selected_hardware"]["hardware"]
    digests = {}
    for case_name, option in selected.items():
        program = Path(option["program"])
        if sha(program) != option["program_sha256"]:
            raise ValueError(f"selected program changed: {case_name}")
        with program.open() as source:
            header = json.loads(next(source))
        expected = read(STARTER / "configs/reference" / f"{case_name}.json")
        if (header["hardware"] != hardware or
                any(header[key] != expected[key] for key in ("shape", "batch", "decode"))):
            raise ValueError(f"selected program header mismatches workload: {case_name}")
        digests[case_name] = option["program_sha256"]
    return digests


def screen(solution, ledger):
    solver = solution["solver"]
    prediction = solution["conditional_predicted_score"]
    if (solver["status"] != 0 or solver["mip_gap"] is None or
            solver["mip_gap"] > 1e-8 or
            not isinstance(prediction, (int, float)) or not math.isfinite(prediction)):
        raise ValueError("proposal lacks a completed finite-domain model estimate")
    if solution["estimator_sha256"] != sha(MODEL / "model/estimate.py"):
        raise ValueError("candidate was not scored by the current independent estimator")
    digests = candidate_identity(solution)
    expected_score = 1000 * math.exp(sum(
        weight * math.log(reference / solution["selected_programs"][case]["estimated_cycles"])
        for case, (reference, weight) in SCORE_CASES.items()))
    if not math.isclose(prediction, expected_score, rel_tol=1e-10):
        raise ValueError("claimed model score does not match five predicted cycle counts")
    threshold = max(5000, ledger["last_predicted_score"] + ledger["step"])
    return {"conditional_predicted_score": prediction,
            "minimum_prediction_for_grade": threshold,
            "grade_allowed": prediction >= threshold,
            "program_sha256": digests,
            "official_score": None}


def verify_grade(grade_path, solution, ledger):
    receipt = read(grade_path)
    digests = candidate_identity(solution)
    if (receipt["status"] != "complete" or receipt["seed"] != 7 or
            receipt["source_sha256"] != ledger["source_sha256"] or
            receipt["hardware"] != solution["selected_hardware"]["hardware"] or
            set(receipt["cases"]) != set(digests) or
            any(receipt["cases"][case]["program_sha256"] != digest
                for case, digest in digests.items())):
        raise ValueError("grade does not certify this five-program proposal")
    score = receipt["score"]
    if not isinstance(score, (int, float)) or not math.isfinite(score) or score <= 0:
        raise ValueError("invalid aggregate score")
    return score


def finish_attempt(attempt, attempt_dir, solution, ledger, ledger_path, output):
    grade_dir = attempt_dir / "grade"
    try:
        score = verify_grade(grade_dir / "grade.json", solution, ledger)
    except ValueError:
        attempt["status"] = "rejected"
        save_ledger(ledger_path, ledger)
        raise
    attempt["status"] = "checked"
    attempt["real_score"] = score
    ledger["last_predicted_score"] = max(ledger["last_predicted_score"], attempt["prediction"])
    save_ledger(ledger_path, ledger)
    if qualifies_for_archive(score, ledger):
        archive = output / f"submission-{attempt_dir.name.removeprefix('attempt-')}.zip"
        if archive.exists():
            with zipfile.ZipFile(archive) as contents:
                if contents.testzip() is not None or "selftest/grade.json" not in contents.namelist():
                    raise ValueError(f"incomplete archive: {archive}")
        else:
            package = ["python3", str(STARTER / "tools/package_phase_two.py"),
                       str(grade_dir), str(archive), "--materials", str(MODEL / "MODEL.md"),
                       "--materials", str(MODEL / "MODEL_V2.md"),
                       "--materials", str(MODEL / "model"),
                       "--materials", str(STARTER / "source/src"),
                       "--materials", str(STARTER / "tools")]
            subprocess.run(package, check=True)
        ledger["last_archived_score"] = score
        ledger["archives"].append({"score": score, "archive": str(archive),
                                   "grade": str(grade_dir / "grade.json"),
                                   "proposal": str(attempt_dir / "proposal.json")})
        attempt["status"] = "archived"
        save_ledger(ledger_path, ledger)
    return {"conditional_predicted_score": attempt["prediction"],
            "official_score": score, "status": attempt["status"]}


def run(proposal, output):
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    ledger_path = output / "ledger.json"
    ledger = read(ledger_path) if ledger_path.exists() else initial_ledger()
    if not ledger_path.exists():
        save_ledger(ledger_path, ledger)
    solution = read(proposal)
    decision = screen(solution, ledger)
    write(output / "last-screen.json", decision)
    identity = "-".join(decision["program_sha256"][case] for case in SCORE_CASES)
    fingerprint = hashlib.sha256(identity.encode()).hexdigest()[:16]
    for existing in reversed(ledger["attempts"]):
        if existing["program_id"] != fingerprint:
            continue
        if existing["prediction"] != decision["conditional_predicted_score"]:
            raise ValueError("same programs already screened with a different prediction")
        attempt_dir = Path(existing["grade"]).parent.parent
        if existing["status"] in ("running", "checked"):
            if Path(existing["grade"]).is_file():
                return {**decision, **finish_attempt(existing, attempt_dir, solution,
                                                     ledger, ledger_path, output)}
            if existing["status"] == "running":
                existing["status"] = "interrupted"
                save_ledger(ledger_path, ledger)
            else:
                raise ValueError("checked grade file disappeared")
        if existing["status"] != "interrupted":
            raise ValueError("same five programs already graded")
        break
    if not decision["grade_allowed"]:
        return decision
    attempt_index = len(ledger["attempts"])
    attempt_dir = output / f"attempt-{attempt_index:04d}-{fingerprint}"
    programs = attempt_dir / "programs"
    programs.mkdir(parents=True)
    for case, option in solution["selected_programs"].items():
        target = programs / f"{case}.jsonl"
        target.write_bytes(Path(option["program"]).read_bytes())
        if sha(target) != decision["program_sha256"][case]:
            raise RuntimeError(f"program copy changed: {case}")
    grade_dir = attempt_dir / "grade"
    grade_command = ["python3", str(STARTER / "tools/grade_v09.py"), str(programs),
                     str(grade_dir), "--binary", str(OFFICIAL), "--seed", "7",
                     "--jobs", "2", "--cpu-budget", "4", "--total-memory-gib", "8",
                     "--timeout", "1200"]
    write(attempt_dir / "proposal.json", solution)
    write(attempt_dir / "grade-command.json", {"argv": grade_command})
    attempt = {"program_id": fingerprint, "prediction": decision["conditional_predicted_score"],
               "status": "running", "grade": str(grade_dir / "grade.json")}
    ledger["attempts"].append(attempt)
    save_ledger(ledger_path, ledger)
    with (attempt_dir / "grade.log").open("w") as log:
        result = subprocess.run(grade_command, stdout=log, stderr=subprocess.STDOUT,
                                check=False)
    if result.returncode != 0 or not (grade_dir / "grade.json").is_file():
        attempt["status"] = "interrupted"
        attempt["returncode"] = result.returncode
        save_ledger(ledger_path, ledger)
        raise RuntimeError(f"grade failed; logs retained at {attempt_dir}")
    return {**decision, **finish_attempt(attempt, attempt_dir, solution,
                                        ledger, ledger_path, output)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("proposal", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    print(json.dumps(run(args.proposal, args.output), indent=2))


if __name__ == "__main__":
    main()
