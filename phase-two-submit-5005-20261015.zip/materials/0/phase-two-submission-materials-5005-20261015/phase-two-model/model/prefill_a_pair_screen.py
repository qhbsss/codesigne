"""Screen two prefill output-column tiles sharing one multi-K A panel.

Two 32x64 GEMM tiles with the same A matrix are split into four 32x32 output
halves.  Their four accumulators, one 32x64 A panel and one 64x32 B panel fit
in the original 32-KiB RF reservation.  This keeps two resident groups per SM
while halving A panel DMA volume for each eligible pair.  The independent
model prices every new load, MMA, wait and epilogue command in memory.
"""

import argparse
import copy
import json
import math
from pathlib import Path

from .estimate import estimate_wave, program_records, validate_wave_capacity
from .prefill_gelu_batch_screen import _gelu_row, _imm, _reg, _vector
from .prefill_m64k32_screen import _instruction, _segments, _tile
from .reuse_b_within import _renumber
from .tool import SCORE_CASES, sha, write


def _epilogue_matches(tile):
    epilogue = tile["epilogue"]
    if len(epilogue) != 321:
        return False
    bias = _instruction(epilogue[0])
    store = tile["store"]
    if (epilogue[0]["command"] != "run" or bias.get("op") != "load" or
            bias["global"]["base"] !=
            store["global"]["base"] % store["global"]["row_stride"] or
            bias["global"]["rows"] != 1 or bias["global"]["cols"] != 64 or
            bias["global"]["col_stride"] != 1 or
            bias["local"] != {"base": 6144, "rows": 1, "cols": 64,
                              "row_stride": 64, "col_stride": 1}):
        return False
    for row in range(32):
        command = epilogue[1 + row]
        if (command["command"] != "run" or
                _instruction(command) !=
                _vector("add", row * 64, 64, _reg(row * 64), _reg(6144))):
            return False
        for step, expected in enumerate(_gelu_row(row)):
            command = epilogue[33 + row * 9 + step]
            if command["command"] != "run" or _instruction(command) != expected:
                return False
    return True


def _compatible(left, right):
    a, b = left["store"], right["store"]
    x, y = a["global"], b["global"]
    if (left["fill"]["value"] != 0 or right["fill"]["value"] != 0 or
            a["tensor"] != b["tensor"] or
            x["row_stride"] != y["row_stride"] or
            x["base"] // x["row_stride"] != y["base"] // y["row_stride"] or
            abs(x["base"] - y["base"]) < 64 or
            x["base"] % x["row_stride"] + 64 > x["row_stride"] or
            y["base"] % y["row_stride"] + 64 > y["row_stride"] or
            len(left["chunks"]) != len(right["chunks"]) or
            not _epilogue_matches(left) or not _epilogue_matches(right)):
        return False
    if any(_instruction(command).get("tensor") == a["tensor"]
           for tile in (left, right) for command in tile["source"]
           if _instruction(command).get("op") == "load"):
        return False
    for first, second in zip(left["chunks"], right["chunks"]):
        fa, fb0, fb1 = map(_instruction, first)
        sa, sb0, sb1 = map(_instruction, second)
        if (fa["tensor"] != sa["tensor"] or fa["global"] != sa["global"] or
                fb0["tensor"] != sb0["tensor"] or
                fb1["tensor"] != sb1["tensor"]):
            return False
    return True


def _half_epilogue(tile, output_base, column_offset):
    bias = copy.deepcopy(_instruction(tile["epilogue"][0]))
    bias["global"] = dict(bias["global"],
                          base=bias["global"]["base"] + column_offset,
                          cols=32)
    bias["local"] = {"base": 6144, "rows": 1, "cols": 32,
                     "row_stride": 32, "col_stride": 1}
    commands = [{"command": "run", "instruction": bias}]
    for row in range(32):
        out = output_base + row * 32
        commands.append({"command": "run", "instruction":
                         _vector("add", out, 32, _reg(out), _reg(6144))})
    # Scratch 6144..7167 is free after the last MMA.  Each output element
    # retains its original nine-operation FP32 order.
    for instruction in _gelu_row(0):
        rewritten = copy.deepcopy(instruction)
        rewritten["len"] = 1024
        if rewritten["dst"] == 0:
            rewritten["dst"] = output_base
        for operand in (rewritten["a"], rewritten["b"]):
            if operand["kind"] == "reg" and operand["base"] == 0:
                operand["base"] = output_base
        commands.append({"command": "run", "instruction": rewritten})
    store = copy.deepcopy(tile["store"])
    store["global"] = dict(store["global"],
                           base=store["global"]["base"] + column_offset,
                           cols=32)
    store["local"] = {"base": output_base, "rows": 32, "cols": 32,
                      "row_stride": 32, "col_stride": 1}
    commands.append({"command": "run", "instruction": store})
    return commands


def _pair(left, right):
    commands = [{"command": "run", "instruction":
                 {"op": "fill", "dst": 0, "len": 4096, "value": 0.0}}]
    token = 0
    for first, second in zip(left["chunks"], right["chunks"]):
        a = copy.deepcopy(_instruction(first[0]))
        a["local"] = {"base": 4096, "rows": 32, "cols": 64,
                      "row_stride": 64, "col_stride": 1}
        panels = []
        for chunks in (first, second):
            original = _instruction(chunks[1])
            for offset in (0, 32):
                b = copy.deepcopy(original)
                b["global"] = dict(original["global"],
                                    base=original["global"]["base"] + offset,
                                    rows=64, cols=32)
                b["local"] = {"base": 6144, "rows": 64, "cols": 32,
                              "row_stride": 32, "col_stride": 1}
                panels.append(b)
        token += 1
        a_token = token
        commands.append({"command": "async", "token": token, "instruction": a})
        for index, b in enumerate(panels):
            token += 1
            commands.append({"command": "async", "token": token, "instruction": b})
            commands.append({"command": "wait", "tokens":
                             [a_token, token] if index == 0 else [token]})
            commands.append({"command": "run", "instruction":
                             {"op": "mma", "a": 4096, "b": 6144,
                              "c": index * 1024, "m": 32, "n": 32, "k": 64}})
    for tile_index, tile in enumerate((left, right)):
        for half in (0, 1):
            commands.extend(_half_epilogue(tile, tile_index * 2048 + half * 1024,
                                           half * 32))
    return commands


def pair_group(group):
    parts = _segments(group)
    if parts is None:
        return group, 0
    tiles = [_tile(part) for part in parts]
    if any(tile is None for tile in tiles):
        return group, 0
    commands = []
    pairs = index = 0
    while index < len(tiles):
        if index + 1 < len(tiles) and _compatible(tiles[index], tiles[index + 1]):
            commands.extend(_pair(tiles[index], tiles[index + 1]))
            pairs += 1
            index += 2
        else:
            commands.extend(parts[index])
            index += 1
    if not pairs:
        return group, 0
    return dict(group, commands=_renumber(copy.deepcopy(commands))), pairs


def pair_wave(groups, hardware):
    result = []
    pairs = 0
    for group in groups:
        changed, count = pair_group(group)
        result.append(changed)
        pairs += count
    if pairs:
        validate_wave_capacity(result, hardware)
    return result, pairs


def screen(source, manifest_path, case, output):
    source, manifest_path, output = map(Path, (source, manifest_path, output))
    manifest = json.loads(manifest_path.read_text())
    if case not in ("w-p", "a-p") or sha(source) != manifest["program_sha256"][case]:
        raise ValueError("source case or SHA differs from five-case manifest")
    records = program_records(source)
    hardware = next(records)["hardware"]
    if hardware != manifest["hardware"]:
        raise ValueError("hardware differs from five-case manifest")
    cache = {}
    waves = eligible = beneficial = pairs_seen = pairs_selected = saved = 0
    choices = []
    for record in records:
        if record["record"] != "wave":
            continue
        candidate, pairs = pair_wave(record["groups"], hardware)
        if pairs:
            eligible += 1
            pairs_seen += pairs
            old = estimate_wave(record["groups"], hardware, cache)
            new = estimate_wave(candidate, hardware, cache)
            if new < old:
                beneficial += 1
                pairs_selected += pairs
                saved += old - new
                choices.append({"wave": waves, "pairs": pairs,
                                "base": old, "cycles": new})
            if eligible % 8 == 0:
                print(case, "eligible", eligible, "beneficial", beneficial,
                      "saved", saved, flush=True)
        waves += 1
    cycles = dict(manifest["model_cycles"])
    cycles[case] -= saved
    score = 1000 * math.exp(sum(weight * math.log(reference / cycles[name])
                                for name, (reference, weight) in SCORE_CASES.items()))
    result = {"case": case, "source_sha256": sha(source),
              "manifest_sha256": sha(manifest_path), "model_sha256": sha(Path(__file__)),
              "source_waves": waves, "eligible_waves": eligible,
              "beneficial_waves": beneficial, "eligible_pairs": pairs_seen,
              "selected_pairs": pairs_selected,
              "base_cycles": manifest["model_cycles"][case],
              "selected_cycles": cycles[case], "cycle_delta": -saved,
              "choices": choices, "five_case_model_cycles": cycles,
              "five_case_model_score": score, "meets_grade_gate": score >= 5000,
              "candidate_program_generated": False, "official_score": None}
    output.parent.mkdir(parents=True, exist_ok=True)
    write(output, result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("manifest", type=Path)
    parser.add_argument("case", choices=("w-p", "a-p"))
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    result = screen(args.source, args.manifest, args.case, args.output)
    print(json.dumps({key: result[key] for key in
                      ("case", "eligible_waves", "beneficial_waves", "selected_pairs",
                       "cycle_delta", "five_case_model_score")}, indent=2), flush=True)


if __name__ == "__main__":
    main()
