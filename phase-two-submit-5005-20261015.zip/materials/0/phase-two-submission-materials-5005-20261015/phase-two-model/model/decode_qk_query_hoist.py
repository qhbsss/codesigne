"""Keep repeated decode QK query panels in RF across output score tiles.

Only groups with the exact M1/N32/K64 QK data flow are transformed.  The
initial query DMA is hoisted, every MMA keeps its original reduction order,
and the existing K DMA and output stores remain in their original order.
The candidate is emitted only after a five-case model screen clears 5000.
"""

import argparse
import copy
import json
import math
import shutil
import subprocess
import sys
import tempfile
from collections import Counter
from pathlib import Path

from .estimate import estimate_program, estimate_wave, program_records, validate_wave_capacity
from .tool import SCORE_CASES, STARTER, sha, write


def _query_key(instruction):
    return instruction["tensor"], json.dumps(instruction["global"], sort_keys=True)


def hoist_group(group, key_tensors):
    """Return a changed group and removed DMA count, or the original group."""
    if group["sh_kib"]:
        return group, 0
    commands = group["commands"]
    query_loads = {}
    old_query_tokens = {}
    active = {}
    mma_keys = {}
    operations = Counter()
    first_wait = first_mma = None
    has_key_dma = False
    for index, command in enumerate(commands):
        operation = command.get("instruction", {}).get("op")
        if operation is None:
            if command["command"] != "wait":
                return group, 0
            if first_wait is None:
                first_wait = index
            continue
        operations[operation] += 1
        if operation not in ("fill", "load", "mma", "store"):
            return group, 0
        instruction = command["instruction"]
        if operation == "load":
            if command["command"] != "async":
                return group, 0
            if instruction["tensor"] in key_tensors:
                has_key_dma = True
                continue
            global_view = instruction["global"]
            local_view = instruction["local"]
            if (global_view["rows"] != 1 or global_view["cols"] != 64 or
                    local_view["rows"] != 1 or local_view["cols"] != 64 or
                    local_view["col_stride"] != 1):
                return group, 0
            key = _query_key(instruction)
            query_loads.setdefault(key, instruction)
            token = command["token"]
            if token in old_query_tokens:
                return group, 0
            old_query_tokens[token] = key
            active[local_view["base"]] = key
        elif operation == "mma":
            if first_mma is None:
                first_mma = index
            if (command["command"] != "run" or
                    (instruction["m"], instruction["n"], instruction["k"]) != (1, 32, 64) or
                    instruction["a"] not in active):
                return group, 0
            mma_keys[index] = active[instruction["a"]]
        elif command["command"] != "run":
            return group, 0
    if (not has_key_dma or not operations["mma"] or
            not 1 <= len(query_loads) <= 4 or
            len(old_query_tokens) <= len(query_loads) or
            first_wait is None or first_mma is None or first_wait > first_mma):
        return group, 0
    # All hoisted panels sit above the old RF reservation.  The old scratch
    # addresses can still be used by the K double buffer and accumulator.
    base = group["rf_kib"] * 256
    allocation = {key: base + 64 * index for index, key in enumerate(query_loads)}
    rf_kib = math.ceil((base + 64 * len(query_loads)) / 256)
    next_token = max((command.get("token", 0) for command in commands), default=0) + 1
    prefetch_tokens = {}
    updated = []
    for key, instruction in query_loads.items():
        selected = copy.deepcopy(instruction)
        selected["local"]["base"] = allocation[key]
        prefetch_tokens[key] = next_token
        updated.append({"command": "async", "token": next_token,
                        "instruction": selected})
        next_token += 1
    for index, command in enumerate(commands):
        instruction = command.get("instruction", {})
        if (instruction.get("op") == "load" and
                command["token"] in old_query_tokens):
            continue
        selected = copy.deepcopy(command)
        if selected["command"] == "wait":
            tokens = [token for token in selected["tokens"]
                      if token not in old_query_tokens]
            if index == first_wait:
                tokens = list(prefetch_tokens.values()) + tokens
            if not tokens:
                continue
            selected["tokens"] = tokens
        elif instruction.get("op") == "mma":
            selected["instruction"]["a"] = allocation[mma_keys[index]]
        updated.append(selected)
    return dict(group, rf_kib=rf_kib, commands=updated), len(old_query_tokens) - len(query_loads)


def _key_tensors(source):
    records = program_records(source)
    header = next(records)
    input_k = []
    tensors = []
    candidates = []
    for record in records:
        kind = record["record"]
        if kind in ("input", "alloc"):
            index = len(tensors)
            tensors.append(record)
            if kind == "input" and str(record.get("source", "")).endswith(".past_k"):
                input_k.append(index)
            elif kind == "alloc" and input_k:
                minimum = header["batch"] * header["shape"]["d"] * (
                    header["shape"]["history"] + header["shape"]["steps"])
                if minimum <= record["len"] <= minimum + 16 * header["batch"] * header["shape"]["d"]:
                    candidates.append(index)
                    if len(candidates) == header["shape"]["layers"]:
                        break
        elif kind == "release":
            if record["tensor"] != len(tensors) - 1:
                raise ValueError("unexpected preamble release")
            tensors.pop()
    if len(input_k) != header["shape"]["layers"] or len(candidates) != len(input_k):
        raise ValueError("could not identify each persistent transposed K tensor")
    return frozenset(candidates)


def _wave(record, key_tensors, hardware):
    groups = []
    removed = 0
    changed = 0
    for group in record["groups"]:
        selected, count = hoist_group(group, key_tensors)
        groups.append(selected)
        removed += count
        changed += count > 0
    if changed:
        validate_wave_capacity(groups, hardware)
    return {"record": "wave", "groups": groups}, changed, removed


def screen(source, manifest_path, case, output):
    source, manifest_path, output = map(Path, (source, manifest_path, output))
    manifest = json.loads(manifest_path.read_text())
    if case != "w-d4l" or sha(source) != manifest["program_sha256"][case]:
        raise ValueError("source or case differs from five-case manifest")
    hardware = manifest["hardware"]
    if next(program_records(source))["hardware"] != hardware:
        raise ValueError("shared hardware differs")
    key_tensors = _key_tensors(source)
    old = new = groups = waves = removed = 0
    cache = {}
    records = program_records(source)
    next(records)
    for record in records:
        if record["record"] != "wave":
            continue
        selected, changed, count = _wave(record, key_tensors, hardware)
        if not changed:
            continue
        old += estimate_wave(record["groups"], hardware, cache)
        new += estimate_wave(selected["groups"], hardware, cache)
        groups += changed
        waves += 1
        removed += count
    if not groups:
        raise ValueError("no repeated QK query loads found")
    cycles = dict(manifest["model_cycles"])
    cycles[case] += new - old
    score = 1000 * math.exp(sum(weight * math.log(reference / cycles[name])
                                for name, (reference, weight) in SCORE_CASES.items()))
    result = {"case": case, "source_sha256": sha(source),
              "manifest_sha256": sha(manifest_path),
              "screen_code_sha256": sha(__file__),
              "estimator_sha256": sha(Path(__file__).with_name("estimate.py")),
              "key_tensors": sorted(key_tensors),
              "changed_waves": waves, "changed_groups": groups,
              "removed_query_dma": removed,
              "original_affected_cycles": old,
              "replacement_affected_cycles": new,
              "cycle_delta": new - old,
              "five_case_model_cycles": cycles,
              "five_case_model_score": score,
              "meets_grade_gate": score >= 5000,
              "candidate_program_generated": False, "official_score": None}
    output.parent.mkdir(parents=True, exist_ok=True)
    write(output, result)
    return result


def materialize(source, manifest_path, screen_path, output_dir):
    source, manifest_path, screen_path, output_dir = map(
        Path, (source, manifest_path, screen_path, output_dir))
    result = json.loads(screen_path.read_text())
    if (not result["meets_grade_gate"] or result["five_case_model_score"] < 5000 or
            sha(source) != result["source_sha256"] or
            sha(manifest_path) != result["manifest_sha256"] or
            sha(__file__) != result["screen_code_sha256"] or
            sha(Path(__file__).with_name("estimate.py")) != result["estimator_sha256"]):
        raise ValueError("five-case model gate or screened inputs changed")
    manifest = json.loads(manifest_path.read_text())
    case = result["case"]
    hardware = manifest["hardware"]
    if (manifest["program_sha256"][case] != result["source_sha256"] or
            sorted(_key_tensors(source)) != result["key_tensors"]):
        raise ValueError("source tensor identity changed")
    with tempfile.TemporaryDirectory(prefix="decode-qk-query-hoist-", dir="/tmp") as temporary:
        expanded = Path(temporary) / "expanded.jsonl"
        compact = Path(temporary) / f"{case}.jsonl"
        changed_groups = removed = 0
        records = program_records(source)
        header = next(records)
        with expanded.open("x") as writer:
            writer.write(json.dumps(header, separators=(",", ":")) + "\n")
            for record in records:
                if record["record"] == "wave":
                    record, changed, count = _wave(record, frozenset(result["key_tensors"]), hardware)
                    changed_groups += changed
                    removed += count
                writer.write(json.dumps(record, separators=(",", ":")) + "\n")
        if changed_groups != result["changed_groups"] or removed != result["removed_query_dma"]:
            raise ValueError("materialized QK groups differ from screen")
        subprocess.run([sys.executable, str(STARTER / "tools/compact_program.py"),
                        str(expanded), str(compact)], check=True)
        exact = estimate_program(compact)["cycles"]
        if exact != result["five_case_model_cycles"][case]:
            raise ValueError("materialized full model differs from in-memory screen")
        output_dir.mkdir(parents=True, exist_ok=False)
        destination = output_dir / f"{case}.jsonl"
        shutil.move(str(compact), destination)
    receipt = {"case": case, "source_sha256": sha(source),
               "program_sha256": sha(destination), "screen_sha256": sha(screen_path),
               "changed_groups": changed_groups, "removed_query_dma": removed,
               "exact_model_cycles": exact,
               "five_case_model_score": result["five_case_model_score"],
               "grade_allowed": True, "official_score": None}
    write(output_dir / "manifest.json", receipt)
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    probe = sub.add_parser("screen")
    probe.add_argument("source", type=Path)
    probe.add_argument("manifest", type=Path)
    probe.add_argument("case")
    probe.add_argument("output", type=Path)
    emit = sub.add_parser("materialize")
    emit.add_argument("source", type=Path)
    emit.add_argument("manifest", type=Path)
    emit.add_argument("screen", type=Path)
    emit.add_argument("output_dir", type=Path)
    args = parser.parse_args()
    if args.command == "screen":
        print(json.dumps(screen(args.source, args.manifest, args.case, args.output), indent=2))
    else:
        print(json.dumps(materialize(args.source, args.manifest, args.screen,
                                     args.output_dir), indent=2))


if __name__ == "__main__":
    main()
