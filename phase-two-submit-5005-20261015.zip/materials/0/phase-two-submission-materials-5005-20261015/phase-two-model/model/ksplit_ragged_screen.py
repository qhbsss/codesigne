"""Reprice causal score localization on the RF-tier2 K-split portfolio."""

import argparse
import json
from pathlib import Path

from .estimate import estimate_wave, program_records
from .ksplit_screen import _pack_waves, split_group
from .local_causal_mask import _localize_group, _mask_wave
from .tool import sha, write


def _cost(groups, hardware, max_k, cache):
    converted = [split_group(group, max_k)[0] for group in groups]
    return sum(estimate_wave(batch, hardware, cache)
               for batch in _pack_waves(converted, hardware))


def screen_case(source, hardware, baseline_cycles, max_k):
    records = program_records(source)
    header = next(records)
    if header["decode"] or header["batch"] != 1:
        raise ValueError("ragged mask requires batch-one prefill")
    context = header["shape"]["prefill"]
    heads = header["shape"]["heads"]
    layers = header["shape"]["layers"]
    active = []
    pending_score_run = []
    cache = {}
    removed = changed = inserted = delta = score_allocations = 0

    def finish_score_run():
        nonlocal score_allocations
        if len(pending_score_run) == heads:
            for index in pending_score_run:
                active[index] = True
            score_allocations += heads
        pending_score_run.clear()

    for record in records:
        kind = record["record"]
        if kind in ("input", "alloc"):
            score_sized = kind == "alloc" and record["len"] == context * context
            if not score_sized:
                finish_score_run()
            active.append(False)
            if score_sized:
                pending_score_run.append(len(active) - 1)
            continue
        finish_score_run()
        if kind == "release":
            if record["tensor"] != len(active) - 1:
                raise ValueError("tensor stack changed")
            active.pop()
            continue
        if kind != "wave":
            continue
        score_ids = {index for index, flag in enumerate(active) if flag}
        groups = record["groups"]
        if _mask_wave(groups, score_ids, context):
            delta -= _cost(groups, hardware, max_k, cache)
            removed += 1
            continue
        replacement = []
        fills = 0
        for group in groups:
            candidate, n = _localize_group(group, score_ids, context,
                                           hardware["dma_engines"] * (1 + hardware["dma_depth"]))
            replacement.append(candidate)
            fills += n
        if fills:
            old = _cost(groups, hardware, max_k, cache)
            new = _cost(replacement, hardware, max_k, cache)
            delta += new - old
            changed += 1
            inserted += fills
    if score_allocations != heads * layers or not removed or not changed:
        raise ValueError(f"incomplete causal attention stage: score_allocations={score_allocations}, "
                         f"expected={heads * layers}, masks={removed}, av={changed}")
    return {"source_sha256": sha(source), "baseline_cycles": baseline_cycles,
            "mask_waves_removed": removed, "av_waves_changed": changed,
            "rf_fills_inserted": inserted, "delta_cycles": delta,
            "predicted_cycles": baseline_cycles + delta}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("base_solution", type=Path)
    parser.add_argument("ksplit_screen", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    base = json.loads(args.base_solution.read_text())
    prior = json.loads(args.ksplit_screen.read_text())
    result = {}
    for case in ("w-p", "a-p"):
        source = base["selected_programs"][case]["program"]
        max_k = prior.get("case_max_k", {}).get(case, prior["max_k"])
        result[case] = screen_case(source, prior["hardware"],
                                   prior["cases"][case]["cycles"], max_k)
        print(case, result[case], flush=True)
    write(args.output, {"cases": result, "candidate_program_generated": False,
                        "official_score": None})


if __name__ == "__main__":
    main()
