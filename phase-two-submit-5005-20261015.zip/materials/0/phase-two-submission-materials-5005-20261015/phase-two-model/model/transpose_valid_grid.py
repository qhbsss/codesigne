"""Price initialized-only decode K transpose tiles under wave admission limits."""

import argparse
import json
from pathlib import Path

from .direct_k import _shared_transpose_waves
from .estimate import estimate_wave, program_records
from .materialize_qualified import _shared_transpose_pair
from .tool import write


def screen_case(source, hardware, feature_tiles, context_tiles):
    records = program_records(source)
    header = dict(next(records), hardware=hardware)
    pairs = []
    for record in records:
        if record["record"] == "wave":
            pair = _shared_transpose_pair(record)
            if pair is not None:
                pairs.append(pair)
                if len(pairs) == header["shape"]["layers"]:
                    break
    if len(pairs) != header["shape"]["layers"]:
        raise ValueError("persistent K transpose layers missing")
    candidates = []
    for feature in feature_tiles:
        for context in context_tiles:
            if (feature, context) not in {
                    (32, 128), (64, 64), (96, 48), (128, 32),
                    (160, 24), (224, 16), (256, 16), (512, 8)}:
                continue
            try:
                cache = {}
                cycles = waves_count = 0
                for pair in pairs:
                    waves, _, _ = _shared_transpose_waves(header, *pair, feature, context)
                    cycles += sum(estimate_wave(wave["groups"], hardware, cache)
                                  for wave in waves)
                    waves_count += len(waves)
                candidates.append({"feature_tile": feature, "context_tile": context,
                                   "cycles": cycles, "waves": waves_count})
            except ValueError:
                continue
    candidates.sort(key=lambda item: (item["cycles"], item["waves"],
                                      item["feature_tile"], item["context_tile"]))
    return {"best": candidates[:20], "tested": len(candidates)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("base_solution", type=Path)
    parser.add_argument("hardware", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--cases", nargs="+", default=["w-d1", "w-d16", "w-d4l"])
    args = parser.parse_args()
    base = json.loads(args.base_solution.read_text())
    document = json.loads(args.hardware.read_text())
    hardware = document.get("hardware", document)
    features = (32, 48, 64, 96, 112, 128, 160, 192, 224, 256, 320, 384, 448, 512)
    contexts = (8, 12, 16, 24, 32, 48, 64, 96, 128)
    result = {}
    for case in args.cases:
        source = base["selected_programs"][case]["program"]
        result[case] = screen_case(source, hardware, features, contexts)
        print(case, result[case]["tested"], result[case]["best"][:3], flush=True)
        write(args.output, {"cases": result, "candidate_program_generated": False,
                            "official_score": None})


if __name__ == "__main__":
    main()
