"""Choose one shared hardware and one existing static program per case."""

import argparse
import json
import math
import shutil
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

from .estimate import InfeasibleProgramError, estimate_program
from .hardware import area, validate
from .structured import solve_master
from .tool import ROOT, SCORE_CASES, STARTER, sha, write


def _read_json(path):
    return json.loads(Path(path).read_text())


class EstimationBudgetReached(Exception):
    pass


def _validated_program_paths(spec):
    if set(spec) != {"hardware_options", "target_score"} or spec["target_score"] <= 0:
        raise ValueError("portfolio requires hardware_options and a positive target_score")
    if not spec["hardware_options"]:
        raise ValueError("portfolio has no hardware options")
    paths = []
    for design in spec["hardware_options"]:
        name, programs = design["name"], design["programs"]
        if set(programs) != set(SCORE_CASES) or any(not choices for choices in programs.values()):
            raise ValueError(f"{name} needs nonempty program choices for all five cases")
        hardware = None
        for case_name in SCORE_CASES:
            expected = _read_json(STARTER / "configs/reference" / f"{case_name}.json")
            for path_string in programs[case_name]:
                program = ROOT / path_string
                with program.open() as source:
                    header = json.loads(next(source))
                if any(header[field] != expected[field]
                       for field in ("shape", "batch", "decode")):
                    raise ValueError(f"incorrect workload for {program}")
                candidate_hardware = header["hardware"]
                validate(candidate_hardware)
                if hardware is None:
                    hardware = candidate_hardware
                if hardware != candidate_hardware:
                    raise ValueError(f"{name} does not share one hardware: {program}")
                paths.append(program)
    return paths


def _estimate_cache_entry(program_string, digest, estimator_hash):
    program = Path(program_string)
    if sha(program) != digest:
        raise RuntimeError(f"program changed before estimation: {program}")
    entry = {"program_sha256": digest, "estimator_sha256": estimator_hash,
             "program": str(program)}
    try:
        entry["cycles"] = estimate_program(program)["cycles"]
    except InfeasibleProgramError as error:
        entry["infeasible"] = str(error)
    if sha(program) != digest:
        raise RuntimeError(f"program changed during estimation: {program}")
    return entry


def _write_estimate_cache(cache_path, cache):
    temporary = cache_path.with_name("estimates.json.tmp")
    write(temporary, cache)
    temporary.replace(cache_path)


def _progress(spec, cache, new_estimates):
    return {"cached_unique_estimates": len(cache),
            "new_estimates_in_batch": new_estimates,
            "total_program_choices": sum(len(choices) for design in spec["hardware_options"]
                                         for choices in design["programs"].values()),
            "completed": False, "official_score": None}


def _register_request_timing(evidence, expected_headers, case_name, digest, header,
                             report, source, expected_source, numerical_checked, path,
                             ignore_unknown=False):
    key = case_name, digest
    if key not in expected_headers:
        if ignore_unknown:
            return
        raise ValueError(f"timing does not identify a portfolio program: {path}")
    if header != expected_headers[key] or source != expected_source:
        raise ValueError(f"timing header or source does not match program: {path}")
    cycles = report["stats"]["cycles"]
    if (type(cycles) is not int or cycles <= 0 or
            report["power_pass"] is not True):
        raise ValueError(f"ineligible request timing: {path}")
    previous = evidence.get(key)
    if previous is not None and previous["cycles"] != cycles:
        raise ValueError(f"conflicting request timing for {case_name}: {path}")
    if previous is None or numerical_checked and not previous["numerical_checked"]:
        evidence[key] = {"cycles": cycles, "numerical_checked": numerical_checked,
                         "source": str(path)}


def _checked_evaluation(report):
    if (report["status"] != "complete" or report["mode"] != "evaluate" or
            report["seed"] != 7 or report.get("error") is not None):
        return False
    evaluation = report["evaluation"]
    return (bool(evaluation.get("output_sha256")) and
            isinstance(evaluation.get("comparison"), dict) and
            evaluation["report"]["power_pass"] is True)


def prepare_portfolio(spec, estimate=None):
    estimate = estimate or estimate_program
    hardware_options = []
    program_options = []
    rejected = []
    if set(spec) != {"hardware_options", "target_score"} or spec["target_score"] <= 0:
        raise ValueError("portfolio requires hardware_options and a positive target_score")
    if not spec["hardware_options"]:
        raise ValueError("portfolio has no hardware options")
    for hardware_index, design in enumerate(spec["hardware_options"]):
        name, programs = design["name"], design["programs"]
        if set(programs) != set(SCORE_CASES) or any(not choices for choices in programs.values()):
            raise ValueError(f"{name} needs nonempty program choices for all five cases")
        hardware = None
        prepared = []
        for case_name in SCORE_CASES:
            expected = _read_json(STARTER / "configs/reference" / f"{case_name}.json")
            for path_string in programs[case_name]:
                program = ROOT / path_string
                with program.open() as source:
                    header = json.loads(next(source))
                if any(header[field] != expected[field] for field in ("shape", "batch", "decode")):
                    raise ValueError(f"incorrect workload for {program}")
                candidate_hardware = header["hardware"]
                validate(candidate_hardware)
                if hardware is None:
                    hardware = candidate_hardware
                if hardware != candidate_hardware:
                    raise ValueError(f"{name} does not share one hardware: {program}")
                digest = sha(program)
                try:
                    cycles = estimate(program)
                    if isinstance(cycles, dict):
                        cycles = cycles["cycles"]
                    if not isinstance(cycles, (int, float)) or not math.isfinite(cycles) or cycles <= 0:
                        raise ValueError("invalid estimate")
                except InfeasibleProgramError as error:
                    rejected.append({"case": case_name, "program": str(program),
                                     "reason": str(error)})
                    continue
                if sha(program) != digest:
                    raise RuntimeError(f"program changed during estimation: {program}")
                prepared.append({"hardware_index": hardware_index, "case": case_name,
                                 "status": "unverified", "lower_bound_cycles": 1,
                                 "estimated_cycles": cycles, "program_sha256": digest,
                                 "program": str(program)})
        if any(not any(option["case"] == case_name for option in prepared)
               for case_name in SCORE_CASES):
            rejected.append({"hardware": name, "reason": "missing feasible case"})
            continue
        hardware_options.append({"index": hardware_index, "design": {"name": name},
                                 "hardware": hardware, "area_au": area(hardware)})
        program_options.extend(prepared)
    if not hardware_options:
        raise ValueError("no hardware has a feasible program for all five cases")
    return hardware_options, program_options, rejected


def select_portfolio(hardware_options, program_options, target_score):
    case_weights = {case: weight for case, (_, weight) in SCORE_CASES.items()}
    proposal, solver = solve_master(hardware_options, program_options, case_weights,
                                    costs=[math.log(option["estimated_cycles"])
                                           for option in program_options])
    if proposal is None:
        raise RuntimeError(f"portfolio MILP did not complete: {solver['message']}")
    hardware, selected_indices = proposal
    selected = {program_options[index]["case"]: program_options[index]
                for index in selected_indices}
    score = 1000 * math.exp(sum(
        case_weights[case_name] * math.log(SCORE_CASES[case_name][0] /
                                      selected[case_name]["estimated_cycles"])
        for case_name in SCORE_CASES))
    return {"selected_hardware": hardware, "selected_programs": selected,
            "conditional_predicted_score": score, "target_score": target_score,
            "target_prediction_met": score >= target_score, "solver": solver,
            "optimality_scope": "conditional independent estimates over the declared finite programs",
            "official_score": None}


def run(spec_path, output, resume=False, max_new_estimates=None, workers=1):
    spec_path, output = Path(spec_path), Path(output)
    spec = _read_json(spec_path)
    if (max_new_estimates is not None and
            (type(max_new_estimates) is not int or max_new_estimates < 0)):
        raise ValueError("max_new_estimates must be a nonnegative integer")
    if type(workers) is not int or workers < 1:
        raise ValueError("workers must be a positive integer")
    if resume:
        if _read_json(output / "spec.json") != spec:
            raise ValueError("resume requires an unchanged portfolio specification")
    else:
        output.mkdir(parents=True, exist_ok=False)
        write(output / "spec.json", spec)
    estimator_hash = sha(Path(__file__).with_name("estimate.py"))
    cache_path = output / "estimates.json"
    cache = _read_json(cache_path) if resume and cache_path.exists() else {}
    new_estimates = 0

    if workers > 1:
        missing = []
        seen = set()
        for program in _validated_program_paths(spec):
            digest = sha(program)
            key = f"{estimator_hash}:{digest}"
            if key not in cache and key not in seen:
                seen.add(key)
                missing.append((program, digest, key))
        selected = (missing if max_new_estimates is None
                    else missing[:max_new_estimates])
        with ProcessPoolExecutor(max_workers=workers) as executor:
            futures = {executor.submit(_estimate_cache_entry, str(program), digest,
                                       estimator_hash): key
                       for program, digest, key in selected}
            for future in as_completed(futures):
                cache[futures[future]] = future.result()
                _write_estimate_cache(cache_path, cache)
                new_estimates += 1
        if len(selected) < len(missing):
            write(output / "progress.json", _progress(spec, cache, new_estimates))
            return None

    def cached_estimate(program):
        nonlocal new_estimates
        digest = sha(program)
        key = f"{estimator_hash}:{digest}"
        if key not in cache:
            if max_new_estimates is not None and new_estimates >= max_new_estimates:
                raise EstimationBudgetReached
            cache[key] = _estimate_cache_entry(str(program), digest, estimator_hash)
            _write_estimate_cache(cache_path, cache)
            new_estimates += 1
        if "infeasible" in cache[key]:
            raise InfeasibleProgramError(cache[key]["infeasible"])
        return cache[key]["cycles"]

    try:
        hardware_options, program_options, rejected = prepare_portfolio(spec, cached_estimate)
    except EstimationBudgetReached:
        write(output / "progress.json", _progress(spec, cache, new_estimates))
        return None
    (output / "progress.json").unlink(missing_ok=True)
    result = select_portfolio(hardware_options, program_options, spec["target_score"])
    result["rejected"] = rejected
    result["estimator_sha256"] = estimator_hash
    result["hardware_options"] = len(hardware_options)
    result["program_options"] = len(program_options)
    write(output / "solution.json", result)
    programs = output / "programs"
    programs.mkdir(exist_ok=resume)
    for case_name, option in result["selected_programs"].items():
        program = Path(option["program"])
        if sha(program) != option["program_sha256"]:
            raise RuntimeError(f"selected program changed: {program}")
        destination = programs / f"{case_name}.jsonl"
        if not destination.exists() or sha(destination) != option["program_sha256"]:
            shutil.copyfile(program, destination)
        if sha(destination) != option["program_sha256"]:
            raise RuntimeError(f"copied program changed: {destination}")
    return result


def summarize_request_timing(output):
    output = Path(output)
    solution = _read_json(output / "solution.json")
    selected_hardware = solution["selected_hardware"]["hardware"]
    cases = {}
    sources = set()
    for case_name, option in solution["selected_programs"].items():
        prediction = _read_json(output / f"timing-{case_name}/prediction.json")
        result = prediction["result"]
        if prediction["backend"] != "shared_official_transition_core":
            raise ValueError(f"unexpected timing backend for {case_name}")
        if (result["program_sha256"] != option["program_sha256"] or
                sha(output / "programs" / f"{case_name}.jsonl") != option["program_sha256"] or
                result["header"]["hardware"] != selected_hardware):
            raise ValueError(f"prediction does not match selected program: {case_name}")
        sources.add(prediction["source_sha256"])
        report = result["report"]
        cases[case_name] = {"estimated_cycles": option["estimated_cycles"],
                            "request_timing_cycles": report["stats"]["cycles"],
                            "program_sha256": option["program_sha256"],
                            "power_pass": report["power_pass"],
                            "numerical_correctness": result["numerical_correctness"],
                            "source_sha256": prediction["source_sha256"]}
    if len(sources) != 1 or set(cases) != set(SCORE_CASES):
        raise ValueError("five matching cases must use one timing source")
    score = 1000 * math.exp(sum(
        weight * math.log(reference / cases[case_name]["request_timing_cycles"])
        for case_name, (reference, weight) in SCORE_CASES.items()))
    summary = {"backend": "shared_official_transition_core",
               "source_sha256": sources.pop(), "cases": cases,
               "score_if_all_eligible": score,
               "target_score": solution["target_score"],
               "target_prediction_met": score >= solution["target_score"],
               "numerical_correctness": "not_checked",
               "official_score": None,
               "not_an_independent_v2_request_model": True}
    write(output / "timing-summary.json", summary)
    return summary


def refine_with_request_evidence(spec_path, output):
    output = Path(output)
    solution = _read_json(output / "solution.json")
    if _read_json(output / "spec.json") != _read_json(spec_path):
        raise ValueError("portfolio specification changed")
    estimator_hash = sha(Path(__file__).with_name("estimate.py"))
    if solution["estimator_sha256"] != estimator_hash:
        raise ValueError("independent estimator changed")
    cache = _read_json(output / "estimates.json")

    def cached_estimate(program):
        digest = sha(program)
        key = f"{estimator_hash}:{digest}"
        if key not in cache:
            raise ValueError(f"missing same-SHA independent estimate: {program}")
        entry = cache[key]
        if (entry["program_sha256"] != digest or
                entry["estimator_sha256"] != estimator_hash):
            raise ValueError(f"estimate identity mismatch: {program}")
        return entry["cycles"]

    spec = _read_json(spec_path)
    hardware, options, _ = prepare_portfolio(spec, cached_estimate)
    base_receipt_path = STARTER / "runs/k4-rf-causal-rf-reuse-joint-grade-20261011/grade.json"
    base_receipt = _read_json(base_receipt_path)
    if base_receipt["status"] != "complete" or base_receipt["seed"] != 7:
        raise ValueError("base receipt must be complete with seed 7")
    expected_source = base_receipt["source_sha256"]
    evidence = {}
    expected_headers = {}
    for option in options:
        with Path(option["program"]).open() as program:
            header = json.loads(next(program))
        expected_headers[option["case"], option["program_sha256"]] = header

    for case_name, entry in base_receipt["cases"].items():
        key = case_name, entry["program_sha256"]
        if key not in expected_headers:
            continue
        header = expected_headers[key]
        if header["hardware"] != base_receipt["hardware"]:
            raise ValueError(f"base receipt hardware differs from program: {case_name}")
        _register_request_timing(
            evidence, expected_headers, case_name, entry["program_sha256"], header,
            {"stats": {"cycles": entry["cycles"]}, "power_pass": True},
            expected_source, expected_source, True, base_receipt_path)
    for run_name in ("regrade-hw-20261011", "rehead-search-20261011"):
        for path in sorted((output.parent / run_name).glob("*/grade/workers/*/evaluation/result.json")):
            report = _read_json(path)
            if not _checked_evaluation(report):
                continue
            evaluation = report["evaluation"]
            case_name = path.parents[1].name
            _register_request_timing(
                evidence, expected_headers, case_name, evaluation["program_sha256"],
                evaluation["header"], evaluation["report"], report["source_sha256"],
                expected_source, True, path, ignore_unknown=True)
    for case_name in SCORE_CASES:
        path = output / f"timing-{case_name}/prediction.json"
        prediction = _read_json(path)
        if prediction["backend"] != "shared_official_transition_core":
            raise ValueError(f"unexpected timing backend: {path}")
        result = prediction["result"]
        if result["numerical_correctness"] != "not_checked":
            raise ValueError(f"unexpected numerical status in timing report: {path}")
        _register_request_timing(
            evidence, expected_headers, case_name, result["program_sha256"],
            result["header"], result["report"], prediction["source_sha256"],
            expected_source, False, path)
    costs = []
    for option in options:
        key = option["case"], option["program_sha256"]
        if key not in evidence:
            raise ValueError(f"missing same-SHA request timing: {key}")
        costs.append(math.log(evidence[key]["cycles"]))
    case_weights = {case: weight for case, (_, weight) in SCORE_CASES.items()}
    proposal, solver = solve_master(hardware, options, case_weights, costs=costs)
    if proposal is None:
        raise RuntimeError(f"request-level MILP did not complete: {solver['message']}")
    chosen_hardware, chosen_indices = proposal
    selected = {}
    for index in chosen_indices:
        option = options[index]
        case_name = option["case"]
        selected[case_name] = {**option, **evidence[(case_name, option["program_sha256"])]}
    score = 1000 * math.exp(sum(
        weight * math.log(reference / selected[case_name]["cycles"])
        for case_name, (reference, weight) in SCORE_CASES.items()))
    result = {"scope": "request timing on declared finite programs with shared official core",
              "not_an_independent_v2_request_model": True,
              "source_sha256": expected_source, "selected_hardware": chosen_hardware,
              "selected_programs": selected, "score_if_all_eligible": score,
              "all_selected_numerically_checked": all(
                  option["numerical_checked"] for option in selected.values()),
              "unverified_cases": [case_name for case_name, option in selected.items()
                                   if not option["numerical_checked"]],
              "target_score": spec["target_score"],
              "target_prediction_met": score >= spec["target_score"],
              "solver": solver, "official_score": None}
    write(output / "request-mip-solution.json", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("spec", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--summarize-exact", action="store_true")
    parser.add_argument("--refine-exact", action="store_true")
    parser.add_argument("--max-new-estimates", type=int)
    parser.add_argument("--workers", type=int, default=1)
    args = parser.parse_args()
    result = run(args.spec, args.output, resume=args.resume,
                 max_new_estimates=args.max_new_estimates, workers=args.workers)
    if result is None:
        print(json.dumps(_read_json(args.output / "progress.json"), indent=2))
        return
    if args.refine_exact:
        refined = refine_with_request_evidence(args.spec, args.output)
        print(json.dumps({"score_if_all_eligible": refined["score_if_all_eligible"],
                          "target_prediction_met": refined["target_prediction_met"],
                          "all_selected_numerically_checked":
                              refined["all_selected_numerically_checked"],
                          "hardware": refined["selected_hardware"]["design"],
                          "solver": refined["solver"]}, indent=2))
        return
    if args.summarize_exact:
        summary = summarize_request_timing(args.output)
        print(json.dumps({"score_if_all_eligible": summary["score_if_all_eligible"],
                          "numerical_correctness": summary["numerical_correctness"],
                          "target_prediction_met": summary["target_prediction_met"]}, indent=2))
        return
    print(json.dumps({"conditional_predicted_score": result["conditional_predicted_score"],
                      "target_prediction_met": result["target_prediction_met"],
                      "hardware": result["selected_hardware"]["design"],
                      "solver": result["solver"]}, indent=2))


if __name__ == "__main__":
    main()
