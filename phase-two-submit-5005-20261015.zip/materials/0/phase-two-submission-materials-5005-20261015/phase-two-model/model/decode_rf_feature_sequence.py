"""Screen one-wave RF transposes with several feature blocks per workgroup.

The feature blocks own disjoint target rows.  A group reuses the same RF tile
for its blocks in sequence, so 16 batches can fit in one wave without raising
the per-SM RF reservation or the number of resident groups.  Materialization
is gated by a complete five-case model score and exact program re-estimation.
"""

import argparse
import json
import math
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

from .decode_rf_feature_retile import _view
from .decode_rf_transpose_screen import transpose_admission
from .estimate import estimate_program, estimate_wave, program_records, validate_wave_capacity
from .merge import MAX_COMMANDS
from .padded_k_transpose_screen import _records
from .tool import SCORE_CASES, STARTER, sha, write


OPTIONS = ((192, 16, 16, "striped"),
           (192, 16, 24, "striped"),
           (192, 16, 32, "striped"),
           (192, 16, 32, "contiguous"),
           (256, 16, 24, "striped"),
           (256, 16, 24, "contiguous"),
           (384, 16, 16, "striped"),
           (384, 16, 16, "contiguous"),
           (192, 32, 16, "striped"),
           (192, 32, 16, "contiguous"),
           (256, 32, 8, "striped"),
           (384, 32, 8, "striped"))


def sequence_waves(header, pair, feature_tile, context_tile, group_count,
                   assignment="striped"):
    """Map every input word once, assigning complete feature blocks to groups."""
    source, target, pitch = pair
    shape = header["shape"]
    hardware = header["hardware"]
    if (not header["decode"] or source == target or
            pitch < shape["history"] + shape["steps"] or
            feature_tile < 1 or context_tile < 1 or group_count < 1 or
            assignment not in ("striped", "contiguous")):
        raise ValueError("unsupported decode transpose layout")
    blocks = [(batch, feature, min(feature_tile, shape["d"] - feature))
              for batch in range(header["batch"])
              for feature in range(0, shape["d"], feature_tile)]
    if group_count > len(blocks):
        raise ValueError("more groups than feature blocks")
    groups = []
    task_count = 0
    input_pitch = header["batch"] * shape["d"]
    for index in range(group_count):
        if assignment == "striped":
            selected = blocks[index::group_count]
        else:
            width = math.ceil(len(blocks) / group_count)
            selected = blocks[index * width:(index + 1) * width]
        if not selected:
            raise ValueError("empty feature group")
        commands = []
        for batch, feature, rows in selected:
            local_stride = rows + 1
            for context in range(0, shape["history"], context_tile):
                cols = min(context_tile, shape["history"] - context)
                token = 1 + len(commands) // 3
                commands.extend((
                    {"command": "async", "token": token, "instruction": {
                        "op": "load", "tensor": source,
                        "global": _view(context * input_pitch + batch * shape["d"] + feature,
                                        cols, rows, input_pitch),
                        "local": _view(0, cols, rows, local_stride)}},
                    {"command": "wait", "tokens": [token]},
                    {"command": "run", "instruction": {
                        "op": "store", "tensor": target,
                        "global": _view((batch * shape["d"] + feature) * pitch + context,
                                        rows, cols, pitch),
                        "local": _view(0, rows, cols, 1, local_stride)}},
                ))
                task_count += 1
        maximum_words = context_tile * (max(rows for _, _, rows in selected) + 1)
        groups.append({"sm": index % hardware["sms"],
                       "rf_kib": math.ceil(maximum_words / 256),
                       "sh_kib": 0, "commands": commands})
    if sum(len(group["commands"]) for group in groups) > MAX_COMMANDS:
        raise ValueError("wave command limit exceeded")
    validate_wave_capacity(groups, hardware)
    wave = {"record": "wave", "groups": groups}
    intervals = transpose_admission(wave, pair)
    details = {"feature_tile": feature_tile, "context_tile": context_tile,
               "group_count": group_count, "assignment": assignment,
               "feature_blocks": len(blocks), "tasks": task_count,
               "waves": 1, "access_intervals_per_wave": [intervals],
               "maximum_rf_kib": max(group["rf_kib"] for group in groups),
               "commands": sum(len(group["commands"]) for group in groups)}
    return [wave], details


def screen(source, manifest_path, case, output, options=OPTIONS):
    source, manifest_path, output = map(Path, (source, manifest_path, output))
    manifest = json.loads(manifest_path.read_text())
    if case not in ("w-d1", "w-d16", "w-d4l") or sha(source) != manifest["program_sha256"][case]:
        raise ValueError("source or case differs from five-case manifest")
    header = next(program_records(source))
    hardware = manifest["hardware"]
    if header["hardware"] != hardware:
        raise ValueError("shared hardware differs")
    stages = {}
    for _, record, pair in _records(source):
        if pair is not None:
            stages.setdefault(pair, []).append(record)
    if len(stages) != header["shape"]["layers"]:
        raise ValueError("initial K transpose pair count differs from layers")
    cache = {}
    original = sum(estimate_wave(record["groups"], hardware, cache)
                   for records in stages.values() for record in records)
    rows = []
    for feature_tile, context_tile, group_count, assignment in options:
        row = {"feature_tile": feature_tile, "context_tile": context_tile,
               "group_count": group_count, "assignment": assignment}
        try:
            replacement = 0
            stage_rows = []
            for pair in stages:
                waves, details = sequence_waves(header, pair, feature_tile,
                                                context_tile, group_count, assignment)
                cost = sum(estimate_wave(wave["groups"], hardware, cache)
                           for wave in waves)
                replacement += cost
                stage_rows.append({"source": pair[0], "target": pair[1],
                                   "pitch": pair[2], "model_cycles": cost, **details})
            cycles = dict(manifest["model_cycles"])
            cycles[case] += replacement - original
            score = 1000 * math.exp(sum(weight * math.log(reference / cycles[name])
                                        for name, (reference, weight) in SCORE_CASES.items()))
            row.update({"replacement_cycles": replacement,
                        "cycle_delta": replacement - original,
                        "stages": stage_rows, "five_case_model_cycles": cycles,
                        "five_case_model_score": score,
                        "meets_grade_gate": score >= 5000})
        except ValueError as error:
            row["infeasible"] = str(error)
        rows.append(row)
        output.parent.mkdir(parents=True, exist_ok=True)
        write(output, {"case": case, "source_sha256": sha(source),
                       "manifest_sha256": sha(manifest_path),
                       "screen_code_sha256": sha(__file__),
                       "estimator_sha256": sha(Path(__file__).with_name("estimate.py")),
                       "admission_code_sha256": sha(Path(__file__).with_name(
                           "decode_rf_transpose_screen.py")),
                       "hardware": hardware, "original_affected_cycles": original,
                       "original_affected_waves": sum(map(len, stages.values())),
                       "options": rows, "candidate_program_generated": False,
                       "official_score": None})
        print(case, feature_tile, context_tile, group_count, assignment,
              row.get("replacement_cycles"), row.get("five_case_model_score"), flush=True)
    return rows


def materialize(source, manifest_path, screen_path, option_index, output_dir):
    source, manifest_path, screen_path, output_dir = map(
        Path, (source, manifest_path, screen_path, output_dir))
    result = json.loads(screen_path.read_text())
    if not 0 <= option_index < len(result["options"]):
        raise ValueError("option index was not screened")
    option = result["options"][option_index]
    if (not option.get("meets_grade_gate") or
            option["five_case_model_score"] < 5000 or
            sha(source) != result["source_sha256"] or
            sha(manifest_path) != result["manifest_sha256"] or
            sha(__file__) != result["screen_code_sha256"] or
            sha(Path(__file__).with_name("estimate.py")) != result["estimator_sha256"] or
            sha(Path(__file__).with_name("decode_rf_transpose_screen.py")) !=
            result["admission_code_sha256"]):
        raise ValueError("five-case model gate or screened inputs changed")
    manifest = json.loads(manifest_path.read_text())
    case = result["case"]
    if (manifest["hardware"] != result["hardware"] or
            manifest["program_sha256"][case] != result["source_sha256"]):
        raise ValueError("source manifest mismatch")
    with tempfile.TemporaryDirectory(prefix="decode-rf-feature-sequence-", dir="/tmp") as temporary:
        expanded = Path(temporary) / "expanded.jsonl"
        compact = Path(temporary) / f"{case}.jsonl"
        emitted = set()
        header_written = False
        with expanded.open("x") as writer:
            for header, record, pair in _records(source):
                if not header_written:
                    writer.write(json.dumps(header, separators=(",", ":")) + "\n")
                    header_written = True
                if pair is None:
                    writer.write(json.dumps(record, separators=(",", ":")) + "\n")
                elif pair not in emitted:
                    emitted.add(pair)
                    waves, details = sequence_waves(
                        header, pair, option["feature_tile"], option["context_tile"],
                        option["group_count"], option["assignment"])
                    screened = next((stage for stage in option["stages"]
                                     if (stage["source"], stage["target"], stage["pitch"]) == pair), None)
                    if screened is None or any(details[key] != screened[key] for key in details):
                        raise ValueError("retiled stage differs from screen")
                    for wave in waves:
                        writer.write(json.dumps(wave, separators=(",", ":")) + "\n")
        if len(emitted) != header["shape"]["layers"]:
            raise ValueError("missing initial K transpose")
        subprocess.run([sys.executable, str(STARTER / "tools/compact_program.py"),
                        str(expanded), str(compact)], check=True)
        exact = estimate_program(compact)["cycles"]
        if exact != option["five_case_model_cycles"][case]:
            raise ValueError("materialized full model differs from in-memory screen")
        output_dir.mkdir(parents=True, exist_ok=False)
        destination = output_dir / f"{case}.jsonl"
        shutil.move(str(compact), destination)
    receipt = {"case": case, "source_sha256": sha(source),
               "program_sha256": sha(destination), "screen_sha256": sha(screen_path),
               "option_index": option_index,
               "feature_tile": option["feature_tile"],
               "context_tile": option["context_tile"],
               "group_count": option["group_count"],
               "assignment": option["assignment"],
               "exact_model_cycles": exact,
               "five_case_model_score": option["five_case_model_score"],
               "grade_allowed": True, "official_score": None}
    write(output_dir / "manifest.json", receipt)
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    probe = sub.add_parser("screen")
    probe.add_argument("source", type=Path)
    probe.add_argument("manifest", type=Path)
    probe.add_argument("case")
    probe.add_argument("output", type=Path)
    emit = sub.add_parser("materialize")
    emit.add_argument("source", type=Path)
    emit.add_argument("manifest", type=Path)
    emit.add_argument("screen", type=Path)
    emit.add_argument("option_index", type=int)
    emit.add_argument("output_dir", type=Path)
    args = parser.parse_args()
    if args.command == "screen":
        screen(args.source, args.manifest, args.case, args.output)
    else:
        print(json.dumps(materialize(args.source, args.manifest, args.screen,
                                     args.option_index, args.output_dir), indent=2))


if __name__ == "__main__":
    main()
