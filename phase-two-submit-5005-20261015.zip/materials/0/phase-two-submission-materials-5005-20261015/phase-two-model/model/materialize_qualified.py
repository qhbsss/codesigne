"""Stream one qualified portfolio to JSONL and independently re-estimate it."""

import argparse
import copy
import json
import math
from pathlib import Path

from .balance_sm import balance_wave
from .direct_k import _shared_transpose_waves
from .estimate import estimate_wave, program_records, validate_wave_capacity
from .ksplit_screen import _pack_waves, split_group
from .ksplit_single_k_screen import _compact
from .local_causal_mask import _localize_group, _mask_wave
from .merge import (_adaptive_footprint, _append_commands,
                    _pipeline_and_combine, _pipeline_footprint,
                    MAX_COMMANDS, MAX_ACCESS_INTERVALS)
from .query_scale_screen import _q_scale_wave, _scaled_group
from .tool import SCORE_CASES, sha, write


def _instruction_accesses(record, op, tensor):
    return any(command.get("instruction", {}).get("op") == op and
               command["instruction"].get("tensor") == tensor
               for group in record["groups"] for command in group["commands"])


def _shared_transpose_pair(record):
    instructions = [command["instruction"] for group in record["groups"]
                    for command in group["commands"] if "instruction" in command]
    if not instructions or {item["op"] for item in instructions} != (
            {"load_shared", "store_shared"}):
        return None
    loads = {item["tensor"] for item in instructions if item["op"] == "load_shared"}
    stores = {item["tensor"] for item in instructions if item["op"] == "store_shared"}
    if len(loads) != 1 or len(stores) != 1:
        return None
    return next(iter(loads)), next(iter(stores))


def _merge_pair(left, right, mode, hardware):
    footprint = _adaptive_footprint if mode == "adaptive" else _pipeline_footprint
    a, b = footprint(left), footprint(right)
    if a is None or b is None or a["key"] != b["key"]:
        raise ValueError(f"selected {mode} pair is no longer compatible")
    if (a["commands"] + b["commands"] > MAX_COMMANDS or
            a["access_intervals"] + b["access_intervals"] > MAX_ACCESS_INTERVALS):
        raise ValueError("selected pair exceeds compact wave admission")
    if _pipeline_and_combine(a["intervals"], b["intervals"]) is None:
        raise ValueError("selected pair has cross-group read/write dependency")
    merged = copy.deepcopy(left)
    _append_commands(merged, copy.deepcopy(right))
    merged["groups"] = [dict(group, rf_kib=max(group["rf_kib"], other["rf_kib"]),
                             sh_kib=max(group["sh_kib"], other["sh_kib"]))
                        for group, other in zip(merged["groups"], right["groups"])]
    validate_wave_capacity(merged["groups"], hardware)
    return merged


def _renumber_tokens(groups):
    """The compact evaluator requires unique token IDs across each whole group."""
    for group in groups:
        active = {}
        next_token = 1
        for command in group["commands"]:
            if command["command"] == "async":
                old = command["token"]
                if old in active:
                    raise ValueError("async token reused before its wait")
                active[old] = next_token
                command["token"] = next_token
                next_token += 1
            elif command["command"] == "wait":
                command["tokens"] = [active.pop(old) for old in command["tokens"]]
        if active:
            raise ValueError("unwaited async token at wave end")


def _appended_k_updates(record, source_to_target, header):
    shape = header["shape"]
    batch, d = header["batch"], shape["d"]
    updates = set()
    for group in record["groups"]:
        for command in group["commands"]:
            instruction = command.get("instruction", {})
            if (instruction.get("op") != "store" or
                    instruction.get("tensor") not in source_to_target):
                continue
            view = instruction["global"]
            if view["cols"] != d or view["rows"] != 1 or view["col_stride"] != 1:
                raise ValueError("unsupported appended K store layout")
            context, remainder = divmod(view["base"], batch * d)
            sample, offset = divmod(remainder, d)
            if offset or not shape["history"] <= context < shape["history"] + shape["steps"]:
                raise ValueError("unexpected appended K address")
            updates.add((instruction["tensor"], source_to_target[instruction["tensor"]],
                         context, sample))
    return sorted(updates)


def _append_k_wave(updates, header, hardware):
    d = header["shape"]["d"]
    capacity = header["shape"]["history"] + header["shape"]["steps"]
    batch = header["batch"]
    groups = []
    for index, (source, target, context, sample) in enumerate(updates):
        source_base = (context * batch + sample) * d
        target_base = sample * d * capacity + context
        groups.append({"sm": index % hardware["sms"],
                       "rf_kib": math.ceil(d / 256), "sh_kib": 0,
                       "commands": [
                           {"command": "async", "token": 1, "instruction": {
                               "op": "load", "tensor": source,
                               "global": {"base": source_base, "rows": 1,
                                          "cols": d, "row_stride": d, "col_stride": 1},
                               "local": {"base": 0, "rows": 1,
                                         "cols": d, "row_stride": d, "col_stride": 1}}},
                           {"command": "wait", "tokens": [1]},
                           {"command": "run", "instruction": {
                               "op": "store", "tensor": target,
                               "global": {"base": target_base, "rows": d,
                                          "cols": 1, "row_stride": capacity,
                                          "col_stride": 1},
                               "local": {"base": 0, "rows": d,
                                         "cols": 1, "row_stride": 1,
                                         "col_stride": 1}}}]})
    validate_wave_capacity(groups, hardware)
    return {"record": "wave", "groups": groups}


def materialize_case(source, destination, case, hardware, max_k, screens,
                     transpose_tile=None):
    records = program_records(source)
    header = next(records)
    header = dict(header, hardware=hardware)
    # The saved base screen predates the optional K=112 splitter and leaves
    # those waves unsplit.  Only rows with positive savings should be split.
    k112 = {row["wave"] for row in screens["k112"].get(case, {}).get("waves", [])
            if row["saving"] > 0}
    single_k = {row["wave"] for row in screens["single_k"].get(case, {}).get("accepted_waves", [])}
    balanced = {row["wave"] for row in screens["balance"].get(case, {}).get("accepted_waves", [])}
    selected_merge = screens["merge"].get(case, {}).get("selected", [])
    if case in ("w-p", "a-p"):
        selected_merge = screens["prefill_merge"].get(case, {}).get("accepted", [])
    elif transpose_tile is not None:
        # New K must be copied into the transposed cache between K and V waves.
        selected_merge = [row for row in selected_merge
                          if not (row["mode"] == "pipeline" and row["saving"] <= 21)]
    merge_left = {row["left"]: row for row in selected_merge}
    merge_right = {row["right"]: row for row in selected_merge}
    if len(merge_left) != len(selected_merge) or len(merge_right) != len(selected_merge):
        raise ValueError("overlapping selected merge pairs")
    active = []
    pending_score_run = []
    qkv_pending = set()
    qkv_written = set()
    qkv_scaled = set()
    transpose_emitted = set()
    source_to_target = {}
    pending_merge = None
    source_wave = -1
    cycles = 0
    output_waves = 0
    query_scale_waves = 0
    appended_k_waves = 0
    dropped_masks = 0
    cache = {}
    shape = header["shape"]
    is_prefill = case in ("w-p", "a-p")
    scale = 0.125 if case == "a-p" else None

    def finish_score_run():
        if len(pending_score_run) == shape["heads"]:
            for index in pending_score_run:
                active[index] = True
        pending_score_run.clear()

    def output_record(writer, record):
        nonlocal cycles, output_waves
        if record.get("record") == "wave":
            _renumber_tokens(record["groups"])
            validate_wave_capacity(record["groups"], hardware)
            cycles += estimate_wave(record["groups"], hardware, cache)
            output_waves += 1
        elif record.get("record") == "commit":
            cycles += 1
        writer.write(json.dumps(record, separators=(",", ":")) + "\n")

    def flush_pending(writer):
        nonlocal pending_merge
        if pending_merge is not None:
            output_record(writer, pending_merge[1])
            pending_merge = None

    def emit_wave(writer, record, source_index=None):
        nonlocal pending_merge
        if source_index in merge_right:
            choice = merge_right[source_index]
            if pending_merge is None or pending_merge[0] != choice["left"]:
                raise ValueError("right merge wave has no adjacent left wave")
            mode = choice.get("mode", "adaptive")
            combined = _merge_pair(pending_merge[1], record, mode, hardware)
            pending_merge = None
            output_record(writer, combined)
        elif source_index in merge_left:
            if pending_merge is not None:
                raise ValueError("overlapping merge waves")
            pending_merge = (source_index, record)
        else:
            flush_pending(writer)
            output_record(writer, record)

    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open("w") as writer:
        output_record(writer, header)
        for record in records:
            kind = record["record"]
            if kind in ("input", "alloc"):
                flush_pending(writer)
                if is_prefill:
                    score_sized = kind == "alloc" and record["len"] == shape["prefill"] ** 2
                    if not score_sized:
                        finish_score_run()
                    active.append(False)
                    if score_sized:
                        pending_score_run.append(len(active) - 1)
                    if scale is not None and kind == "alloc" and (
                            record["len"] == 3 * shape["prefill"] * shape["d"]):
                        qkv_pending.add(len(active) - 1)
                output_record(writer, record)
                continue
            if is_prefill:
                finish_score_run()
            if kind == "release":
                flush_pending(writer)
                if is_prefill:
                    if record["tensor"] != len(active) - 1:
                        raise ValueError("tensor stack changed")
                    active.pop()
                    qkv_pending.discard(record["tensor"])
                    qkv_written.discard(record["tensor"])
                    qkv_scaled.discard(record["tensor"])
                output_record(writer, record)
                continue
            if kind != "wave":
                flush_pending(writer)
                output_record(writer, record)
                continue
            source_wave += 1
            if scale is not None:
                for tensor in tuple(qkv_pending):
                    reads = _instruction_accesses(record, "load", tensor)
                    writes = _instruction_accesses(record, "store", tensor)
                    if reads and tensor not in qkv_scaled:
                        if tensor not in qkv_written or writes:
                            raise ValueError("QKV read overlaps incomplete producer")
                        flush_pending(writer)
                        output_record(writer, {"record": "wave", "groups":
                                      _q_scale_wave(shape, hardware, tensor, scale)})
                        qkv_scaled.add(tensor)
                        query_scale_waves += 1
                    if writes:
                        qkv_written.add(tensor)
            pair = _shared_transpose_pair(record) if transpose_tile is not None else None
            if pair is not None:
                flush_pending(writer)
                source_to_target[pair[0]] = pair[1]
                if pair not in transpose_emitted:
                    waves, _, _ = _shared_transpose_waves(
                        header, *pair, *transpose_tile)
                    for replacement in waves:
                        output_record(writer, replacement)
                    transpose_emitted.add(pair)
                continue
            groups = record["groups"]
            appended_k = (_appended_k_updates(record, source_to_target, header)
                          if transpose_tile is not None else [])
            if is_prefill:
                score_ids = {index for index, flag in enumerate(active) if flag}
                if _mask_wave(groups, score_ids, shape["prefill"]):
                    flush_pending(writer)
                    dropped_masks += 1
                    continue
                groups = [_localize_group(group, score_ids, shape["prefill"],
                          hardware["dma_engines"] * (1 + hardware["dma_depth"]))[0]
                          for group in groups]
                if scale is not None:
                    groups = [_scaled_group(group, scale)[0] for group in groups]
            if source_wave in single_k:
                groups = [_compact(group)[0] for group in groups]
            split_112 = source_wave in k112
            groups = [split_group(group, max_k, split_112)[0] for group in groups]
            if source_wave in balanced:
                groups = balance_wave(groups, hardware)
            batches = _pack_waves(groups, hardware)
            if source_wave in merge_left or source_wave in merge_right:
                if len(batches) != 1:
                    raise ValueError("selected merged wave partitions after K split")
            for batch in batches:
                emit_wave(writer, {"record": "wave", "groups": batch}, source_wave)
            if appended_k:
                flush_pending(writer)
                output_record(writer, _append_k_wave(appended_k, header, hardware))
                appended_k_waves += 1
        flush_pending(writer)
    if scale is not None and query_scale_waves != shape["layers"]:
        raise ValueError("not all QKV layers were scaled")
    if transpose_tile is not None and len(transpose_emitted) != shape["layers"]:
        raise ValueError("not all decode transposes were replaced")
    return {"source_sha256": sha(source), "program": str(destination),
            "program_sha256": sha(destination), "cycles": cycles,
            "source_waves": source_wave + 1, "output_waves": output_waves,
            "query_scale_waves": query_scale_waves,
            "appended_k_waves": appended_k_waves,
            "dropped_causal_mask_waves": dropped_masks}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("base_solution", type=Path)
    parser.add_argument("ksplit_screen", type=Path)
    parser.add_argument("screen_dir", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--cases", nargs="+", choices=tuple(SCORE_CASES))
    args = parser.parse_args()
    base = json.loads(args.base_solution.read_text())
    prior = json.loads(args.ksplit_screen.read_text())
    hardware = dict(prior["hardware"], sfu=27)
    choices = {name: json.loads((args.screen_dir / filename).read_text())["cases"]
               for name, filename in (
                   ("k112", "k112-tail-screen.json"),
                   ("single_k", "single-k-screen.json"),
                   ("balance", "balance-screen.json"),
                   ("merge", "merge-screen.json"),
                   ("prefill_merge", "prefill-merge-query-pipeline-screen.json"))}
    tiles = {"w-d1": (512, 8), "w-d16": (224, 16), "w-d4l": (512, 8)}
    output = args.output
    programs = output / "programs"
    programs.mkdir(parents=True, exist_ok=True)
    existing = output / "joint-screen.json"
    cases = json.loads(existing.read_text())["cases"] if existing.exists() else {}
    for case in (args.cases or SCORE_CASES):
        source = Path(base["selected_programs"][case]["program"])
        max_k = prior.get("case_max_k", {}).get(case, prior["max_k"])
        cases[case] = materialize_case(source, programs / f"{case}.jsonl", case,
                                       hardware, max_k, choices, tiles.get(case))
        print(case, cases[case]["cycles"], flush=True)
    score = (1000 * math.exp(sum(weight * math.log(reference / cases[case]["cycles"])
                                 for case, (reference, weight) in SCORE_CASES.items()))
             if set(cases) == set(SCORE_CASES) else None)
    result = {"hardware": hardware, "cases": cases,
              "conditional_predicted_score": score, "target_score": 5000,
              "meets_grade_gate": score is not None and score >= 5000,
              "numerical_correctness": "not_checked", "official_score": None}
    write(output / "joint-screen.json", result)
    print("score", score, flush=True)


if __name__ == "__main__":
    main()
