"""Materialize only SHA-gated causal AV choices from a full model screen."""

import argparse
import json
import subprocess
import sys
import tempfile
from pathlib import Path

from . import prefill_av_edge_k32_screen
from .estimate import estimate_program, estimate_wave, program_records, validate_wave_capacity
from .resident4_pack_materialize import _cross_sm_safe
from .resident4_pack_screen import _access_footprint
from .resident4_window_screen import independent
from .tool import STARTER, sha, write


def materialize(source, manifest_path, screen_path, output):
    source, manifest_path, screen_path, output = map(
        Path, (source, manifest_path, screen_path, output))
    manifest = json.loads(manifest_path.read_text())
    screen = json.loads(screen_path.read_text())
    case = screen["case"]
    if (case not in ("w-p", "a-p") or
            screen["source_sha256"] != sha(source) or
            screen["manifest_sha256"] != sha(manifest_path) or
            screen["model_sha256"] != sha(Path(prefill_av_edge_k32_screen.__file__)) or
            manifest["program_sha256"][case] != sha(source) or
            screen["five_case_model_score"] < 5000 or
            not screen["meets_grade_gate"] or screen["cycle_delta"] >= 0):
        raise ValueError("screen gate or immutable source identity failed")
    hardware = manifest["hardware"]
    choices = {row["source_start"]: row for row in screen["choices"]}
    if len(choices) != len(screen["choices"]):
        raise ValueError("duplicate selected wave")
    covered = set()
    for row in screen["choices"]:
        if row["source_waves"] not in (1, 2) or row["output_waves"] != 1:
            raise ValueError("unsupported selected window")
        indices = set(range(row["source_start"],
                            row["source_start"] + row["source_waves"]))
        if covered & indices:
            raise ValueError("overlapping selected windows")
        covered.update(indices)
    if len(covered) != screen["selected_source_waves"]:
        raise ValueError("selected wave count differs")

    output.mkdir(parents=True, exist_ok=False)
    target = output / f"{case}.jsonl"
    wave_index = selected_edges = merged_pairs = 0
    source_commands = output_commands = 0
    pending = None
    with tempfile.TemporaryDirectory(prefix="av-edge-") as temporary:
        expanded = Path(temporary) / "expanded.jsonl"
        with expanded.open("x") as writer:
            records = program_records(source)
            header = next(records)
            if header["hardware"] != hardware:
                raise ValueError("source hardware changed")
            context = header["shape"]["prefill"]
            writer.write(json.dumps(header, separators=(",", ":")) + "\n")
            for record in records:
                if record["record"] != "wave":
                    if pending is not None:
                        raise ValueError("selected pair crosses a non-wave record")
                    writer.write(json.dumps(record, separators=(",", ":")) + "\n")
                    continue
                source_commands += sum(len(group["commands"]) for group in record["groups"])
                if pending is not None:
                    start, prior, prior_changed, prior_edges, prior_base, choice = pending
                    if wave_index != start + 1:
                        raise ValueError("selected pair is not adjacent")
                    changed, edges = prefill_av_edge_k32_screen.retile_wave(
                        record, hardware, context)
                    if changed is None:
                        raise ValueError("selected second wave no longer matches")
                    current_base = estimate_wave(record["groups"], hardware)
                    entries = [(prior, prior_base, _access_footprint(prior), start),
                               (record, current_base, _access_footprint(record), wave_index)]
                    groups = prior_changed + changed
                    if not independent(entries) or not _cross_sm_safe(groups):
                        raise ValueError("selected pair has a cross-wave dependency")
                    validate_wave_capacity(groups, hardware)
                    cost = estimate_wave(groups, hardware)
                    if (choice["base"] != prior_base + current_base or
                            choice["cycles"] != cost or
                            choice["edges"] != prior_edges + edges):
                        raise ValueError("selected pair differs from model screen")
                    selected_edges += prior_edges + edges
                    merged_pairs += 1
                    pending = None
                else:
                    choice = choices.get(wave_index)
                    if choice is None:
                        groups = record["groups"]
                    else:
                        changed, edges = prefill_av_edge_k32_screen.retile_wave(
                            record, hardware, context)
                        if changed is None:
                            raise ValueError("selected wave no longer matches")
                        base = estimate_wave(record["groups"], hardware)
                        if choice["source_waves"] == 2:
                            pending = (wave_index, record, changed, edges, base, choice)
                            wave_index += 1
                            continue
                        cost = estimate_wave(changed, hardware)
                        if (choice["base"] != base or choice["cycles"] != cost or
                                choice["edges"] != edges):
                            raise ValueError("selected wave differs from model screen")
                        selected_edges += edges
                        groups = changed
                output_commands += sum(len(group["commands"]) for group in groups)
                writer.write(json.dumps({"record": "wave", "groups": groups},
                                        separators=(",", ":")) + "\n")
                wave_index += 1
        if (pending is not None or wave_index != screen["source_waves"] or
                selected_edges != screen["selected_edges"] or
                merged_pairs != screen["merged_wave_pairs"]):
            raise ValueError("candidate coverage differs from model screen")
        subprocess.run([sys.executable, str(STARTER / "tools/compact_program.py"),
                        str(expanded), str(target)], check=True)

    exact = estimate_program(target)["cycles"]
    if exact != screen["selected_cycles"]:
        raise ValueError("compact candidate differs from full model screen")
    result = {"case": case, "source_sha256": sha(source),
              "screen_sha256": sha(screen_path), "program_sha256": sha(target),
              "source_waves": wave_index, "merged_wave_pairs": merged_pairs,
              "selected_edges": selected_edges, "source_commands": source_commands,
              "output_commands": output_commands, "exact_model_cycles": exact,
              "five_case_model_score": screen["five_case_model_score"],
              "hardware": hardware, "grade_allowed": True,
              "official_score": None}
    write(output / "manifest.json", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("manifest", type=Path)
    parser.add_argument("screen", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    print(json.dumps(materialize(args.source, args.manifest,
                                 args.screen, args.output), indent=2), flush=True)


if __name__ == "__main__":
    main()
