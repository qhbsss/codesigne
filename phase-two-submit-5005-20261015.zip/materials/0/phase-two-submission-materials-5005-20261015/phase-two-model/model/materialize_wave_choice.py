"""Reprice a per-wave model choice, then materialize one case only past 5000."""

import argparse
import json
import math
import subprocess
import sys
import tempfile
from pathlib import Path

from .estimate import estimate_program, estimate_wave, program_records
from .joint_k_pipeline_screen import transformed
from .tool import SCORE_CASES, STARTER, sha, write


def price(source, checkpoint, case, hardware):
    rows = json.loads(Path(checkpoint).read_text())["cases"][case]
    records = program_records(source)
    next(records)
    cache = {}
    original = selected = waves = commits = 0
    for record in records:
        if record["record"] == "commit":
            original += 1
            selected += 1
            commits += 1
        elif record["record"] == "wave":
            groups = record["groups"]
            original += estimate_wave(groups, hardware, cache)
            option = rows[waves]["option"]
            if option != "base":
                groups = transformed(groups, option, hardware)
                if groups is None:
                    raise ValueError(f"option infeasible at wave {waves}")
            selected += estimate_wave(groups, hardware, cache)
            waves += 1
    if waves != len(rows):
        raise ValueError("checkpoint wave count mismatch")
    return {"source_sha256": sha(source), "checkpoint_sha256": sha(checkpoint),
            "case": case, "waves": waves, "original_cycles": original,
            "selected_cycles": selected,
            "no_fluid_selected_cycles": sum(row["cycles"] for row in rows) + commits}


def screen(source, checkpoint, base_manifest, case, output):
    base = json.loads(Path(base_manifest).read_text())
    hardware = base["hardware"]
    row = price(source, checkpoint, case, hardware)
    cycles = dict(base["exact_model_cycles"])
    cycles[case] = row["selected_cycles"]
    score = 1000 * math.exp(sum(weight * math.log(reference / cycles[name])
        for name, (reference, weight) in SCORE_CASES.items()))
    result = {**row, "source_manifest_sha256": sha(base_manifest),
              "five_case_model_cycles": cycles, "five_case_model_score": score,
              "meets_grade_gate": score >= 5000,
              "candidate_program_generated": False, "official_score": None}
    write(output, result)
    return result


def materialize(source, checkpoint, screen_path, output):
    row = json.loads(Path(screen_path).read_text())
    if (not row["meets_grade_gate"] or row["five_case_model_score"] < 5000 or
            row["source_sha256"] != sha(source) or
            row["checkpoint_sha256"] != sha(checkpoint)):
        raise ValueError("five-case model gate or source identity failed")
    case = row["case"]
    choices = json.loads(Path(checkpoint).read_text())["cases"][case]
    output = Path(output)
    output.mkdir(parents=True, exist_ok=False)
    destination = output / f"{case}.jsonl"
    with tempfile.TemporaryDirectory(prefix=f"wave-choice-{case}-") as temporary:
        expanded = Path(temporary) / "expanded.jsonl"
        records = program_records(source)
        header = next(records)
        wave_index = 0
        with expanded.open("x") as writer:
            writer.write(json.dumps(header, separators=(",", ":")) + "\n")
            for record in records:
                if record["record"] == "wave":
                    option = choices[wave_index]["option"]
                    wave_index += 1
                    if option != "base":
                        groups = transformed(record["groups"], option, header["hardware"])
                        if groups is None:
                            raise ValueError(f"option infeasible at wave {wave_index}")
                        record = {"record": "wave", "groups": groups}
                writer.write(json.dumps(record, separators=(",", ":")) + "\n")
        if wave_index != len(choices):
            raise ValueError("checkpoint wave count changed")
        subprocess.run([sys.executable, str(STARTER / "tools/compact_program.py"),
                        str(expanded), str(destination)], check=True)
    exact = estimate_program(destination)["cycles"]
    if exact != row["selected_cycles"]:
        raise ValueError("materialized model cycles differ from in-memory price")
    result = {"case": case, "source_sha256": row["source_sha256"],
              "checkpoint_sha256": row["checkpoint_sha256"],
              "screen_sha256": sha(screen_path), "program_sha256": sha(destination),
              "exact_model_cycles": exact,
              "five_case_model_score": row["five_case_model_score"],
              "grade_allowed": row["five_case_model_score"] >= 5000,
              "official_score": None}
    write(output / "manifest.json", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="mode", required=True)
    first = sub.add_parser("screen")
    first.add_argument("source", type=Path)
    first.add_argument("checkpoint", type=Path)
    first.add_argument("base_manifest", type=Path)
    first.add_argument("case")
    first.add_argument("output", type=Path)
    second = sub.add_parser("materialize")
    second.add_argument("source", type=Path)
    second.add_argument("checkpoint", type=Path)
    second.add_argument("screen", type=Path)
    second.add_argument("output", type=Path)
    args = parser.parse_args()
    if args.mode == "screen":
        result = screen(args.source, args.checkpoint, args.base_manifest,
                        args.case, args.output)
    else:
        result = materialize(args.source, args.checkpoint, args.screen, args.output)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
