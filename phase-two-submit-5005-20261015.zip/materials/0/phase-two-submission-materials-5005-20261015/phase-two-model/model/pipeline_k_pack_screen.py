"""Screen pipelined K retiling jointly with independent-wave packing."""

import argparse
import json
import math
from collections import deque
from pathlib import Path

from .estimate import estimate_wave, program_records
from .pipeline_k_retile import retile_group
from .resident4_pack_screen import _access_footprint, _pack
from .resident4_window_screen import choose, independent
from .tool import SCORE_CASES, sha, write


def screen(source, case, manifest_path, output, panel_k=48, max_window=6):
    source, manifest_path, output = map(Path, (source, manifest_path, output))
    output.parent.mkdir(parents=True, exist_ok=True)
    manifest = json.loads(manifest_path.read_text())
    if sha(source) != manifest["program_sha256"][case]:
        raise ValueError("program SHA changed")
    hardware = manifest["hardware"]
    records = program_records(source)
    if next(records)["hardware"] != hardware or hardware["tc_k_parallel"] != 1:
        raise ValueError("hardware mismatch or unsupported K order")
    cache = {}
    rows = []
    pending = deque()
    wave_index = commit_cycles = eligible_windows = changed_groups = 0

    def flush(force=False):
        nonlocal eligible_windows
        while pending and (force or len(pending) >= max_window):
            first = pending[0]
            choices = []
            for width in range(2, min(len(pending), max_window) + 1):
                entries = list(pending)[:width]
                if not any(entry[4] for entry in entries) or not independent(entries):
                    continue
                transformed = [{"groups": entry[3]} for entry in entries]
                packed = _pack(transformed, hardware)
                if len(packed) >= width:
                    continue
                eligible_windows += 1
                cycles = sum(estimate_wave(groups, hardware, cache) for groups in packed)
                base = sum(entry[1] for entry in entries)
                if cycles < base:
                    choices.append({"source_waves": width, "packed_waves": len(packed),
                                    "cycles": cycles, "base": base, "panel_k": panel_k,
                                    "retiled_groups": sum(entry[4] for entry in entries)})
            rows.append({"base": first[1], "options": choices})
            pending.popleft()
            if len(rows) % 32 == 0:
                write(output.with_name("progress.json"),
                      {"case": case, "source_sha256": sha(source),
                       "screened_waves": len(rows), "eligible_windows": eligible_windows,
                       "beneficial_options": sum(len(row["options"]) for row in rows),
                       "retiled_groups_seen": changed_groups})
                print(case, "screened", len(rows), "eligible", eligible_windows,
                      "beneficial", sum(len(row["options"]) for row in rows), flush=True)

    for record in records:
        if record.get("record") != "wave":
            flush(force=True)
            if record.get("record") == "commit":
                commit_cycles += 1
            continue
        transformed = []
        count = 0
        for group in record["groups"]:
            new, tiles = retile_group(group, panel_k)
            transformed.append(new)
            count += tiles > 0
        changed_groups += count
        pending.append((record, estimate_wave(record["groups"], hardware, cache),
                        _access_footprint(record), transformed, count, wave_index))
        wave_index += 1
        flush()
    flush(force=True)
    baseline = commit_cycles + sum(row["base"] for row in rows)
    if len(rows) != wave_index or baseline != manifest["model_cycles"][case]:
        raise ValueError("source differs from complete model baseline")
    selected, wave_cycles = choose(rows)
    cycles = dict(manifest["model_cycles"])
    cycles[case] = commit_cycles + wave_cycles
    score = 1000 * math.exp(sum(weight * math.log(reference / cycles[name])
                              for name, (reference, weight) in SCORE_CASES.items()))
    result = {"case": case, "source_sha256": sha(source),
              "manifest_sha256": sha(manifest_path), "panel_k": panel_k,
              "max_window": max_window, "source_waves": wave_index,
              "packed_waves": sum(row["packed_waves"] for row in selected),
              "retiled_groups_seen": changed_groups,
              "eligible_windows": eligible_windows,
              "beneficial_options": sum(len(row["options"]) for row in rows),
              "chosen": [row for row in selected if row["source_waves"] > 1],
              "base_cycles": baseline, "selected_cycles": cycles[case],
              "cycle_delta": cycles[case] - baseline,
              "five_case_model_cycles": cycles, "five_case_model_score": score,
              "meets_grade_gate": score >= 5000,
              "candidate_program_generated": False, "official_score": None}
    write(output, result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("case")
    parser.add_argument("manifest", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--panel-k", type=int, default=48)
    parser.add_argument("--max-window", type=int, default=6)
    args = parser.parse_args()
    result = screen(args.source, args.case, args.manifest, args.output,
                    args.panel_k, args.max_window)
    print(json.dumps({key: result[key] for key in ("case", "source_waves", "packed_waves",
                                                   "retiled_groups_seen", "eligible_windows",
                                                   "beneficial_options", "cycle_delta",
                                                   "five_case_model_score")}, indent=2))


if __name__ == "__main__":
    main()
