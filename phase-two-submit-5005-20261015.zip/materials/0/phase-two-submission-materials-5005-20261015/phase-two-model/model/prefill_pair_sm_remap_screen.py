"""Price load-balancing SM permutations of already resident paired waves."""

import argparse
import json
import math
from pathlib import Path

from .estimate import estimate_wave, program_records, validate_wave_capacity
from .resident4_pack_materialize import _cross_sm_safe
from .tool import SCORE_CASES, sha, write


def mappings(groups):
    yield "half_reverse", [3, 2, 1, 0, 7, 6, 5, 4]
    yield "full_reverse", list(range(7, -1, -1))
    for step in range(1, 8):
        yield f"rotate_{step}", [(index + step) % 8 for index in range(8)]
    for step in range(1, 4):
        yield f"half_rotate_{step}", [4 * (index // 4) +
                                     (index % 4 + step) % 4 for index in range(8)]
    first = sorted(range(8), key=lambda index: len(groups[index]["commands"]))
    second = sorted(range(8), key=lambda index: len(groups[8 + index]["commands"]),
                    reverse=True)
    assignment = [0] * 8
    for sm, index in zip(first, second):
        assignment[index] = sm
    if assignment != list(range(8)):
        yield "command_balance", assignment


def remap(groups, mapping):
    return groups[:8] + [dict(group, sm=mapping[index])
                         for index, group in enumerate(groups[8:])]


def eligible(groups):
    return (len(groups) == 16 and all(group["rf_kib"] == 32 and
                                      group["sh_kib"] == 0 for group in groups) and
            [group["sm"] for group in groups[:8]] == list(range(8)) and
            [group["sm"] for group in groups[8:]] == list(range(8)))


def screen(source, manifest_path, case, output, only_mapping=None):
    source, manifest_path, output = map(Path, (source, manifest_path, output))
    manifest = json.loads(manifest_path.read_text())
    if case not in ("w-p", "a-p") or sha(source) != manifest["program_sha256"][case]:
        raise ValueError("case or source SHA differs from five-case manifest")
    records = program_records(source)
    header = next(records)
    hardware = manifest["hardware"]
    if header["hardware"] != hardware:
        raise ValueError("hardware differs from five-case manifest")
    cache = {}
    choices = []
    waves = candidates = tested = saved = 0
    for record in records:
        if record["record"] != "wave":
            continue
        groups = record["groups"]
        if eligible(groups):
            candidates += 1
            original = estimate_wave(groups, hardware, cache)
            best = None
            for name, mapping in mappings(groups):
                if only_mapping is not None and name != only_mapping:
                    continue
                if mapping == list(range(8)):
                    continue
                changed = remap(groups, mapping)
                validate_wave_capacity(changed, hardware)
                cost = estimate_wave(changed, hardware, cache)
                tested += 1
                if (cost < (best["cycles"] if best else original) and
                        _cross_sm_safe(changed)):
                    best = {"wave": waves, "mapping_name": name,
                            "mapping": mapping, "base": original,
                            "cycles": cost}
            if best is not None:
                choices.append(best)
                saved += original - best["cycles"]
            if candidates % 8 == 0:
                print(case, "candidates", candidates, "selected", len(choices),
                      "saved", saved, flush=True)
        waves += 1
    cycles = dict(manifest["model_cycles"])
    cycles[case] -= saved
    score = 1000 * math.exp(sum(weight * math.log(reference / cycles[name])
                                for name, (reference, weight) in SCORE_CASES.items()))
    result = {"case": case, "source_sha256": sha(source),
              "manifest_sha256": sha(manifest_path), "model_sha256": sha(Path(__file__)),
              "only_mapping": only_mapping,
              "source_waves": waves, "candidate_waves": candidates,
              "tested_mappings": tested, "selected_waves": len(choices),
              "choices": choices, "base_cycles": manifest["model_cycles"][case],
              "selected_cycles": cycles[case], "cycle_delta": -saved,
              "five_case_model_cycles": cycles, "five_case_model_score": score,
              "meets_grade_gate": score >= 5000,
              "candidate_program_generated": False, "official_score": None}
    output.parent.mkdir(parents=True, exist_ok=True)
    write(output, result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("manifest", type=Path)
    parser.add_argument("case", choices=("w-p", "a-p"))
    parser.add_argument("output", type=Path)
    parser.add_argument("--mapping", choices=("half_reverse", "full_reverse",
                                              "command_balance"))
    args = parser.parse_args()
    result = screen(args.source, args.manifest, args.case, args.output,
                    only_mapping=args.mapping)
    print(json.dumps({key: result[key] for key in
                      ("case", "candidate_waves", "tested_mappings",
                       "selected_waves", "cycle_delta", "five_case_model_score")},
                     indent=2), flush=True)


if __name__ == "__main__":
    main()
