"""Screen initial K transpose tiles against an already padded decode layout."""

import argparse
import json
import math
import subprocess
import sys
import tempfile
from pathlib import Path

from .direct_k import _shared_transpose_waves
from .estimate import estimate_program, estimate_wave, program_records, validate_wave_capacity
from .tool import SCORE_CASES, STARTER, sha, write


OPTIONS = ((192, 32), (256, 24), (256, 16), (320, 16), (384, 16),
           (384, 12), (448, 12), (512, 8))


def transpose_pair(record, tensors, header):
    if record["record"] != "wave":
        return None
    operations = set()
    loads = set()
    stores = set()
    pitches = set()
    for group in record["groups"]:
        for command in group["commands"]:
            instruction = command.get("instruction")
            if instruction is None:
                continue
            operation = instruction["op"]
            operations.add(operation)
            if operation == "load_shared":
                loads.add(instruction["tensor"])
            elif operation == "store_shared":
                stores.add(instruction["tensor"])
                pitches.add(instruction["global"]["row_stride"])
    if operations != {"load_shared", "store_shared"} or len(loads) != 1 or len(stores) != 1 or len(pitches) != 1:
        return None
    source, target, pitch = next(iter(loads)), next(iter(stores)), next(iter(pitches))
    if (source >= len(tensors) or target >= len(tensors) or
            tensors[source]["kind"] != "input" or
            not str(tensors[source]["source"]).endswith("past_k") or
            tensors[target]["kind"] != "alloc" or
            tensors[target]["len"] != header["batch"] * header["shape"]["d"] * pitch):
        return None
    return source, target, pitch


def _records(source):
    records = program_records(source)
    header = next(records)
    tensors = []
    for record in records:
        kind = record["record"]
        if kind in ("input", "alloc"):
            tensors.append({"kind": kind, "source": record.get("source"), "len": record["len"]})
        elif kind == "release":
            if record["tensor"] != len(tensors) - 1:
                raise ValueError("non-stack tensor release")
            tensors.pop()
        yield header, record, transpose_pair(record, tensors, header)


def screen(source, base_manifest, case, output, options=OPTIONS):
    source, base_manifest, output = map(Path, (source, base_manifest, output))
    base = json.loads(base_manifest.read_text())
    records = program_records(source)
    header = next(records)
    hardware = header["hardware"]
    if (case not in ("w-d1", "w-d16", "w-d4l") or not header["decode"] or
            hardware != base["hardware"] or sha(source) != base["program_sha256"][case]):
        raise ValueError("source, case or shared hardware identity changed")
    cache = {}
    pairs = {}
    original_cycles = original_waves = 0
    for _, record, pair in _records(source):
        if pair is None:
            continue
        original_cycles += estimate_wave(record["groups"], hardware, cache)
        original_waves += 1
        pairs[pair] = pairs.get(pair, 0) + 1
    if len(pairs) != header["shape"]["layers"]:
        raise ValueError("initial K transpose pair count differs from layer count")
    rows = []
    for feature_tile, context_tile in options:
        replacement_cycles = replacement_waves = tasks = 0
        try:
            for source_id, target_id, pitch in pairs:
                waves, pair_tasks, sh_kib = _shared_transpose_waves(
                    header, source_id, target_id, feature_tile, context_tile,
                    output_stride=pitch)
                for wave in waves:
                    validate_wave_capacity(wave["groups"], hardware)
                    replacement_cycles += estimate_wave(wave["groups"], hardware, cache)
                replacement_waves += len(waves)
                tasks += pair_tasks
            cycles = dict(base["exact_model_cycles"])
            cycles[case] += replacement_cycles - original_cycles
            score = 1000 * math.exp(sum(weight * math.log(reference / cycles[name])
                for name, (reference, weight) in SCORE_CASES.items()))
            rows.append({"feature_tile": feature_tile, "context_tile": context_tile,
                         "group_sh_kib": sh_kib, "tasks": tasks,
                         "replacement_waves": replacement_waves,
                         "replacement_cycles": replacement_cycles,
                         "five_case_model_cycles": cycles,
                         "five_case_model_score": score,
                         "meets_grade_gate": score >= 5000})
        except ValueError as error:
            rows.append({"feature_tile": feature_tile, "context_tile": context_tile,
                         "infeasible": str(error)})
        write(output, {"case": case, "source_sha256": sha(source),
                       "base_manifest_sha256": sha(base_manifest),
                       "estimator_sha256": sha(Path(__file__).with_name("estimate.py")),
                       "generator_sha256": sha(Path(__file__).with_name("direct_k.py")),
                       "screen_code_sha256": sha(__file__),
                       "pairs": len(pairs), "original_waves": original_waves,
                       "original_affected_cycles": original_cycles,
                       "options": rows, "candidate_program_generated": False,
                       "official_score": None})
        print(feature_tile, context_tile, rows[-1].get("replacement_cycles"),
              rows[-1].get("five_case_model_score"), flush=True)
    return rows


def materialize(source, screen_path, feature_tile, context_tile, output):
    source, screen_path, output = map(Path, (source, screen_path, output))
    screen_result = json.loads(screen_path.read_text())
    row, = [item for item in screen_result["options"]
            if item["feature_tile"] == feature_tile and item["context_tile"] == context_tile]
    if (not row.get("meets_grade_gate") or row["five_case_model_score"] < 5000 or
            screen_result["source_sha256"] != sha(source) or
            screen_result["screen_code_sha256"] != sha(__file__) or
            screen_result["generator_sha256"] != sha(Path(__file__).with_name("direct_k.py")) or
            screen_result["estimator_sha256"] != sha(Path(__file__).with_name("estimate.py"))):
        raise ValueError("five-case model gate or source identity failed")
    output.mkdir(parents=True, exist_ok=False)
    destination = output / f"{screen_result['case']}.jsonl"
    with tempfile.TemporaryDirectory(prefix="padded-k-transpose-") as temporary:
        expanded = Path(temporary) / "expanded.jsonl"
        emitted = set()
        records = program_records(source)
        header = next(records)
        with expanded.open("x") as writer:
            writer.write(json.dumps(header, separators=(",", ":")) + "\n")
            for _, record, pair in _records(source):
                if pair is None:
                    writer.write(json.dumps(record, separators=(",", ":")) + "\n")
                elif pair not in emitted:
                    emitted.add(pair)
                    waves, _, _ = _shared_transpose_waves(
                        header, *pair[:2], feature_tile, context_tile,
                        output_stride=pair[2])
                    for wave in waves:
                        writer.write(json.dumps(wave, separators=(",", ":")) + "\n")
        if len(emitted) != screen_result["pairs"]:
            raise ValueError("padded K transpose pair count changed")
        subprocess.run([sys.executable, str(STARTER / "tools/compact_program.py"),
                        str(expanded), str(destination)], check=True)
    exact = estimate_program(destination)["cycles"]
    if exact != row["five_case_model_cycles"][screen_result["case"]]:
        raise ValueError("materialized model cycles differ from in-memory screen")
    result = {"case": screen_result["case"], "source_sha256": sha(source),
              "program_sha256": sha(destination), "screen_sha256": sha(screen_path),
              "feature_tile": feature_tile, "context_tile": context_tile,
              "exact_model_cycles": exact,
              "five_case_model_score": row["five_case_model_score"],
              "grade_allowed": True, "official_score": None}
    write(output / "manifest.json", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="mode", required=True)
    first = sub.add_parser("screen")
    first.add_argument("source", type=Path)
    first.add_argument("base_manifest", type=Path)
    first.add_argument("case")
    first.add_argument("output", type=Path)
    second = sub.add_parser("materialize")
    second.add_argument("source", type=Path)
    second.add_argument("screen", type=Path)
    second.add_argument("feature_tile", type=int)
    second.add_argument("context_tile", type=int)
    second.add_argument("output", type=Path)
    args = parser.parse_args()
    if args.mode == "screen":
        print(json.dumps(screen(args.source, args.base_manifest, args.case, args.output)[-1], indent=2))
    else:
        print(json.dumps(materialize(args.source, args.screen, args.feature_tile,
                                     args.context_tile, args.output), indent=2))


if __name__ == "__main__":
    main()
