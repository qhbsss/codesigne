"""Screen a 64-row, 32-K prefill GEMM tile while keeping RF residency.

This module only constructs wave alternatives in memory.  It pairs adjacent
32-row output tiles, retains their fused epilogues, and prices the resulting
paid commands with the common five-case independent model.  It emits a small
screen receipt; no candidate program is written.
"""

import argparse
import copy
import json
import math
from collections import defaultdict
from pathlib import Path

from .estimate import estimate_wave, program_records, validate_wave_capacity
from .reuse_b_within import _renumber
from .tool import SCORE_CASES, sha, write


def _instruction(command):
    return command.get("instruction", {})


def _segments(group):
    if group["rf_kib"] != 32 or group["sh_kib"]:
        return None
    parts = []
    pending = []
    for command in group["commands"]:
        pending.append(command)
        if _instruction(command).get("op") == "store":
            parts.append(pending)
            pending = []
    if pending or not parts:
        return None
    return parts


def _tile(segment):
    if (_instruction(segment[0]).get("op") != "fill" or
            _instruction(segment[-1]).get("op") != "store"):
        return None
    fill, store = _instruction(segment[0]), _instruction(segment[-1])
    gv, lv = store["global"], store["local"]
    if (fill.get("dst") != 0 or fill.get("len") != 2048 or
            gv["rows"] != 32 or gv["cols"] != 64 or
            gv["col_stride"] != 1 or gv["row_stride"] < 64 or
            lv != {"base": 0, "rows": 32, "cols": 64,
                   "row_stride": 64, "col_stride": 1}):
        return None
    chunks = []
    cursor = 1
    while cursor + 4 < len(segment):
        commands = segment[cursor:cursor + 5]
        if [item["command"] for item in commands] != [
                "async", "async", "async", "wait", "run"]:
            break
        a, b0, b1, wait, mma = commands
        ai, low, high, mi = map(_instruction, (a, b0, b1, mma))
        if ([ai.get("op"), low.get("op"), high.get("op"), mi.get("op")] !=
                ["load", "load", "load", "mma"] or
                wait["tokens"] != [a["token"], b0["token"], b1["token"]] or
                (mi["m"], mi["n"], mi["k"], mi["a"], mi["b"], mi["c"]) !=
                (32, 64, 64, 2048, 4096, 0)):
            return None
        av, al = ai["global"], ai["local"]
        if (av["rows"] != 32 or av["cols"] != 64 or av["col_stride"] != 1 or
                al != {"base": 2048, "rows": 32, "cols": 64,
                       "row_stride": 64, "col_stride": 1}):
            return None
        for offset, panel in ((0, low), (2048, high)):
            pv, pl = panel["global"], panel["local"]
            if (pv["rows"] != 32 or pv["cols"] != 64 or pv["col_stride"] != 1 or
                    pl != {"base": 4096 + offset, "rows": 32, "cols": 64,
                           "row_stride": 64, "col_stride": 1}):
                return None
        if (low["tensor"] != high["tensor"] or
                high["global"]["base"] !=
                low["global"]["base"] + 32 * low["global"]["row_stride"] or
                high["global"]["row_stride"] != low["global"]["row_stride"]):
            return None
        chunks.append((a, b0, b1))
        cursor += 5
    if not chunks:
        return None
    epilogue = segment[cursor:-1]
    if not epilogue or any(command["command"] != "run" or
                           _instruction(command).get("op") not in ("load", "vector")
                           for command in epilogue):
        return None
    # Epilogue scratch lives above both output halves after retile.
    for command in epilogue:
        instruction = _instruction(command)
        if instruction["op"] == "load":
            local = instruction["local"]
            if (local["base"] < 6144 or
                    local["base"] + (local["rows"] - 1) * local["row_stride"] +
                    local["cols"] > 8192):
                return None
        else:
            locations = [instruction["dst"]]
            locations += [argument["base"] for argument in
                          (instruction["a"], instruction["b"])
                          if argument["kind"] == "reg"]
            if any(2048 <= base < 6144 or base >= 8192 for base in locations):
                return None
    return {"fill": fill, "store": store, "chunks": chunks,
            "epilogue": epilogue, "source": segment}


def _pair_key(tile):
    view = tile["store"]["global"]
    row, col = divmod(view["base"], view["row_stride"])
    if row % 64 not in (0, 32):
        return None
    return tile["store"]["tensor"], view["row_stride"], row // 64, col


def _compatible(low, high):
    a, b = low["store"], high["store"]
    if (a["tensor"] != b["tensor"] or
            a["global"]["row_stride"] != b["global"]["row_stride"] or
            b["global"]["base"] != a["global"]["base"] +
            32 * a["global"]["row_stride"] or
            len(low["chunks"]) != len(high["chunks"])):
        return False
    for one, two in zip(low["chunks"], high["chunks"]):
        la, l0, l1 = map(_instruction, one)
        ha, h0, h1 = map(_instruction, two)
        if (la["tensor"] != ha["tensor"] or
                ha["global"]["base"] != la["global"]["base"] +
                32 * la["global"]["row_stride"] or
                ha["global"]["row_stride"] != la["global"]["row_stride"] or
                l0["tensor"] != h0["tensor"] or
                l0["global"] != h0["global"] or l1["global"] != h1["global"]):
            return False
    return True


def _move_epilogue(command, output_offset):
    rewritten = copy.deepcopy(command)
    instruction = rewritten["instruction"]
    if instruction["op"] == "vector":
        if instruction["dst"] < 2048:
            instruction["dst"] += output_offset
        for operand in (instruction["a"], instruction["b"]):
            if operand["kind"] == "reg" and operand["base"] < 2048:
                operand["base"] += output_offset
    return rewritten


def _retile_pair(low, high):
    commands = [{"command": "run", "instruction":
                 {"op": "fill", "dst": 0, "len": 4096,
                  "value": low["fill"]["value"]}}]
    token = 0
    for one in low["chunks"]:
        source_a = _instruction(one[0])
        for half, original_b in enumerate(one[1:]):
            token += 1
            activation = copy.deepcopy(source_a)
            activation["global"] = dict(source_a["global"],
                                        base=source_a["global"]["base"] + half * 32,
                                        rows=64, cols=32)
            activation["local"] = {"base": 4096, "rows": 64, "cols": 32,
                                   "row_stride": 32, "col_stride": 1}
            commands.append({"command": "async", "token": token,
                             "instruction": activation})
            a_token = token
            token += 1
            panel = copy.deepcopy(_instruction(original_b))
            panel["local"] = {"base": 6144, "rows": 32, "cols": 64,
                              "row_stride": 64, "col_stride": 1}
            commands.append({"command": "async", "token": token,
                             "instruction": panel})
            commands.append({"command": "wait", "tokens": [a_token, token]})
            commands.append({"command": "run", "instruction": {
                "op": "mma", "a": 4096, "b": 6144, "c": 0,
                "m": 64, "n": 64, "k": 32}})
    for offset, tile in ((0, low), (2048, high)):
        commands.extend(_move_epilogue(command, offset)
                        for command in tile["epilogue"])
    store = copy.deepcopy(low["store"])
    store["global"]["rows"] = 64
    store["local"]["rows"] = 64
    commands.append({"command": "run", "instruction": store})
    return commands


def _wave_option(groups, hardware, mapping):
    if len(groups) != 16 or any(group["sh_kib"] for group in groups):
        return None
    by_key = defaultdict(dict)
    output_tensors = set()
    input_tensors = set()
    original_segments = 0
    for group in groups:
        parts = _segments(group)
        if parts is None:
            return None
        for part in parts:
            tile = _tile(part)
            if tile is None:
                return None
            key = _pair_key(tile)
            if key is None:
                return None
            row = tile["store"]["global"]["base"] // key[1]
            side = row % 64
            if side in by_key[key]:
                return None
            by_key[key][side] = tile
            original_segments += 1
            output_tensors.add(tile["store"]["tensor"])
            input_tensors.update(_instruction(command)["tensor"]
                                 for command in part
                                 if _instruction(command).get("op") == "load")
    if output_tensors & input_tensors:
        return None
    pairs = []
    singles = []
    for key, sides in by_key.items():
        if set(sides) == {0, 32} and _compatible(sides[0], sides[32]):
            pairs.append((key, sides[0], sides[32]))
        else:
            singles.extend((key, side, tile) for side, tile in sides.items())
    pairs.sort(key=lambda row: row[0])
    singles.sort(key=lambda row: (row[0], row[1]))
    if not pairs:
        return None
    # Distribute equal numbers of independent tiles to two 32-KiB groups/SM.
    slots = [[] for _ in range(16)]
    tasks = [_retile_pair(low, high) for _, low, high in pairs]
    tasks.extend(copy.deepcopy(tile["source"]) for _, _, tile in singles)
    for index, commands in enumerate(tasks):
        target = (index % 16 if mapping == "round_robin" else
                  min(index // math.ceil(len(tasks) / 16), 15))
        slots[target].extend(commands)
    rewritten = [{"sm": index % 8, "rf_kib": 32, "sh_kib": 0,
                  "commands": _renumber(commands)}
                 for index, commands in enumerate(slots) if commands]
    validate_wave_capacity(rewritten, hardware)
    return rewritten, len(pairs), original_segments, len(singles)


def screen(source, manifest_path, case, output):
    source, manifest_path, output = map(Path, (source, manifest_path, output))
    manifest = json.loads(manifest_path.read_text())
    expected = manifest["program_sha256"][case]
    if sha(source) != expected:
        raise ValueError("source SHA differs from full model manifest")
    records = program_records(source)
    hardware = next(records)["hardware"]
    if hardware != manifest["hardware"]:
        raise ValueError("hardware differs from full model manifest")
    cache = {}
    waves = eligible = beneficial = output_pairs = original_tiles = 0
    baseline = replacement = commits = 0
    choices = []
    for record in records:
        kind = record["record"]
        if kind == "commit":
            commits += 1
        if kind != "wave":
            continue
        original = estimate_wave(record["groups"], hardware, cache)
        baseline += original
        selected = {"wave": waves, "mode": "base", "base": original,
                    "cycles": original, "pairs": 0}
        for mapping in ("round_robin", "block"):
            option = _wave_option(record["groups"], hardware, mapping)
            if option is None:
                continue
            groups, pairs, tiles, singles = option
            if mapping == "round_robin":
                eligible += 1
                output_pairs += pairs
                original_tiles += tiles
            cycles = estimate_wave(groups, hardware, cache)
            if cycles < selected["cycles"]:
                selected = {"wave": waves, "mode": mapping, "base": original,
                            "cycles": cycles, "pairs": pairs, "singles": singles}
        beneficial += selected["mode"] != "base"
        replacement += selected["cycles"]
        if selected["mode"] != "base":
            choices.append(selected)
        waves += 1
        if waves % 8 == 0:
            print(case, "screened", waves, "eligible", eligible,
                  "beneficial", beneficial, flush=True)
    baseline += commits
    replacement += commits
    if baseline != manifest["model_cycles"][case]:
        raise ValueError(f"source model baseline differs: {baseline}")
    cycles = dict(manifest["model_cycles"])
    cycles[case] = replacement
    score = 1000 * math.exp(sum(weight * math.log(reference / cycles[name])
                                for name, (reference, weight) in SCORE_CASES.items()))
    result = {"case": case, "source_sha256": expected,
              "manifest_sha256": sha(manifest_path),
              "model_sha256": sha(Path(__file__)),
              "hardware": hardware, "source_waves": waves,
              "eligible_waves": eligible, "beneficial_waves": beneficial,
              "original_tiles_in_eligible_waves": original_tiles,
              "paired_tiles_in_eligible_waves": output_pairs,
              "base_cycles": baseline, "selected_cycles": replacement,
              "cycle_delta": replacement - baseline, "choices": choices,
              "five_case_model_cycles": cycles,
              "five_case_model_score": score, "meets_grade_gate": score >= 5000,
              "candidate_program_generated": False, "official_score": None}
    output.parent.mkdir(parents=True, exist_ok=True)
    write(output, result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("manifest", type=Path)
    parser.add_argument("case", choices=("w-p", "a-p"))
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    result = screen(args.source, args.manifest, args.case, args.output)
    print(json.dumps({key: result[key] for key in
                      ("case", "eligible_waves", "beneficial_waves", "cycle_delta",
                       "five_case_model_score")}, indent=2), flush=True)


if __name__ == "__main__":
    main()
