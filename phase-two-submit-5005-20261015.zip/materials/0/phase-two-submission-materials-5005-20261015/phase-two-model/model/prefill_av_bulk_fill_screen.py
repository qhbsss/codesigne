"""Screen one RF zero fill per AV panel on an already retiled prefill program."""

import argparse
import json
import math
from pathlib import Path

from .estimate import estimate_wave, program_records, validate_wave_capacity
from .tool import SCORE_CASES, sha, write


def bulk_group(group):
    if group["rf_kib"] != 32 or group["sh_kib"]:
        return None, 0
    output = []
    segment = []
    changed = 0
    for command in group["commands"]:
        segment.append(command)
        if command.get("instruction", {}).get("op") != "store":
            continue
        mma_indices = [index for index, item in enumerate(segment[:-1])
                       if item.get("instruction", {}).get("op") == "mma"]
        if not mma_indices or mma_indices[-1] != len(segment) - 2:
            return None, 0
        final = mma_indices[-1]
        mma = segment[final]["instruction"]
        k = mma.get("k")
        if (k not in (32, 64) or mma !=
                {"op": "mma", "a": 2048, "b": 4096, "c": 0,
                 "m": 32, "n": 64, "k": k}):
            return None, 0
        stage_start = mma_indices[-2] + 1 if len(mma_indices) > 1 else 1
        fill_start = final
        while (fill_start > stage_start and
               segment[fill_start - 1].get("instruction", {}).get("op") == "fill"):
            fill_start -= 1
        fills = segment[fill_start:final]
        stage = segment[stage_start:fill_start]
        scores = {}
        values = []
        for item in stage:
            instruction = item.get("instruction", {})
            if instruction.get("op") != "load":
                continue
            local = instruction["local"]
            base = local["base"]
            if base == 4096:
                values.append(instruction)
            elif 2048 <= base < 2048 + 32 * k:
                row, offset = divmod(base - 2048, k)
                if offset or row in scores or local["rows"] != 1:
                    return None, 0
                scores[row] = instruction
            else:
                return None, 0
        if (len(fills) != 31 or len(scores) != 32 or len(values) != 1 or
                values[0]["local"] != {"base": 4096, "rows": k, "cols": 64,
                                       "row_stride": 64, "col_stride": 1}):
            return None, 0
        expected_fills = []
        for row in range(32):
            local = scores[row]["local"]
            valid = local["cols"]
            if (local != {"base": 2048 + row * k, "rows": 1,
                          "cols": valid, "row_stride": valid, "col_stride": 1} or
                    not 1 <= valid <= k):
                return None, 0
            if valid < k:
                expected_fills.append({"command": "run", "instruction":
                                       {"op": "fill", "dst": 2048 + row * k + valid,
                                        "len": k - valid, "value": 0.0}})
        if fills != expected_fills:
            return None, 0
        bulk = {"command": "run", "instruction":
                {"op": "fill", "dst": 2048, "len": 32 * k, "value": 0.0}}
        output.extend(segment[:stage_start] + [bulk] + stage + segment[final:])
        changed += 1
        segment = []
    if segment or not changed:
        return None, 0
    return dict(group, commands=output), changed


def bulk_wave(groups, hardware):
    result = []
    panels = 0
    for group in groups:
        rewritten, count = bulk_group(group)
        if rewritten is None:
            return None, 0
        result.append(rewritten)
        panels += count
    validate_wave_capacity(result, hardware)
    return result, panels


def screen(source, manifest_path, case, output):
    source, manifest_path, output = map(Path, (source, manifest_path, output))
    manifest = json.loads(manifest_path.read_text())
    if case not in ("w-p", "a-p") or sha(source) != manifest["program_sha256"][case]:
        raise ValueError("case or source SHA differs from five-case manifest")
    records = program_records(source)
    header = next(records)
    hardware = manifest["hardware"]
    if header["hardware"] != hardware:
        raise ValueError("hardware differs from five-case manifest")
    cache = {}
    choices = []
    waves = eligible = panels = selected_panels = saved = 0
    for record in records:
        if record["record"] != "wave":
            continue
        changed, count = bulk_wave(record["groups"], hardware)
        if changed is not None:
            eligible += 1
            panels += count
            old = estimate_wave(record["groups"], hardware, cache)
            new = estimate_wave(changed, hardware, cache)
            if new < old:
                choices.append({"wave": waves, "panels": count,
                                "base": old, "cycles": new})
                selected_panels += count
                saved += old - new
        waves += 1
    cycles = dict(manifest["model_cycles"])
    cycles[case] -= saved
    score = 1000 * math.exp(sum(weight * math.log(reference / cycles[name])
                                for name, (reference, weight) in SCORE_CASES.items()))
    result = {"case": case, "source_sha256": sha(source),
              "manifest_sha256": sha(manifest_path), "model_sha256": sha(Path(__file__)),
              "source_waves": waves, "eligible_waves": eligible,
              "eligible_panels": panels, "selected_panels": selected_panels,
              "choices": choices, "base_cycles": manifest["model_cycles"][case],
              "selected_cycles": cycles[case], "cycle_delta": -saved,
              "five_case_model_cycles": cycles, "five_case_model_score": score,
              "meets_grade_gate": score >= 5000,
              "candidate_program_generated": False, "official_score": None}
    output.parent.mkdir(parents=True, exist_ok=True)
    write(output, result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("manifest", type=Path)
    parser.add_argument("case", choices=("w-p", "a-p"))
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    result = screen(args.source, args.manifest, args.case, args.output)
    print(json.dumps({key: result[key] for key in
                      ("case", "eligible_waves", "eligible_panels", "selected_panels",
                       "cycle_delta", "five_case_model_score")}, indent=2), flush=True)


if __name__ == "__main__":
    main()
