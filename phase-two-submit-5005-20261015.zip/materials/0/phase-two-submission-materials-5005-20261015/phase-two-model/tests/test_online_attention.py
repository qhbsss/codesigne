import unittest

from model.online_attention import _online_group


class OnlineAttentionTests(unittest.TestCase):
    def test_key_layout_is_paid_and_matches_tensor_storage(self):
        for layout, expected in (("strided", (1, 16, 8)),
                                 ("transposed", (128, 1, 1024))):
            with self.subTest(layout=layout):
                group = _online_group(8, 8, 128, 1, 16, 8, 16,
                                      16, 12, 13, 17, layout, 1)
                loads = [command["instruction"] for command in group["commands"]
                         if command.get("instruction", {}).get("op") == "load"]
                self.assertEqual(len(loads), 3)
                view = loads[1]["global"]
                self.assertEqual((view["row_stride"], view["col_stride"], view["base"]),
                                 expected)
                stores = [command["instruction"] for command in group["commands"]
                          if command.get("instruction", {}).get("op") == "store"]
                self.assertEqual(len(stores), 1)
                self.assertEqual(stores[0]["tensor"], 17)
                self.assertLessEqual(group["rf_kib"], 128)


if __name__ == "__main__":
    unittest.main()
