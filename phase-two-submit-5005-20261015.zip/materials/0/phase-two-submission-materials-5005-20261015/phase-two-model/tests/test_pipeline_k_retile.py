import unittest
from collections import Counter

from model.pipeline_k_retile import retile_group
from model.pipeline_sh_stage import stage_group


def _view(base, rows, cols, row_stride):
    return {"base": base, "rows": rows, "cols": cols,
            "row_stride": row_stride, "col_stride": 1}


def _group():
    def load(tensor, global_view, local_view, token):
        return {"command": "async", "token": token,
                "instruction": {"op": "load", "tensor": tensor,
                                "global": global_view, "local": local_view}}
    commands = [
        {"command": "run", "instruction": {"op": "fill", "dst": 0,
                                          "len": 32, "value": 0.0}},
        load(32, _view(0, 1, 64, 4608), _view(32, 1, 64, 64), 17),
        load(14, _view(480, 64, 32, 4112), _view(96, 64, 32, 32), 18),
        {"command": "wait", "tokens": [17, 18]},
        load(32, _view(64, 1, 64, 4608), _view(2304, 1, 64, 64), 19),
        load(14, _view(480 + 64 * 4112, 64, 32, 4112),
             _view(2368, 64, 32, 32), 20),
        {"command": "run", "instruction": {"op": "mma", "a": 32, "b": 96,
                                          "c": 0, "m": 1, "n": 32, "k": 64}},
        {"command": "wait", "tokens": [19, 20]},
        {"command": "run", "instruction": {"op": "mma", "a": 2304, "b": 2368,
                                          "c": 0, "m": 1, "n": 32, "k": 64}},
        {"command": "run", "instruction": {"op": "store", "tensor": 38,
                                          "global": _view(480, 1, 32, 4097),
                                          "local": _view(0, 1, 32, 32)}},
    ]
    return {"sm": 0, "rf_kib": 18, "sh_kib": 0, "commands": commands}


def _loaded_elements(group):
    counts = Counter()
    for command in group["commands"]:
        instruction = command.get("instruction", {})
        if instruction.get("op") != "load":
            continue
        view = instruction["global"]
        for row in range(view["rows"]):
            for col in range(view["cols"]):
                counts[(instruction["tensor"], view["base"] +
                        row * view["row_stride"] + col)] += 1
    return counts


class PipelineKRetileTest(unittest.TestCase):
    def test_same_hbm_elements_and_ordered_k_with_smaller_rf(self):
        source = _group()
        transformed, tiles = retile_group(source, 48)
        self.assertEqual(tiles, 1)
        self.assertEqual(transformed["rf_kib"], 13)
        self.assertEqual(_loaded_elements(source), _loaded_elements(transformed))
        self.assertEqual([command["instruction"]["k"] for command in transformed["commands"]
                          if command.get("instruction", {}).get("op") == "mma"],
                         [48, 48, 32])
        self.assertEqual([command["instruction"]["tensor"] for command in transformed["commands"]
                          if command.get("instruction", {}).get("op") == "store"], [38])

    def test_shared_staging_preserves_hbm_reads_and_mma_order(self):
        source = _group()
        staged, tiles = stage_group(source)
        self.assertEqual(tiles, 1)
        self.assertEqual((staged["rf_kib"], staged["sh_kib"]), (9, 8))
        original = _loaded_elements(source)
        staged_reads = Counter()
        for command in staged["commands"]:
            instruction = command.get("instruction", {})
            if instruction.get("op") not in ("load", "load_shared"):
                continue
            view = instruction["global"]
            for row in range(view["rows"]):
                for col in range(view["cols"]):
                    staged_reads[(instruction["tensor"], view["base"] +
                                  row * view["row_stride"] + col)] += 1
        self.assertEqual(original, staged_reads)
        self.assertEqual([c["instruction"]["op"] for c in staged["commands"]
                          if "instruction" in c],
                         ["fill", "load", "load", "load", "load_shared",
                          "mma", "shared_read", "mma", "store"])
        self.assertEqual([c["instruction"]["k"] for c in staged["commands"]
                          if c.get("instruction", {}).get("op") == "mma"],
                         [64, 64])

    def test_shared_tc_consumes_staged_second_panel(self):
        staged, tiles = stage_group(_group(), direct_tc=True)
        self.assertEqual(tiles, 1)
        self.assertEqual((staged["rf_kib"], staged["sh_kib"]), (9, 8))
        self.assertEqual([c["instruction"]["op"] for c in staged["commands"]
                          if "instruction" in c],
                         ["fill", "load", "load", "load", "load_shared",
                          "mma", "mma_shared", "store"])
        mma = next(c["instruction"] for c in staged["commands"]
                   if c.get("instruction", {}).get("op") == "mma_shared")
        self.assertEqual(mma["b"], {"base": 0, "rows": 64, "cols": 32,
                                    "row_stride": 32, "col_stride": 1})


if __name__ == "__main__":
    unittest.main()
