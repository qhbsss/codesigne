import unittest

from model.resident4_pack_screen import _access_footprint, _independent_triple


def _command(op, tensor, base):
    view = {"base": base, "rows": 1, "cols": 16,
            "row_stride": 16, "col_stride": 1}
    return {"command": "run", "instruction": {
        "op": op, "tensor": tensor, "global": view, "local": view}}


def _wave(sm, read_tensor, write_tensor):
    return {"record": "wave", "groups": [{"sm": sm, "rf_kib": 4, "sh_kib": 0,
        "commands": [_command("load", read_tensor, 0),
                     _command("store", write_tensor, 0)]}]}


class Resident4PackingSafetyTest(unittest.TestCase):
    def test_cross_wave_read_after_write_is_rejected(self):
        waves = [_wave(0, 1, 12), _wave(1, 12, 13), _wave(2, 2, 14)]
        entries = [(wave, 0, _access_footprint(wave), index)
                   for index, wave in enumerate(waves)]
        self.assertFalse(_independent_triple(entries))

    def test_disjoint_waves_remain_eligible(self):
        waves = [_wave(0, 1, 12), _wave(1, 2, 13), _wave(2, 3, 14)]
        entries = [(wave, 0, _access_footprint(wave), index)
                   for index, wave in enumerate(waves)]
        self.assertTrue(_independent_triple(entries))


if __name__ == "__main__":
    unittest.main()
