import json
import tempfile
import unittest
from pathlib import Path

from model.estimate import estimate_program
from model.tool import ROOT


class HardwareOverrideTests(unittest.TestCase):
    def test_in_memory_hardware_matches_a_retargeted_program(self):
        config = json.loads((ROOT / "phase-two-starter/configs/reference/w-p.json").read_text())
        hardware = config["hardware"]
        changed = {**hardware, "vector": 16}
        wave = {"record": "wave", "groups": [{"sm": 0, "rf_kib": 1,
                "sh_kib": 0, "commands": [{"command": "run", "instruction":
                {"op": "fill", "dst": 0, "len": 64, "value": 0.0}}]}]}
        with tempfile.TemporaryDirectory() as directory:
            original = Path(directory) / "original.jsonl"
            retargeted = Path(directory) / "retargeted.jsonl"
            original.write_text(json.dumps({"record": "header", "hardware": hardware}) +
                                "\n" + json.dumps(wave) + "\n")
            retargeted.write_text(json.dumps({"record": "header", "hardware": changed}) +
                                  "\n" + json.dumps(wave) + "\n")
            expected = estimate_program(retargeted)
            actual = estimate_program(original, hardware_override=changed)
            self.assertEqual(actual, expected)
            self.assertNotEqual(actual["cycles"], estimate_program(original)["cycles"])


if __name__ == "__main__":
    unittest.main()
