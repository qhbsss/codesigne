import unittest

from model.decode_rf_feature_retile import feature_waves
from model.decode_rf_transpose_screen import transpose_admission


class DecodeRfFeatureRetileTest(unittest.TestCase):
    def test_transpose_maps_every_source_element_to_its_feature_row(self):
        header = {
            "batch": 2, "decode": True,
            "shape": {"d": 8, "heads": 2, "history": 5, "steps": 2},
            "hardware": {"sms": 8, "rf_kib": 64, "sh_kib": 32,
                         "resident_groups": 4},
        }
        waves, receipt = feature_waves(header, (1, 2, 16), 4, 2)
        self.assertEqual((receipt["feature_groups"], receipt["tasks"],
                          receipt["access_intervals_per_wave"]), (4, 12, [16]))
        seen = set()
        for wave in waves:
            for group in wave["groups"]:
                commands = group["commands"]
                for offset in range(0, len(commands), 3):
                    load = commands[offset]["instruction"]
                    store = commands[offset + 2]["instruction"]
                    registers = {}
                    a, local = load["global"], load["local"]
                    for row in range(a["rows"]):
                        for col in range(a["cols"]):
                            local_word = local["base"] + row * local["row_stride"] + col
                            registers[local_word] = a["base"] + row * a["row_stride"] + col
                    b, local = store["global"], store["local"]
                    for row in range(b["rows"]):
                        for col in range(b["cols"]):
                            local_word = (local["base"] + row * local["row_stride"] +
                                          col * local["col_stride"])
                            destination = b["base"] + row * b["row_stride"] + col
                            feature, context = divmod(destination, 16)
                            self.assertEqual(registers[local_word], context * 16 + feature)
                            self.assertNotIn(destination, seen)
                            seen.add(destination)
        self.assertEqual(len(seen), 2 * 8 * 5)

    def test_compact_interval_cap_and_cross_sm_overlap(self):
        instruction = {"op": "store", "tensor": 2,
                       "global": {"base": 0, "rows": 262145, "cols": 16,
                                  "row_stride": 16, "col_stride": 1}}
        wave = {"groups": [{"sm": 0, "commands": [
            {"command": "run", "instruction": instruction}]}]}
        with self.assertRaisesRegex(ValueError, "262144"):
            transpose_admission(wave, (1, 2, 16))
        instruction["global"]["rows"] = 1
        wave["groups"].append({"sm": 1, "commands": [
            {"command": "run", "instruction": instruction}]})
        with self.assertRaisesRegex(ValueError, "overlapping feature rows"):
            transpose_admission(wave, (1, 2, 16))


if __name__ == "__main__":
    unittest.main()
