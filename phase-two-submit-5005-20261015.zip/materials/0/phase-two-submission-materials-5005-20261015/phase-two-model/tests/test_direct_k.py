import unittest
from unittest.mock import patch

from model.direct_k import (_direct_view, _on_demand_views, _rewrite_wave,
                            _shared_on_demand_views, _shared_staged_views,
                            _shared_transpose_waves,
                            screen_shared_transpose_grid)


class DirectKViewTests(unittest.TestCase):
    def setUp(self):
        self.header = {
            "batch": 16,
            "shape": {
                "d": 1536,
                "heads": 12,
                "history": 256,
                "steps": 4,
            }
        }

    def test_full_head_view_maps_to_original_context_major_layout(self):
        view = {"base": 128 * 260 + 64, "rows": 128, "cols": 64,
                "row_stride": 260, "col_stride": 1}
        self.assertEqual(
            _direct_view(view, self.header),
            {"base": 64 * 1536 + 128, "rows": 128, "cols": 64,
             "row_stride": 1, "col_stride": 1536},
        )

    def test_partial_head_view_preserves_row_offset(self):
        view = {"base": 112 * 260 + 3, "rows": 16, "cols": 4,
                "row_stride": 260, "col_stride": 1}
        self.assertEqual(
            _direct_view(view, self.header),
            {"base": 3 * 1536 + 112, "rows": 16, "cols": 4,
             "row_stride": 1, "col_stride": 1536},
        )

    def test_batch_offset_maps_to_original_batch_major_layout(self):
        view = {"base": (12 * 12 * 128 + 112) * 260 + 3,
                "rows": 16, "cols": 4,
                "row_stride": 260, "col_stride": 1}
        self.assertEqual(
            _direct_view(view, self.header),
            {"base": 12 * 260 * 1536 + 3 * 1536 + 112,
             "rows": 16, "cols": 4,
             "row_stride": 1, "col_stride": 1536},
        )

    def test_view_cannot_cross_head_boundary(self):
        view = {"base": 120 * 260, "rows": 16, "cols": 64,
                "row_stride": 260, "col_stride": 1}
        with self.assertRaisesRegex(ValueError, "exceeds tensor"):
            _direct_view(view, self.header)

    def test_on_demand_load_is_contiguous_and_transposes_in_rf(self):
        global_view = {"base": 128 * 260 + 64, "rows": 112, "cols": 32,
                       "row_stride": 260, "col_stride": 1}
        local_view = {"base": 288, "rows": 112, "cols": 32,
                      "row_stride": 32, "col_stride": 1}
        self.assertEqual(
            _on_demand_views(global_view, local_view, self.header),
            (
                {"base": 64 * 1536 + 128, "rows": 32, "cols": 112,
                 "row_stride": 1536, "col_stride": 1},
                {"base": 288, "rows": 32, "cols": 112,
                 "row_stride": 1, "col_stride": 32},
            ),
        )

    def test_on_demand_wave_rewrites_tensor_and_views(self):
        record = {"record": "wave", "groups": [{"commands": [{
            "command": "run",
            "instruction": {
                "op": "load", "tensor": 14,
                "global": {"base": 128 * 260 + 64, "rows": 112,
                           "cols": 32, "row_stride": 260, "col_stride": 1},
                "local": {"base": 288, "rows": 112, "cols": 32,
                          "row_stride": 32, "col_stride": 1},
            },
        }]}]}
        rewritten, changed = _rewrite_wave(
            record, self.header, {14: 12}, "on-demand-transpose")
        self.assertTrue(changed)
        instruction = rewritten["groups"][0]["commands"][0]["instruction"]
        self.assertEqual(instruction["tensor"], 12)
        self.assertEqual(
            instruction["global"],
            {"base": 64 * 1536 + 128, "rows": 32, "cols": 112,
             "row_stride": 1536, "col_stride": 1},
        )
        self.assertEqual(
            instruction["local"],
            {"base": 288, "rows": 32, "cols": 112,
             "row_stride": 1, "col_stride": 32},
        )

    def test_shared_on_demand_uses_contiguous_dma_and_transposed_mma_view(self):
        global_view = {"base": 128 * 260 + 64, "rows": 112, "cols": 32,
                       "row_stride": 260, "col_stride": 1}
        local_view = {"base": 288, "rows": 112, "cols": 32,
                      "row_stride": 32, "col_stride": 1}
        self.assertEqual(
            _shared_on_demand_views(global_view, local_view, self.header),
            (
                {"base": 64 * 1536 + 128, "rows": 32, "cols": 112,
                 "row_stride": 1536, "col_stride": 1},
                {"base": 0, "rows": 32, "cols": 112,
                 "row_stride": 112, "col_stride": 1},
                {"base": 0, "rows": 112, "cols": 32,
                 "row_stride": 1, "col_stride": 112},
            ),
        )

    def test_shared_on_demand_rewrites_load_and_matching_mma(self):
        record = {"record": "wave", "groups": [{"sm": 0, "rf_kib": 4,
            "sh_kib": 0, "commands": [
                {"command": "async", "token": 1, "instruction": {
                    "op": "load", "tensor": 14,
                    "global": {"base": 128 * 260 + 64, "rows": 112,
                               "cols": 32, "row_stride": 260, "col_stride": 1},
                    "local": {"base": 288, "rows": 112, "cols": 32,
                              "row_stride": 32, "col_stride": 1}}},
                {"command": "wait", "tokens": [1]},
                {"command": "run", "instruction": {
                    "op": "mma", "a": 0, "b": 288, "c": 128,
                    "m": 1, "n": 32, "k": 112}},
            ]}]}
        rewritten, changed = _rewrite_wave(
            record, self.header, {14: 12}, "shared-on-demand")
        self.assertTrue(changed)
        group = rewritten["groups"][0]
        self.assertEqual(group["sh_kib"], 16)
        load = group["commands"][0]["instruction"]
        self.assertEqual((load["op"], load["tensor"]), ("load_shared", 12))
        self.assertEqual(load["local"],
                         {"base": 0, "rows": 32, "cols": 112,
                          "row_stride": 112, "col_stride": 1})
        mma = group["commands"][2]["instruction"]
        self.assertEqual(mma["op"], "mma_shared")
        self.assertEqual(mma["b"],
                         {"base": 0, "rows": 112, "cols": 32,
                          "row_stride": 1, "col_stride": 112})

    def test_shared_staged_padding_avoids_transpose_bank_aliasing(self):
        global_view = {"base": 128 * 260 + 64, "rows": 112, "cols": 32,
                       "row_stride": 260, "col_stride": 1}
        local_view = {"base": 288, "rows": 112, "cols": 32,
                      "row_stride": 32, "col_stride": 1}
        views = _shared_staged_views(global_view, local_view, self.header)
        self.assertEqual(views[1],
                         {"base": 0, "rows": 32, "cols": 112,
                          "row_stride": 113, "col_stride": 1})
        self.assertEqual(views[2],
                         {"base": 0, "rows": 112, "cols": 32,
                          "row_stride": 1, "col_stride": 113})
        self.assertEqual(views[3], local_view)

    def test_shared_staged_inserts_read_before_regular_mma(self):
        record = {"record": "wave", "groups": [{"sm": 0, "rf_kib": 4,
            "sh_kib": 0, "commands": [
                {"command": "async", "token": 1, "instruction": {
                    "op": "load", "tensor": 14,
                    "global": {"base": 128 * 260 + 64, "rows": 112,
                               "cols": 32, "row_stride": 260, "col_stride": 1},
                    "local": {"base": 288, "rows": 112, "cols": 32,
                              "row_stride": 32, "col_stride": 1}}},
                {"command": "wait", "tokens": [1]},
                {"command": "run", "instruction": {
                    "op": "mma", "a": 0, "b": 288, "c": 128,
                    "m": 1, "n": 32, "k": 112}},
            ]}]}
        rewritten, changed = _rewrite_wave(
            record, self.header, {14: 12}, "shared-staged")
        self.assertTrue(changed)
        group = rewritten["groups"][0]
        self.assertEqual(group["sh_kib"], 16)
        self.assertEqual([command.get("instruction", {}).get("op")
                          for command in group["commands"]],
                         ["load_shared", None, "shared_read", "mma"])
        self.assertEqual(group["commands"][3]["instruction"]["b"], 288)

    def test_shared_transpose_tiles_cover_padded_mapping(self):
        header = {"batch": 1,
                  "shape": {"d": 8, "heads": 2, "history": 4, "steps": 1},
                  "hardware": {"sms": 2, "resident_groups": 2, "sh_kib": 32}}
        waves, tasks, group_sh_kib = _shared_transpose_waves(
            header, 3, 4, feature_tile=4, context_tile=3)
        self.assertEqual((tasks, group_sh_kib, len(waves)), (4, 4, 1))
        self.assertEqual(len(waves[0]["groups"]), 4)
        commands = waves[0]["groups"][0]["commands"]
        self.assertEqual(commands[0]["instruction"]["global"],
                         {"base": 0, "rows": 3, "cols": 4,
                          "row_stride": 8, "col_stride": 1})
        self.assertEqual(commands[0]["instruction"]["local"],
                         {"base": 0, "rows": 3, "cols": 4,
                          "row_stride": 5, "col_stride": 1})
        self.assertEqual(commands[2]["instruction"]["global"],
                         {"base": 0, "rows": 4, "cols": 3,
                          "row_stride": 5, "col_stride": 1})
        self.assertEqual(commands[2]["instruction"]["local"],
                         {"base": 0, "rows": 4, "cols": 3,
                          "row_stride": 1, "col_stride": 5})

    def test_wide_shared_transpose_respects_sh_capacity(self):
        header = {"batch": 1,
                  "shape": {"d": 1536, "heads": 12, "history": 4096,
                            "steps": 4},
                  "hardware": {"sms": 8, "resident_groups": 2,
                               "sh_kib": 32}}
        waves, tasks, sh_kib = _shared_transpose_waves(
            header, 3, 4, feature_tile=512, context_tile=8)
        self.assertEqual((tasks, sh_kib, len(waves)), (1539, 20, 1))
        with self.assertRaisesRegex(ValueError, "exceeds SH capacity"):
            _shared_transpose_waves(header, 3, 4, 512, 16)

    @patch("model.direct_k.sha", return_value="source-sha")
    @patch("model.direct_k._shared_transpose_waves")
    @patch("model.direct_k.estimate_wave")
    @patch("model.direct_k.program_records")
    @patch("model.direct_k._transposed_pairs")
    def test_shared_transpose_grid_replaces_affected_wave_cost_once(
            self, transposed_pairs, records, estimate_wave,
            shared_transpose_waves, _sha):
        header = {"decode": True, "hardware": {}}
        transpose = {"record": "wave", "groups": [{"commands": [
            {"instruction": {"op": "load", "tensor": 3}},
            {"instruction": {"op": "store", "tensor": 4}},
        ]}]}
        transposed_pairs.return_value = header, {4: 3}
        records.return_value = iter([header, transpose])
        shared_transpose_waves.return_value = (
            [{"record": "wave", "groups": [{"replacement": True}]}], 2, 4)
        estimate_wave.side_effect = lambda groups, *_args: (
            25 if groups[0].get("replacement") else 100)

        result = screen_shared_transpose_grid("program.jsonl", 1000, [64], [32])

        self.assertEqual(result["program_sha256"], "source-sha")
        self.assertEqual(result["candidates"], [{
            "feature_tile": 64,
            "context_tile": 32,
            "group_sh_kib": 4,
            "removed_transpose_waves": 1,
            "replacement_waves": 1,
            "replacement_tasks": 2,
            "original_affected_cycles": 100,
            "replacement_affected_cycles": 25,
            "baseline_cycles": 1000,
            "predicted_cycles": 925,
        }])


if __name__ == "__main__":
    unittest.main()
