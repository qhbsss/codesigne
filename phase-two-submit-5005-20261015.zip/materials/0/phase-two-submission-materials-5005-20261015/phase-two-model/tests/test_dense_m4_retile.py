import unittest
from collections import Counter

from model.dense_m4_retile import retile_group


def view(base, rows, cols, stride):
    return {"base": base, "rows": rows, "cols": cols,
            "row_stride": stride, "col_stride": 1}


def group():
    commands = [{"command": "run", "instruction":
                 {"op": "fill", "dst": 0, "len": 128, "value": 0.0}}]
    for index in range(8):
        offset = index * 128
        left, right = 2 * index + 1, 2 * index + 2
        commands.extend((
            {"command": "async", "token": left, "instruction":
             {"op": "load", "tensor": 1,
              "global": view(offset, 4, 128, 1536),
              "local": view(128, 4, 128, 128)}},
            {"command": "async", "token": right, "instruction":
             {"op": "load", "tensor": 2,
              "global": view(224 + offset * 4608, 128, 32, 4608),
              "local": view(640, 128, 32, 32)}},
            {"command": "wait", "tokens": [left, right]},
            {"command": "run", "instruction":
             {"op": "mma", "a": 128, "b": 640, "c": 0,
              "m": 4, "n": 32, "k": 128}},
        ))
    commands.extend((
        {"command": "run", "instruction":
         {"op": "load", "tensor": 3,
          "global": view(0, 1, 32, 32),
          "local": view(1152, 1, 32, 32)}},
        {"command": "run", "instruction":
         {"op": "vector", "kind": "add", "len": 128, "dst": 0,
          "a": {"kind": "reg", "base": 0, "stride": 1},
          "b": {"kind": "reg", "base": 1152, "stride": 0}}},
        {"command": "run", "instruction":
         {"op": "store", "tensor": 4,
          "global": view(0, 4, 32, 4608),
          "local": view(0, 4, 32, 32)}},
    ))
    return {"sm": 0, "rf_kib": 19, "sh_kib": 0, "commands": commands}


def loaded_elements(commands):
    counts = Counter()
    for command in commands:
        instruction = command.get("instruction", {})
        if instruction.get("op") != "load":
            continue
        v = instruction["global"]
        for row in range(v["rows"]):
            for col in range(v["cols"]):
                counts[(instruction["tensor"], v["base"] +
                        row * v["row_stride"] + col)] += 1
    return counts


class DenseM4RetileTest(unittest.TestCase):
    def test_full_k_range_and_fused_output_are_preserved(self):
        source = group()
        transformed, tiles = retile_group(source, 110)
        self.assertEqual(tiles, 1)
        self.assertEqual(transformed["rf_kib"], 16)
        self.assertEqual(loaded_elements(source["commands"]),
                         loaded_elements(transformed["commands"]))
        original_k = [c["instruction"]["k"] for c in source["commands"]
                      if c.get("instruction", {}).get("op") == "mma"]
        new_k = [c["instruction"]["k"] for c in transformed["commands"]
                 if c.get("instruction", {}).get("op") == "mma"]
        self.assertEqual(sum(original_k), sum(new_k))
        self.assertEqual(new_k, [110] * 9 + [34])
        self.assertEqual(source["commands"][-3:], transformed["commands"][-3:])


if __name__ == "__main__":
    unittest.main()
