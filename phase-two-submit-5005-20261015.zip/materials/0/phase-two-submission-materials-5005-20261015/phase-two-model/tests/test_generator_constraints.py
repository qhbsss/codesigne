import copy
import json
import unittest

from model.generator_constraints import validate_generator_config
from model.tool import STARTER


class GeneratorConstraintTests(unittest.TestCase):
    def reference(self, name):
        return json.loads((STARTER / "configs/reference" / f"{name}.json").read_text())

    def test_reference_configs_pass_without_export(self):
        for name in ("w-p", "a-p", "w-d1", "w-d16", "w-d4l"):
            with self.subTest(name=name):
                validate_generator_config(self.reference(name))

    def test_rejects_rf_tile_that_cannot_fit(self):
        config = copy.deepcopy(self.reference("w-d1"))
        config["policy"].update(m=64, n=64, k=256)
        config["hardware"]["rf_kib"] = 16
        with self.assertRaisesRegex(ValueError, "GEMM tile working set exceeds RF"):
            validate_generator_config(config)

    def test_rejects_direct_shared_without_interface(self):
        config = copy.deepcopy(self.reference("a-p"))
        config["hardware"]["sh_tc_bw"] = 0
        with self.assertRaisesRegex(ValueError, "requires SH-TC bandwidth"):
            validate_generator_config(config)
