import unittest

from model.direct_k import _shared_transpose_waves


class PaddedKTransposeTests(unittest.TestCase):
    def test_padded_output_maps_every_initial_k_element_once(self):
        header = {
            "batch": 2,
            "shape": {"d": 64, "heads": 1, "history": 32, "steps": 4},
            "hardware": {"sms": 2, "resident_groups": 2, "sh_kib": 32},
        }
        pitch = 48
        waves, _, _ = _shared_transpose_waves(
            header, 0, 1, 64, 16, output_stride=pitch)
        mapped = {}
        for wave in waves:
            for group in wave["groups"]:
                commands = group["commands"]
                for index in range(0, len(commands), 3):
                    load = commands[index]["instruction"]
                    store = commands[index + 2]["instruction"]
                    a, b = load["global"], store["global"]
                    self.assertEqual((a["rows"], a["cols"]), (b["cols"], b["rows"]))
                    self.assertEqual(b["row_stride"], pitch)
                    for feature in range(b["rows"]):
                        for context in range(b["cols"]):
                            src = a["base"] + context * a["row_stride"] + feature
                            dst = b["base"] + feature * pitch + context
                            self.assertNotIn(dst, mapped)
                            mapped[dst] = src
        self.assertEqual(len(mapped), 2 * 64 * 32)
        for batch in range(2):
            for feature in range(64):
                for context in range(32):
                    dst = (batch * 64 + feature) * pitch + context
                    src = context * 2 * 64 + batch * 64 + feature
                    self.assertEqual(mapped[dst], src)


if __name__ == "__main__":
    unittest.main()
