import json
import tempfile
import unittest
from pathlib import Path

from model.discover import build_spec
from model.tool import ROOT, sha


class DiscoverTests(unittest.TestCase):
    def test_discovery_deduplicates_and_checks_artifact_hashes(self):
        base = json.loads((ROOT / "phase-two-model/specs/portfolio-mip-20261012.json").read_text())
        original = ROOT / base["hardware_options"][0]["programs"]["w-p"][0]
        with original.open() as source:
            header = json.loads(next(source))
        with tempfile.TemporaryDirectory(dir=ROOT) as directory:
            folder = Path(directory)
            program = folder / "program.jsonl"
            program.write_text(json.dumps(header) + "\n" + json.dumps({"record": "wave", "groups": []}) + "\n")
            config = folder / "config.json"
            config.write_text(json.dumps(header))
            manifest = folder / "prepared.json"
            receipt = {"status": "unverified", "case": "w-p", "program": str(program),
                       "program_sha256": sha(program), "config_sha256": sha(config)}
            manifest.write_text(json.dumps(receipt))

            spec, report = build_spec(base, [manifest, manifest])
            self.assertEqual(report["added_programs"], 1)
            matching = [design for design in spec["hardware_options"] if str(program.relative_to(ROOT))
                        in design["programs"]["w-p"]]
            self.assertEqual(len(matching), 1)
            self.assertEqual(len(matching[0]["programs"]["w-p"]), 2)

            receipt["program_sha256"] = "changed"
            manifest.write_text(json.dumps(receipt))
            _, report = build_spec(base, [manifest])
            self.assertEqual(report["added_programs"], 0)
            self.assertEqual(report["rejected"][0]["reason"], "missing or changed artifact")


if __name__ == "__main__":
    unittest.main()
