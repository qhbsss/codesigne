import json
import tempfile
import unittest
from concurrent.futures import Future
from pathlib import Path
from unittest.mock import patch

from model.portfolio import (_checked_evaluation, _register_request_timing,
                             prepare_portfolio, run, select_portfolio)
from model.tool import ROOT, SCORE_CASES


class PortfolioTests(unittest.TestCase):
    class InlineExecutor:
        def __init__(self, max_workers):
            self.max_workers = max_workers

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_value, traceback):
            return False

        def submit(self, function, *arguments):
            future = Future()
            try:
                future.set_result(function(*arguments))
            except Exception as error:
                future.set_exception(error)
            return future

    def test_shared_hardware_mip_does_not_mix_cases(self):
        hardware = [
            {"index": 0, "design": {"name": "zero"}, "area_au": 90},
            {"index": 1, "design": {"name": "one"}, "area_au": 99},
        ]
        options = []
        for hardware_index in range(2):
            for case_name in SCORE_CASES:
                cycles = 100 if hardware_index == 0 else 80
                if hardware_index == 1 and case_name == "w-d4l":
                    cycles = 400
                options.append({"hardware_index": hardware_index, "case": case_name,
                                "status": "unverified", "lower_bound_cycles": 1,
                                "estimated_cycles": cycles})
        result = select_portfolio(hardware, options, 5000)
        self.assertEqual(result["selected_hardware"]["design"]["name"], "zero")
        self.assertEqual(len(result["selected_programs"]), 5)
        self.assertTrue(all(option["hardware_index"] == 0
                            for option in result["selected_programs"].values()))
        self.assertEqual(result["solver"]["status"], 0)

    def test_invalid_workload_is_rejected_before_estimation(self):
        spec_path = ROOT / "phase-two-model/specs/portfolio-mip-20261012.json"
        spec = json.loads(spec_path.read_text())
        with tempfile.TemporaryDirectory() as directory:
            candidate = Path(directory) / "bad.jsonl"
            with (ROOT / spec["hardware_options"][0]["programs"]["a-p"][0]).open() as source:
                candidate.write_text(next(source))
            spec["hardware_options"][0]["programs"]["w-p"] = [str(candidate)]
            with self.assertRaisesRegex(ValueError, "incorrect workload"):
                prepare_portfolio(spec, lambda program: self.fail("estimated invalid program"))

    def test_request_evidence_matches_header_source_and_power(self):
        expected_headers = {("w-p", "digest"): {"hardware": {"sms": 8}}}
        report = {"stats": {"cycles": 101}, "power_pass": True}
        evidence = {}

        def register(header=None, source="source", request_report=None, checked=False):
            _register_request_timing(
                evidence, expected_headers, "w-p", "digest",
                header or expected_headers["w-p", "digest"],
                request_report or report, source, "source", checked, "evidence.json")

        register()
        self.assertFalse(evidence["w-p", "digest"]["numerical_checked"])
        register(checked=True)
        self.assertTrue(evidence["w-p", "digest"]["numerical_checked"])
        with self.assertRaisesRegex(ValueError, "header or source"):
            register(header={"hardware": {"sms": 16}})
        with self.assertRaisesRegex(ValueError, "header or source"):
            register(source="different")
        with self.assertRaisesRegex(ValueError, "ineligible"):
            register(request_report={"stats": {"cycles": 101}, "power_pass": False})
        with self.assertRaisesRegex(ValueError, "conflicting"):
            register(request_report={"stats": {"cycles": 100}, "power_pass": True})

    def test_only_completed_numerical_evaluation_is_checked(self):
        report = {"status": "complete", "mode": "evaluate", "seed": 7,
                  "error": None, "evaluation": {"output_sha256": "output",
                                                "comparison": {"max_scaled": 0.01},
                                                "report": {"power_pass": True}}}
        self.assertTrue(_checked_evaluation(report))
        for field, value in (("mode", "predict"), ("status", "failed"),
                             ("seed", 8), ("error", "bad result")):
            altered = {**report, field: value}
            self.assertFalse(_checked_evaluation(altered))
        altered = {**report, "evaluation": {**report["evaluation"], "comparison": None}}
        self.assertFalse(_checked_evaluation(altered))

    def test_small_batches_resume_from_saved_estimates(self):
        source = ROOT / "phase-two-model/specs/portfolio-mip-20261012.json"
        original = json.loads(source.read_text())
        spec = {"target_score": 5000, "hardware_options": [original["hardware_options"][0]]}
        with tempfile.TemporaryDirectory() as directory:
            spec_path = Path(directory) / "spec.json"
            output = Path(directory) / "run"
            spec_path.write_text(json.dumps(spec))
            with patch("model.portfolio.estimate_program", return_value={"cycles": 100}) as estimate:
                self.assertIsNone(run(spec_path, output, max_new_estimates=2))
                self.assertEqual(json.loads((output / "progress.json").read_text())[
                    "cached_unique_estimates"], 2)
                self.assertIsNone(run(spec_path, output, resume=True, max_new_estimates=2))
                result = run(spec_path, output, resume=True, max_new_estimates=2)
            self.assertEqual(estimate.call_count, 5)
            self.assertEqual(len(result["selected_programs"]), 5)
            self.assertFalse((output / "progress.json").exists())

    def test_parallel_batches_checkpoint_completed_estimates(self):
        source = ROOT / "phase-two-model/specs/portfolio-mip-20261012.json"
        original = json.loads(source.read_text())
        spec = {"target_score": 5000, "hardware_options": [original["hardware_options"][0]]}
        with tempfile.TemporaryDirectory() as directory:
            spec_path = Path(directory) / "spec.json"
            output = Path(directory) / "run"
            spec_path.write_text(json.dumps(spec))
            with (patch("model.portfolio.ProcessPoolExecutor", self.InlineExecutor),
                  patch("model.portfolio.estimate_program", return_value={"cycles": 100})
                  as estimate):
                self.assertIsNone(run(spec_path, output, max_new_estimates=2, workers=2))
                progress = json.loads((output / "progress.json").read_text())
                self.assertEqual(progress["cached_unique_estimates"], 2)
                self.assertEqual(progress["new_estimates_in_batch"], 2)
                result = run(spec_path, output, resume=True, workers=2)
            self.assertEqual(estimate.call_count, 5)
            self.assertEqual(len(result["selected_programs"]), 5)
            self.assertFalse((output / "progress.json").exists())


if __name__ == "__main__":
    unittest.main()
