import unittest

from model.resident4_pack_screen import _access_footprint
from model.resident4_window_screen import choose, independent
from tests.test_resident4_pack_screen import _wave


class WindowScreenTest(unittest.TestCase):
    def test_fourth_wave_dependency_rejects_window(self):
        waves = [_wave(0, 1, 12), _wave(1, 2, 13),
                 _wave(2, 3, 14), _wave(3, 12, 15)]
        entries = [(wave, 0, _access_footprint(wave), index)
                   for index, wave in enumerate(waves)]
        self.assertTrue(independent(entries[:3]))
        self.assertFalse(independent(entries))

    def test_dynamic_choice_beats_greedy_first_pair(self):
        rows = [
            {"base": 10, "options": [{"source_waves": 2, "packed_waves": 1,
                                      "cycles": 16}]},
            {"base": 10, "options": [{"source_waves": 2, "packed_waves": 1,
                                      "cycles": 10}]},
            {"base": 10, "options": []},
        ]
        selected, cycles = choose(rows)
        self.assertEqual(cycles, 20)
        self.assertEqual([row["source_start"] for row in selected], [0, 1])


if __name__ == "__main__":
    unittest.main()
