import json
import tempfile
import unittest
from pathlib import Path

from model.retarget_portfolio import build
from model.tool import ROOT, SCORE_CASES


class RetargetPortfolioTests(unittest.TestCase):
    def test_retargets_headers_and_preserves_program_bodies(self):
        programs = {case: [f"phase-two-starter/programs/k4-rf/{case}.jsonl"]
                    for case in SCORE_CASES}
        with (ROOT / programs["w-p"][0]).open() as source:
            hardware = json.loads(next(source))["hardware"]
        spec = {"target_score": 5000,
                "hardware_choices": [{"name": "same", "hardware": hardware}],
                "programs": programs}
        with tempfile.TemporaryDirectory() as directory:
            directory = Path(directory)
            spec_path = directory / "spec.json"
            spec_path.write_text(json.dumps(spec))
            result = build(spec_path, directory / "output")
            for case in SCORE_CASES:
                source = ROOT / programs[case][0]
                destination = Path(result["hardware_options"][0]["programs"][case][0])
                with source.open("rb") as original, destination.open("rb") as retargeted:
                    source_header = json.loads(original.readline())
                    target_header = json.loads(retargeted.readline())
                    self.assertEqual(target_header["hardware"], hardware)
                    self.assertEqual(source_header, target_header)
                    self.assertEqual(original.read(), retargeted.read())


if __name__ == "__main__":
    unittest.main()
