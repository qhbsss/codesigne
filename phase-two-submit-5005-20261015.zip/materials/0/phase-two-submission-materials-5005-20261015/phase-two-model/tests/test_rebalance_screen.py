import unittest

from model.estimate import validate_wave_capacity
from model.rebalance_screen import split_wave


class SplitWaveTests(unittest.TestCase):
    def setUp(self):
        self.hardware = {"sms": 2, "rf_kib": 64, "sh_kib": 32,
                         "resident_groups": 2}

    def test_splits_rf_conflicts_without_moving_a_group_to_another_sm(self):
        groups = [{"sm": sm, "rf_kib": 40, "sh_kib": 0,
                   "commands": [{"id": index}]}
                  for index, sm in enumerate((0, 0, 1, 1))]
        rounds = split_wave(groups, self.hardware)
        self.assertEqual([[group["commands"][0]["id"] for group in wave]
                          for wave in rounds], [[0, 2], [1, 3]])
        for wave in rounds:
            validate_wave_capacity(wave, self.hardware)

    def test_preserves_a_wave_that_fits(self):
        groups = [{"sm": 0, "rf_kib": 32, "sh_kib": 0},
                  {"sm": 0, "rf_kib": 32, "sh_kib": 0}]
        self.assertEqual(split_wave(groups, self.hardware), [groups])

    def test_rejects_a_group_larger_than_the_new_rf(self):
        with self.assertRaises(ValueError):
            split_wave([{"sm": 0, "rf_kib": 65, "sh_kib": 0}],
                       self.hardware)


if __name__ == "__main__":
    unittest.main()
