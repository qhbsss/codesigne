"""Check ragged DMA never reads NaN score cells and preserves AV input."""

import math

from model.local_causal_mask import _localize_group, _mask_wave


def test_causal_rf_fill_matches_masked_score_tile():
    context = 8
    global_view = {"base": 2 * context + 1, "rows": 3, "cols": 4,
                   "row_stride": context, "col_stride": 1}
    local_view = {"base": 20, "rows": 3, "cols": 4,
                  "row_stride": 4, "col_stride": 1}
    load = {"op": "load", "tensor": 5, "global": global_view,
            "local": local_view}
    original = [float(10 * row + col) if col <= row else 0.0
                for row in range(context) for col in range(context)]
    unmasked = [float(10 * row + col) if col <= row else math.nan
                for row in range(context) for col in range(context)]
    rf = [None] * 40
    group = {"commands": [
        {"command": "async", "token": 1, "instruction": load},
        {"command": "wait", "tokens": [1]},
        {"command": "run", "instruction": {"op": "mma"}},
    ]}
    changed, inserted = _localize_group(group, {5}, context)
    assert inserted == 2
    for command in changed["commands"]:
        if command.get("instruction", {}).get("op") == "mma":
            break
        if command["command"] == "wait":
            continue
        instruction = command["instruction"]
        if instruction["op"] == "load":
            source = instruction["global"]["base"]
            target = instruction["local"]["base"]
            for offset in range(instruction["global"]["cols"]):
                value = unmasked[source + offset]
                assert math.isfinite(value)
                rf[target + offset] = value
        elif instruction["op"] == "fill":
            for offset in range(instruction["len"]):
                rf[instruction["dst"] + offset] = instruction["value"]
    expected = [original[global_view["base"] + row * context + col]
                for row in range(global_view["rows"])
                for col in range(global_view["cols"])]
    assert rf[20:32] == expected


def test_fills_follow_dma_wait_and_global_mask_is_exactly_identified():
    view = {"base": 2 * 8 + 1, "rows": 3, "cols": 4,
            "row_stride": 8, "col_stride": 1}
    local = {"base": 20, "rows": 3, "cols": 4,
             "row_stride": 4, "col_stride": 1}
    group = {"commands": [
        {"command": "async", "token": 1,
         "instruction": {"op": "load", "tensor": 5,
                         "global": view, "local": local}},
        {"command": "wait", "tokens": [1]},
        {"command": "run", "instruction": {"op": "mma"}},
    ]}
    changed, inserted = _localize_group(group, {5}, 8)
    assert inserted == 2
    assert [command.get("instruction", {}).get("op")
            for command in changed["commands"]] == [
                "load", "load", "load", None, "fill", "fill", "mma"]
    assert len({command["token"] for command in changed["commands"]
                if command["command"] == "async"}) == 3
    mask = [{"commands": [
        {"command": "run", "instruction": {
            "op": "fill", "dst": 0, "len": 3, "value": 0}},
        {"command": "run", "instruction": {
            "op": "store", "tensor": 5,
            "global": {"base": 2 * 8 + 3, "rows": 1, "cols": 3,
                       "row_stride": 8, "col_stride": 1},
            "local": {"base": 0}}},
    ]}]
    assert _mask_wave(mask, {5}, 8)
    mask[0]["commands"][1]["instruction"]["tensor"] = 6
    assert not _mask_wave(mask, {5}, 8)


def test_ragged_score_loads_wait_before_live_token_limit():
    context = 16
    group = {"commands": [
        {"command": "async", "token": 1, "instruction": {
            "op": "load", "tensor": 5,
            "global": {"base": 3 * context + 1, "rows": 8, "cols": 12,
                       "row_stride": context, "col_stride": 1},
            "local": {"base": 0, "rows": 8, "cols": 12,
                      "row_stride": 12, "col_stride": 1}}},
        {"command": "wait", "tokens": [1]},
        {"command": "run", "instruction": {"op": "mma"}},
    ]}
    changed, fills = _localize_group(group, {5}, context, max_live_tokens=6)
    assert fills > 0
    live = set()
    waits = 0
    for command in changed["commands"]:
        if command["command"] == "async":
            live.add(command["token"])
            assert len(live) <= 6
        elif command["command"] == "wait":
            live.difference_update(command["tokens"])
            waits += 1
    assert not live and waits >= 2


def test_value_prefetch_reserves_token_slot_for_ragged_score_dma():
    from model.prefetch_ragged import prefetch_group

    context = 16
    score = {"command": "async", "token": 1, "instruction": {
        "op": "load", "tensor": 5,
        "global": {"base": 3 * context + 1, "rows": 8, "cols": 12,
                   "row_stride": context, "col_stride": 1},
        "local": {"base": 0, "rows": 8, "cols": 12,
                  "row_stride": 12, "col_stride": 1}}}
    value = {"command": "async", "token": 2, "instruction": {
        "op": "load", "tensor": 6,
        "global": {"base": 0, "rows": 1, "cols": 8,
                   "row_stride": 8, "col_stride": 1},
        "local": {"base": 128, "rows": 1, "cols": 8,
                  "row_stride": 8, "col_stride": 1}}}
    group = {"commands": [score, value,
                           {"command": "wait", "tokens": [1, 2]},
                           {"command": "run", "instruction": {"op": "mma"}}]}
    changed, fills, swaps = prefetch_group(group, {5}, context, 6)
    assert swaps == 1 and fills > 0
    assert changed["commands"][0]["token"] == 2
    live = set()
    for command in changed["commands"]:
        if command["command"] == "async":
            live.add(command["token"])
            assert len(live) <= 6
        elif command["command"] == "wait":
            live.difference_update(command["tokens"])
    assert not live
