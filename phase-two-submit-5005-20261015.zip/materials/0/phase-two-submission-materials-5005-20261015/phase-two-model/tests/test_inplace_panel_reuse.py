import copy
import unittest

from model.inplace_panel_reuse import reuse_group
from model.reuse_b_within import _group


def _view(base, rows, cols):
    return {"base": base, "rows": rows, "cols": cols,
            "row_stride": cols, "col_stride": 1}


def _tile(row, panel_base=0):
    return [
        {"command": "run", "instruction": {
            "op": "fill", "dst": 0, "len": 32, "value": 0.0}},
        {"command": "async", "token": 1, "instruction": {
            "op": "load", "tensor": 1, "global": _view(row * 32, 2, 16),
            "local": _view(32, 2, 16)}},
        {"command": "async", "token": 2, "instruction": {
            "op": "load", "tensor": 2, "global": _view(panel_base, 16, 16),
            "local": _view(64, 16, 16)}},
        {"command": "wait", "tokens": [1, 2]},
        {"command": "run", "instruction": {
            "op": "mma", "m": 2, "n": 16, "k": 16,
            "a": 32, "b": 64, "c": 0}},
        {"command": "run", "instruction": {
            "op": "store", "tensor": 3, "global": _view(row * 32, 2, 16),
            "local": _view(0, 2, 16)}}]


class InplacePanelReuseTests(unittest.TestCase):
    def test_reuses_accumulator_and_panel_without_more_rf(self):
        original = _tile(0, 0) + _tile(1, 16) + _tile(2, 0) + _tile(3, 16)
        group = {"sm": 0, "rf_kib": 2, "sh_kib": 0,
                 "commands": copy.deepcopy(original)}
        transformed, reused, removed = reuse_group(group, 8)
        self.assertEqual((reused, removed), (4, 2))
        self.assertEqual(transformed["rf_kib"], group["rf_kib"])
        panel_loads = [command for command in transformed["commands"]
                       if command.get("instruction", {}).get("tensor") == 2]
        self.assertEqual(len(panel_loads), 2)
        self.assertEqual(len([command for command in transformed["commands"]
                              if command.get("instruction", {}).get("op") == "store"]), 4)
        self.assertEqual({command["instruction"]["c"]
                          for command in transformed["commands"]
                          if command.get("instruction", {}).get("op") == "mma"}, {0})
        self.assertEqual(group["commands"], original)

    def test_fanout_controls_panel_reload_count(self):
        group = {"sm": 0, "rf_kib": 2, "sh_kib": 0,
                 "commands": sum((_tile(row) for row in range(5)), [])}
        transformed, reused, removed = reuse_group(group, 2)
        self.assertEqual((reused, removed), (4, 2))
        panel_loads = [command for command in transformed["commands"]
                       if command.get("instruction", {}).get("tensor") == 2]
        self.assertEqual(len(panel_loads), 3)

    def test_rejects_overlapping_outputs(self):
        group = {"sm": 0, "rf_kib": 2, "sh_kib": 0,
                 "commands": _tile(0) + _tile(0)}
        self.assertEqual(reuse_group(group, 8)[1:], (0, 0))

    def test_extends_an_existing_two_way_reuse_group(self):
        source = {"sm": 0, "rf_kib": 2, "sh_kib": 0,
                  "commands": sum((_tile(row) for row in range(4)), [])}
        paired, _, _ = _group(source, 2)
        self.assertEqual(sum(command.get("instruction", {}).get("tensor") == 2
                             for command in paired["commands"]), 2)
        transformed, reused, removed = reuse_group(paired, 8)
        self.assertEqual((reused, removed), (4, 1))
        self.assertEqual(sum(command.get("instruction", {}).get("tensor") == 2
                             for command in transformed["commands"]), 1)


if __name__ == "__main__":
    unittest.main()
