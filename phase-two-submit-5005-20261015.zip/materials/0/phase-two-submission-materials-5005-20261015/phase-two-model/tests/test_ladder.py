import copy
import hashlib
import json
import shutil
import tempfile
import unittest
from pathlib import Path

from model.ladder import (BASE_GRADE, initial_ledger, qualifies_for_archive,
                          run, screen, verify_grade)
from model.tool import MODEL, SCORE_CASES, sha


def verified_solution():
    grade = json.loads(BASE_GRADE.read_text())
    return {"selected_hardware": {"hardware": grade["hardware"]},
            "selected_programs": {
                case: {"program": str(BASE_GRADE.parent / "programs" / f"{case}.jsonl"),
                       "program_sha256": grade["cases"][case]["program_sha256"],
                       "estimated_cycles": grade["cases"][case]["cycles"]}
                for case in SCORE_CASES},
            "estimator_sha256": sha(MODEL / "model/estimate.py"),
            "solver": {"status": 0, "mip_gap": 0.0},
            "conditional_predicted_score": grade["score"]}


class LadderTests(unittest.TestCase):
    def test_requires_5000_and_a_500_point_model_increase_before_grade(self):
        ledger = initial_ledger()
        solution = verified_solution()
        starting_score = solution["conditional_predicted_score"]
        threshold = ledger["last_predicted_score"] + 499.99
        base_cycles = solution["selected_programs"]["a-p"]["estimated_cycles"]
        solution["selected_programs"]["a-p"]["estimated_cycles"] = (
            base_cycles * (starting_score / threshold) ** 4)
        solution["conditional_predicted_score"] = threshold
        self.assertFalse(screen(solution, ledger)["grade_allowed"])
        with tempfile.TemporaryDirectory() as directory:
            proposal = Path(directory) / "proposal.json"
            proposal.write_text(json.dumps(solution))
            result = run(proposal, Path(directory) / "output")
            self.assertFalse(result["grade_allowed"])
            self.assertEqual(json.loads((Path(directory) / "output/ledger.json").read_text()), ledger)
            self.assertFalse(list(Path(directory).glob("**/*.zip")))
        target = max(5000, ledger["last_predicted_score"] + 500)
        solution["selected_programs"]["a-p"]["estimated_cycles"] *= (threshold / target) ** 4
        solution["conditional_predicted_score"] = target
        self.assertTrue(screen(solution, ledger)["grade_allowed"])
        solution["conditional_predicted_score"] += 1
        with self.assertRaisesRegex(ValueError, "claimed model score"):
            screen(solution, ledger)

    def test_graded_result_must_match_exact_programs(self):
        ledger = initial_ledger()
        solution = verified_solution()
        self.assertEqual(verify_grade(BASE_GRADE, solution, ledger), ledger["last_archived_score"])
        changed = copy.deepcopy(solution)
        changed["selected_programs"]["w-p"]["program_sha256"] = "wrong"
        with self.assertRaisesRegex(ValueError, "selected program changed"):
            verify_grade(BASE_GRADE, changed, ledger)
        changed = copy.deepcopy(solution)
        changed["selected_programs"]["w-p"]["program_sha256"] = sha(BASE_GRADE)
        with self.assertRaises(ValueError):
            screen(changed, ledger)

    def test_archive_needs_500_points_of_real_score(self):
        ledger = initial_ledger()
        self.assertFalse(qualifies_for_archive(ledger["last_archived_score"] + 499.99, ledger))
        self.assertTrue(qualifies_for_archive(ledger["last_archived_score"] + 500, ledger))

    def test_resumes_checked_receipt_without_regrading_after_interrupt(self):
        ledger = initial_ledger()
        solution = verified_solution()
        starting_score = solution["conditional_predicted_score"]
        prediction = ledger["last_predicted_score"] + 500
        solution["selected_programs"]["a-p"]["estimated_cycles"] *= (
            starting_score / prediction) ** 4
        solution["conditional_predicted_score"] = prediction
        fingerprint = hashlib.sha256("-".join(
            solution["selected_programs"][case]["program_sha256"]
            for case in SCORE_CASES).encode()).hexdigest()[:16]
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory)
            grade_path = output / f"attempt-0000-{fingerprint}/grade/grade.json"
            grade_path.parent.mkdir(parents=True)
            shutil.copyfile(BASE_GRADE, grade_path)
            ledger["last_predicted_score"] = prediction
            ledger["attempts"].append({"program_id": fingerprint, "prediction": prediction,
                                       "status": "checked", "grade": str(grade_path),
                                       "real_score": ledger["last_archived_score"]})
            (output / "ledger.json").write_text(json.dumps(ledger))
            proposal = output / "proposal.json"
            proposal.write_text(json.dumps(solution))
            result = run(proposal, output)
            self.assertEqual(result["status"], "checked")
            self.assertEqual(result["official_score"], ledger["last_archived_score"])
            self.assertFalse(list(output.glob("*.zip")))


if __name__ == "__main__":
    unittest.main()
