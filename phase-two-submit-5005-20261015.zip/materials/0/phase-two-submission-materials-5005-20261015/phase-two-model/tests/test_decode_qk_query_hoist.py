import unittest

from model.decode_qk_query_hoist import hoist_group
from model.decode_qk_query_reuse import reuse_group


def view(base, rows, cols, row_stride):
    return {"base": base, "rows": rows, "cols": cols,
            "row_stride": row_stride, "col_stride": 1}


class DecodeQkQueryHoistTest(unittest.TestCase):
    def test_repeated_query_dma_is_hoisted_without_changing_k_order(self):
        commands = []
        for tile in range(2):
            a = 4 * tile + 1
            b = a + 1
            commands.extend((
                {"command": "run", "instruction": {"op": "fill", "dst": 0,
                                                       "len": 32, "value": 0.0}},
                {"command": "async", "token": a, "instruction": {
                    "op": "load", "tensor": 1,
                    "global": view(0, 1, 64, 64),
                    "local": view(32, 1, 64, 64)}},
                {"command": "async", "token": b, "instruction": {
                    "op": "load", "tensor": 2,
                    "global": view(tile * 64 * 128, 64, 32, 128),
                    "local": view(96, 64, 32, 32)}},
                {"command": "wait", "tokens": [a, b]},
                {"command": "run", "instruction": {
                    "op": "mma", "a": 32, "b": 96, "c": 0,
                    "m": 1, "n": 32, "k": 64}},
                {"command": "run", "instruction": {
                    "op": "store", "tensor": 3,
                    "global": view(tile * 32, 1, 32, 64),
                    "local": view(0, 1, 32, 32)}},
            ))
        source = {"sm": 0, "rf_kib": 9, "sh_kib": 0, "commands": commands}
        changed, removed = hoist_group(source, frozenset({2}))
        self.assertEqual(removed, 1)
        self.assertEqual(changed["rf_kib"], 10)
        self.assertEqual(sum(c.get("instruction", {}).get("tensor") == 1
                             for c in changed["commands"]), 1)
        self.assertEqual([c["instruction"]["a"] for c in changed["commands"]
                          if c.get("instruction", {}).get("op") == "mma"],
                         [9 * 256, 9 * 256])
        self.assertEqual([c["instruction"]["global"]["base"]
                          for c in changed["commands"]
                          if c.get("instruction", {}).get("tensor") == 2],
                         [0, 64 * 128])
        waits = [c["tokens"] for c in changed["commands"]
                 if c["command"] == "wait"]
        self.assertEqual(waits, [[7, 2], [6]])

        reused, removed = reuse_group(source, frozenset({2}))
        self.assertEqual(removed, 1)
        self.assertEqual(reused["rf_kib"], source["rf_kib"])
        self.assertEqual([c["instruction"]["a"] for c in reused["commands"]
                          if c.get("instruction", {}).get("op") == "mma"], [32, 32])
        self.assertEqual([c["tokens"] for c in reused["commands"]
                          if c["command"] == "wait"], [[1, 2], [6]])

    def test_k128_tail_reuse_preserves_the_tiny_score_tile(self):
        commands = []
        for tile, (n, query_base, query_local, key_local) in enumerate(
                ((1, 0, 1, 257), (32, 128, 32, 288), (32, 128, 32, 288))):
            left = 2 * tile + 1
            commands.extend((
                {"command": "run", "instruction": {"op": "fill", "dst": 0,
                                                       "len": n, "value": 0.0}},
                {"command": "async", "token": left, "instruction": {
                    "op": "load", "tensor": 1,
                    "global": view(query_base, 1, 128, 128),
                    "local": view(query_local, 1, 128, 128)}},
                {"command": "async", "token": left + 1, "instruction": {
                    "op": "load", "tensor": 2,
                    "global": view(tile * 128 * 512, 128, n, 512),
                    "local": view(key_local, 128, n, n)}},
                {"command": "wait", "tokens": [left, left + 1]},
                {"command": "run", "instruction": {
                    "op": "mma", "a": query_local, "b": key_local, "c": 0,
                    "m": 1, "n": n, "k": 128}},
                {"command": "run", "instruction": {
                    "op": "store", "tensor": 3,
                    "global": view(tile * 32, 1, n, 128),
                    "local": view(0, 1, n, n)}},
            ))
        source = {"sm": 0, "rf_kib": 18, "sh_kib": 0, "commands": commands}
        changed, removed = reuse_group(source, frozenset({2}))
        self.assertEqual(removed, 1)
        self.assertEqual([c["instruction"]["n"] for c in changed["commands"]
                          if c.get("instruction", {}).get("op") == "mma"], [1, 32, 32])
        self.assertEqual([c["tokens"] for c in changed["commands"]
                          if c["command"] == "wait"], [[1, 2], [3, 4], [6]])


if __name__ == "__main__":
    unittest.main()
