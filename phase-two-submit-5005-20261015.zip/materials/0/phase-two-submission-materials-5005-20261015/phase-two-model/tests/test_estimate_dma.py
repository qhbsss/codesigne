import unittest

from model.estimate import InfeasibleProgramError, _validate_dma_destination


class DmaDestinationTests(unittest.TestCase):
    def test_load_destination_requires_contiguous_disjoint_rows(self):
        instruction = {
            "op": "load",
            "global": {"base": 0, "rows": 32, "cols": 112,
                       "row_stride": 1536, "col_stride": 1},
            "local": {"base": 288, "rows": 32, "cols": 112,
                      "row_stride": 1, "col_stride": 32},
        }
        with self.assertRaisesRegex(InfeasibleProgramError, "contiguous rows"):
            _validate_dma_destination(instruction)

    def test_load_source_may_be_strided(self):
        instruction = {
            "op": "load",
            "global": {"base": 0, "rows": 128, "cols": 32,
                       "row_stride": 1, "col_stride": 1536},
            "local": {"base": 288, "rows": 128, "cols": 32,
                      "row_stride": 32, "col_stride": 1},
        }
        _validate_dma_destination(instruction)

    def test_store_destination_requires_contiguous_disjoint_rows(self):
        instruction = {
            "op": "store",
            "global": {"base": 0, "rows": 16, "cols": 16,
                       "row_stride": 1, "col_stride": 16},
            "local": {"base": 0, "rows": 16, "cols": 16,
                      "row_stride": 16, "col_stride": 1},
        }
        with self.assertRaisesRegex(InfeasibleProgramError, "contiguous rows"):
            _validate_dma_destination(instruction)


if __name__ == "__main__":
    unittest.main()
