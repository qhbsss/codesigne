from model.ksplit_screen import _independent, _pack_waves, split_group


def _view(base, rows, cols, row_stride):
    return dict(base=base, rows=rows, cols=cols, row_stride=row_stride, col_stride=1)


def _addresses(view):
    return [view["base"] + row * view["row_stride"] + col * view["col_stride"]
            for row in range(view["rows"]) for col in range(view["cols"])]


def test_k_split_preserves_panel_elements_and_k_order():
    a = dict(op="load", tensor=0, **{"global": _view(5, 2, 4, 9),
                                      "local": _view(4, 2, 4, 4)})
    b = dict(op="load", tensor=1, **{"global": _view(11, 4, 2, 7),
                                      "local": _view(12, 4, 2, 2)})
    mma = dict(op="mma", a=4, b=12, c=0, m=2, n=2, k=4)
    group = dict(sm=0, rf_kib=1, sh_kib=0, commands=[
        dict(command="run", instruction=dict(op="fill", dst=0, len=4, value=0.0)),
        dict(command="async", token=1, instruction=a),
        dict(command="async", token=2, instruction=b),
        dict(command="wait", tokens=[1, 2]),
        dict(command="run", instruction=mma),
    ])
    result, changed = split_group(group, 2)
    assert changed == 1
    chunks = result["commands"][1:]
    assert [chunks[offset + 3]["instruction"]["k"]
            for offset in (0, 4)] == [2, 2]
    assert [chunks[offset + 3]["instruction"]["c"]
            for offset in (0, 4)] == [0, 0]
    for original, offset in ((a, 0), (b, 1)):
        old = _addresses(original["global"])
        split = [_addresses(chunks[pos + offset]["instruction"]["global"])
                 for pos in (0, 4)]
        assert sorted(old) == sorted(split[0] + split[1])
    assert result["rf_kib"] == 1


def test_only_independent_groups_may_be_partitioned():
    def group(sm, base, read_other=False):
        commands = []
        if read_other:
            commands.append(dict(command="run", instruction=dict(
                op="load", tensor=0, **{"global": _view(0, 1, 1, 1),
                                            "local": _view(0, 1, 1, 1)})))
        commands.append(dict(command="run", instruction=dict(
            op="store", tensor=0, **{"global": _view(base, 1, 1, 1),
                                         "local": _view(0, 1, 1, 1)})))
        return dict(sm=sm, rf_kib=33, sh_kib=0, commands=commands)

    hardware = dict(sms=1, rf_kib=64, sh_kib=0, resident_groups=2)
    safe = [group(0, 0), group(0, 2)]
    assert _independent(safe)
    assert len(_pack_waves(safe, hardware)) == 2
    unsafe = [group(0, 0), group(0, 2, read_other=True)]
    assert not _independent(unsafe)
