"""Check line traffic and shared-link accounting without invoking a scorer."""

import unittest

from model.shared_noc_screen import (
    group_credit_path, hbm_queue_service_cycles, service_cycles,
    sh_bank_cycles, wave_sh_port_service, wave_traffic,
)


def load(sm, base):
    return {
        "sm": sm,
        "commands": [{
            "command": "run",
            "instruction": {
                "op": "load",
                "global": {"base": base, "rows": 1, "cols": 16,
                           "row_stride": 16, "col_stride": 1},
            },
        }],
    }


class SharedNocScreenTest(unittest.TestCase):
    def test_two_sms_compete_for_one_global_link(self):
        hardware = {"sms": 2, "hbm_channels": 1,
                    "sm_noc": 256, "global_noc": 128}
        traffic = wave_traffic([load(0, 0), load(1, 16)], hardware)
        self.assertEqual(traffic["read_requests"], 2)
        self.assertEqual(traffic["endpoint_bytes"], 144)
        self.assertEqual(traffic["endpoint_by_sm"], [72, 72])
        self.assertEqual(service_cycles(traffic, hardware)["service_cycles"], 2)
        self.assertEqual(
            service_cycles(traffic, hardware, merge_fraction=0.5)["service_cycles"],
            1,
        )
        self.assertEqual(traffic["read_by_channel"], [2])
        hardware.update(cache_mib=0, hbm_queue=1)
        self.assertEqual(hbm_queue_service_cycles(traffic, hardware), 518)
        hardware["hbm_queue"] = 2
        self.assertEqual(hbm_queue_service_cycles(traffic, hardware), 259)

    def test_shared_dma_uses_local_bank_service_per_coalesced_line(self):
        hardware = {"sh_banks": 2, "shared_ports": 1,
                    "hbm_channels": 8, "cache_mib": 0}
        view = {"base": 0, "rows": 1, "cols": 16,
                "row_stride": 16, "col_stride": 1}
        instruction = {"op": "load_shared", "global": view,
                       "local": dict(view)}
        self.assertEqual(sh_bank_cycles(instruction, hardware), 8)
        instruction["global"] = dict(view, base=15)
        self.assertEqual(sh_bank_cycles(instruction, hardware), 9)
        instruction["global"] = view
        instruction["op"] = "store_shared"
        hardware["shared_ports"] = 2
        self.assertEqual(sh_bank_cycles(instruction, hardware), 4)
        instruction["local"] = dict(view, col_stride=0)
        self.assertEqual(sh_bank_cycles(instruction, hardware), 1)

    def test_shared_bank_path_accounts_for_serial_load_wait_store(self):
        hardware = {"sh_banks": 2, "shared_ports": 1,
                    "hbm_channels": 8, "cache_mib": 0, "sms": 1}
        view = {"base": 0, "rows": 1, "cols": 1024,
                "row_stride": 1024, "col_stride": 1}
        group = {"sm": 0, "commands": [
            {"command": "async", "token": 1,
             "instruction": {"op": "load_shared", "global": view,
                             "local": view}},
            {"command": "wait", "tokens": [1]},
            {"command": "run",
             "instruction": {"op": "store_shared", "global": view,
                             "local": view}},
        ]}
        self.assertEqual(sh_bank_cycles(group["commands"][0]["instruction"], hardware), 512)
        self.assertEqual(wave_sh_port_service([group], hardware), 512)
        self.assertEqual(group_credit_path(group, hardware), 533)
        self.assertEqual(group_credit_path(group, hardware, banked_shared=True), 1025)


if __name__ == "__main__":
    unittest.main()
