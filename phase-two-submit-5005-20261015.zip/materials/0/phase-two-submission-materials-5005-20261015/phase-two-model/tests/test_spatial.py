import json
import tempfile
import unittest
from pathlib import Path

from model.estimate import program_records
from model.spatial import rebalance_program
from model.tool import OFFICIAL, STARTER, command


class SpatialReassignmentTests(unittest.TestCase):
    def test_reassigns_two_groups_per_sm_to_one_group(self):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / "input.jsonl"
            destination = Path(directory) / "output.jsonl"
            with (STARTER / "examples/small-prefill.jsonl").open() as example:
                header = json.loads(next(example))
            header["hardware"].update(sms=8, rf_kib=128)
            wave = {"record": "wave", "groups": [
                {"sm": index % 8, "rf_kib": 56, "sh_kib": 0, "commands": []}
                for index in range(16)]}
            source.write_text("\n".join(json.dumps(item) for item in (header, wave)) + "\n")
            hardware = dict(header["hardware"], sms=16, rf_kib=64,
                            vector=16, sfu=8, p=8, q=16, sh_kib=0,
                            sh_banks=0, sh_tc_bw=0)
            statistics = rebalance_program(source, destination, hardware)
            rewritten = list(program_records(destination))
            self.assertEqual(statistics["changed_group_definitions"], 8)
            self.assertEqual(statistics["expanded_waves"], 1)
            self.assertEqual([group["sm"] for group in rewritten[1]["groups"]],
                             list(range(16)))
            self.assertEqual([group["commands"] for group in rewritten[1]["groups"]],
                             [group["commands"] for group in wave["groups"]])

    def test_rejects_oversubscribed_rf(self):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / "input.jsonl"
            destination = Path(directory) / "output.jsonl"
            with (STARTER / "examples/small-prefill.jsonl").open() as example:
                header = json.loads(next(example))
            wave = {"record": "wave", "groups": [
                {"sm": index % 8, "rf_kib": 56, "sh_kib": 0, "commands": []}
                for index in range(16)]}
            source.write_text("\n".join(json.dumps(item) for item in (header, wave)) + "\n")
            with self.assertRaisesRegex(ValueError, "resident workgroups"):
                rebalance_program(source, destination, dict(header["hardware"], rf_kib=64))

    def test_small_program_has_identical_output(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            original = STARTER / "examples/small-prefill.jsonl"
            with original.open() as source:
                hardware = dict(json.loads(next(source))["hardware"], sms=12,
                                sh_kib=0, sh_banks=0, sh_tc_bw=0)
            rewritten = root / "remapped.jsonl"
            statistics = rebalance_program(original, rewritten, hardware)
            self.assertGreater(statistics["expanded_waves"], 0)
            results = []
            for index, program in enumerate((original, rewritten)):
                command([OFFICIAL, "evaluate", program, 7, root / f"evaluate-{index}"],
                        60, root / f"evaluate-command-{index}.json")
                results.append(json.loads((root / f"evaluate-{index}/result.json").read_text()))
            self.assertTrue(all(result["status"] == "complete" and
                                result["evaluation"]["report"]["power_pass"]
                                for result in results))
            self.assertEqual(results[0]["evaluation"]["output_sha256"],
                             results[1]["evaluation"]["output_sha256"])


if __name__ == "__main__":
    unittest.main()
