import unittest

from model.fused_panel_reuse import reuse_group


def view(base, rows, cols, row_stride):
    return {"base": base, "rows": rows, "cols": cols,
            "row_stride": row_stride, "col_stride": 1}


def tile(row):
    base = row * 4
    return [
        {"command": "run", "instruction": {"op": "fill", "dst": 0,
                                               "len": 4, "value": 0.0}},
        {"command": "async", "token": 10 + row * 2,
         "instruction": {"op": "load", "tensor": 0,
                         "global": view(base, 2, 2, 2),
                         "local": view(4, 2, 2, 2)}},
        {"command": "async", "token": 11 + row * 2,
         "instruction": {"op": "load", "tensor": 1,
                         "global": view(0, 2, 2, 2),
                         "local": view(8, 2, 2, 2)}},
        {"command": "wait", "tokens": [10 + row * 2, 11 + row * 2]},
        {"command": "run", "instruction": {"op": "mma", "a": 4, "b": 8,
                                               "c": 0, "m": 2, "n": 2, "k": 2}},
        {"command": "run", "instruction": {"op": "load", "tensor": 2,
                                               "global": view(0, 1, 4, 4),
                                               "local": view(12, 1, 4, 4)}},
        {"command": "run", "instruction": {"op": "vector", "kind": "add",
                                               "dst": 0, "len": 4,
                                               "a": {"kind": "reg", "base": 0,
                                                     "stride": 1},
                                               "b": {"kind": "reg", "base": 12,
                                                     "stride": 1}}},
        {"command": "run", "instruction": {"op": "store", "tensor": 3,
                                               "global": view(base, 2, 2, 2),
                                               "local": view(0, 2, 2, 2)}},
    ]


class FusedPanelReuseTest(unittest.TestCase):
    def test_second_accumulator_and_epilogue_are_relocated(self):
        group = {"sm": 0, "rf_kib": 1, "sh_kib": 0,
                 "commands": tile(0) + tile(1)}
        transformed, removed = reuse_group(group, "b")
        self.assertEqual(removed, 1)
        self.assertEqual(transformed["rf_kib"], 2)
        instructions = [command["instruction"] for command in transformed["commands"]
                        if "instruction" in command]
        self.assertEqual([i["c"] for i in instructions if i["op"] == "mma"], [0, 256])
        vectors = [i for i in instructions if i["op"] == "vector"]
        self.assertEqual([i["dst"] for i in vectors], [0, 256])
        self.assertEqual([i["b"]["base"] for i in vectors], [12, 12])
        stores = [i for i in instructions if i["op"] == "store"]
        self.assertEqual([i["global"]["base"] for i in stores], [0, 4])
        self.assertEqual([i["local"]["base"] for i in stores], [0, 256])
        self.assertEqual(sum(i["op"] == "load" and i["tensor"] == 1
                             for i in instructions), 1)


if __name__ == "__main__":
    unittest.main()
