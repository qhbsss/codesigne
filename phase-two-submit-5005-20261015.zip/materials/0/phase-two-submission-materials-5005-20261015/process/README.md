# Redacted native Codex event exports

These JSONL files preserve selected original event objects and their order within each session.
The source sessions were read only. This is a frozen prefix of live logs through
2026-10-15T13:05:00Z; later messages and unavailable sessions are not represented.
No raw session file is included here.

## Selection and redaction

Kept: visible user and assistant `response_item.message` content; text-only
tool calls and outputs (`custom_tool_call`, `function_call` and corresponding outputs);
agent collaboration messages with `input_text`; and existing numeric `token_usage_record` fields.
Dropped: system/developer messages, reasoning, encrypted content, compaction summaries,
world state, turn context, duplicated completion events, hidden metadata and non-text payloads.
Text fields were recursively redacted for credential patterns, URLs, email addresses,
internal domains, home paths, IP addresses, phone numbers and opaque high-entropy blobs.
Redactions use placeholders; no record, counter or command was invented. The original
native sessions should be retained locally for a full private audit.
An automated structural and residual-pattern scan passed for every output file before
writing and again after writing. This does not certify the absence of every possible
unmarked private fact; review the exported text before external publication.

Exporter SHA256: `ad4c51acedc9be8b0655a75248c6de4fd7596041cabe4d4c3c5c85fada28bca7`.

## Files and provenance

The source paths below are relative to `~/.codex/sessions/`; each source SHA256 covers
only the newline-terminated prefix at or before the cutoff. Source files may keep growing.
Output SHA256 covers the complete exported JSONL file.

| Export | Source | Source prefix bytes | Events | Output bytes | Source prefix SHA256 | Output SHA256 |
| --- | --- | ---: | ---: | ---: | --- | --- |
| `codex-root.redacted.jsonl` | `2026/10/12/rollout-2026-10-12T19-00-55-01a12fc5-cfcc-7391-96ac-341d29a3ea1b.jsonl` | 67535056 | 10370 | 14859390 | `0be08028bbf9c429a3dd9c69ed177b4860b18dd902b66ffae8b2274572708aa4` | `a2eb4e72b3596a7d80cd3f1e92b25bc5e8007378854fbcb1854307389980ee4c` |
| `codex-decode-dataflow.redacted.jsonl` | `2026/10/14/rollout-2026-10-14T16-37-41-01a13b46-db34-7931-bd9e-f2e6743f96a8.jsonl` | 6006529 | 820 | 1323615 | `01c686ec40da5edb302f9ec8b92c4252ecee5f46ee613caf1ffe6079f03e9575` | `fd3d9238ee3051e94166dc3c32a117d277ec225ae08bce77d3763a7aad743c2f` |
| `codex-noc-model.redacted.jsonl` | `2026/10/14/rollout-2026-10-14T16-37-55-01a13b47-11a4-7021-b9d2-20c09902c8da.jsonl` | 9550486 | 742 | 1292161 | `f38664a4c951e37ffd8b2ec9f82e58eb492b0f7b493dfc5e20a580cd82cafd5c` | `80e80a62732be63bec69d8f1a8f7109c37ea30b463e143303f3b2ff39fbba93b` |
| `codex-prefill-search.redacted.jsonl` | `2026/10/14/rollout-2026-10-14T16-38-41-01a13b47-c30a-7cc0-ac1e-8fbb4b108349.jsonl` | 11732512 | 845 | 1913318 | `c8dcf7afc7501ea7e523c759cef99a149aac1dbf65e4e7b057180999cf533141` | `beec018cea1dd1ebb4127ee62acb316ce0c5d06cb37ced32551c4ee3517fbb93` |
| `codex-score-audit.redacted.jsonl` | `2026/10/14/rollout-2026-10-14T20-12-47-01a13c0b-c961-7460-94e6-c67c26a6d830.jsonl` | 2458354 | 149 | 520794 | `a5152e86d93754dabfb20994ade25774f6a2213c9b624f61dd4ca2b16facdfc3` | `27199ae98eeaab1a17fbcddf3f49281d44aa7210de4f1b1e6214a7cc3fb03023` |
| `codex-gate-audit.redacted.jsonl` | `2026/10/14/rollout-2026-10-14T20-13-08-01a13c0c-1aa4-7b90-8262-a8147524fec8.jsonl` | 1796071 | 150 | 410719 | `73f7b89b655275f12cdc6ea63e55b7bd426b1c5b8c6352906f19b48dc914e6cd` | `a3266f0abfaf86a297ad7fef90c86be47a057eecdcf13590f88080fcd618e0b0` |
| `codex-disk-audit.redacted.jsonl` | `2026/10/14/rollout-2026-10-14T20-13-14-01a13c0c-3094-70f1-8d1a-7ff549a103b9.jsonl` | 931834 | 53 | 188216 | `b10901b91a1a804a4cb24fb3378b16eb293d38fe137a699bd9aac8dc22c98438` | `2b325c4e9dca2fb09f2ecad70a934f0bdf46149797fe74cea6317a6f3a7e2ce5` |

Total exported JSONL: **20508213 bytes** across 7 files.

The root session covers the Phase Two search and follow-up verification. Three Oct 14
search subagents cover decode dataflow, NoC modeling and prefill search; three later
subagents cover score, model-gate and disk audits. Older Claude sessions and the unrelated
short Codex Oct 13 session are omitted; their absence limits completeness for earlier work.
Token counters are copied only where present and keep their original scope. Missing
counters are not reported as zero.

## Redaction counts

Counts describe replacements in visible fields, never secret values.

| Export | Categories and counts |
| --- | --- |
| `codex-root.redacted.jsonl` | credential_assignment: 273, home_path: 3932, ip_address: 16, opaque_blob: 1017, phone: 43, url: 56 |
| `codex-decode-dataflow.redacted.jsonl` | credential_assignment: 33, home_path: 165, ip_address: 2, opaque_blob: 24, phone: 1, url: 3 |
| `codex-noc-model.redacted.jsonl` | credential_assignment: 7, home_path: 164, opaque_blob: 47, phone: 9, url: 2 |
| `codex-prefill-search.redacted.jsonl` | credential_assignment: 40, home_path: 283, ip_address: 2, opaque_blob: 70, phone: 9, url: 3 |
| `codex-score-audit.redacted.jsonl` | credential_assignment: 1, home_path: 191, opaque_blob: 134, phone: 4, private_key_content: 3, url: 20 |
| `codex-gate-audit.redacted.jsonl` | home_path: 102, opaque_blob: 43, url: 10 |
| `codex-disk-audit.redacted.jsonl` | home_path: 65, opaque_blob: 35, phone: 2, url: 11 |
