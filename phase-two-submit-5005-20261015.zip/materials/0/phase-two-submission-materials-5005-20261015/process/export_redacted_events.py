#!/usr/bin/env python3
"""Export selected Codex JSONL events without private or internal payloads.

This script reads the original session files. It never changes them and only
writes a filtered export after checking the complete output in memory.
"""

from __future__ import annotations

import hashlib
import json
import math
import re
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path


SESSION_ROOT = Path.home() / ".codex" / "sessions"
OUTPUT_DIR = Path(__file__).resolve().parent
CUTOFF = datetime.fromisoformat("2026-10-15T13:05:00+00:00")
SOURCES = (
    (
        "codex-root",
        "2026/10/12/rollout-2026-10-12T19-00-55-01a12fc5-cfcc-7391-96ac-341d29a3ea1b.jsonl",
    ),
    (
        "codex-decode-dataflow",
        "2026/10/14/rollout-2026-10-14T16-37-41-01a13b46-db34-7931-bd9e-f2e6743f96a8.jsonl",
    ),
    (
        "codex-noc-model",
        "2026/10/14/rollout-2026-10-14T16-37-55-01a13b47-11a4-7021-b9d2-20c09902c8da.jsonl",
    ),
    (
        "codex-prefill-search",
        "2026/10/14/rollout-2026-10-14T16-38-41-01a13b47-c30a-7cc0-ac1e-8fbb4b108349.jsonl",
    ),
    (
        "codex-score-audit",
        "2026/10/14/rollout-2026-10-14T20-12-47-01a13c0b-c961-7460-94e6-c67c26a6d830.jsonl",
    ),
    (
        "codex-gate-audit",
        "2026/10/14/rollout-2026-10-14T20-13-08-01a13c0c-1aa4-7b90-8262-a8147524fec8.jsonl",
    ),
    (
        "codex-disk-audit",
        "2026/10/14/rollout-2026-10-14T20-13-14-01a13c0c-3094-70f1-8d1a-7ff549a103b9.jsonl",
    ),
)


PEM_MARKER = re.compile(r"-----BEGIN [^-]*PRIVATE KEY-----", re.I)
URL = re.compile(r"\b(?:https?|wss?)://[^\s<>\"'`]+", re.I)
BEARER = re.compile(r"\bBearer\s+[A-Za-z0-9._~+/-]{8,}", re.I)
KNOWN_TOKEN = re.compile(
    r"\b(?:sk-(?:proj-)?[A-Za-z0-9_-]{16,}|"
    r"(?:AKIA|ASIA)[A-Z0-9]{16}|"
    r"(?:ghp|gho|ghu|ghs|ghr|github_pat)_[A-Za-z0-9_]{20,}|"
    r"xox[baprs]-[A-Za-z0-9-]{16,})\b"
)
JWT = re.compile(
    r"\beyJ[A-Za-z0-9_-]{16,}\.eyJ[A-Za-z0-9_-]{16,}\."
    r"[A-Za-z0-9_-]{8,}\b"
)
ASSIGNMENT = re.compile(
    r"(?i)(\b(?:[A-Z0-9_]*(?:API[_-]?KEY|ACCESS[_-]?KEY|SECRET|TOKEN|"
    r"PASSWORD|PASSWD)|AUTHORIZATION|COOKIE)\b(?:\\*[\"'])?\s*[:=]\s*"
    r"(?:\\*[\"'])?)([^\s,;}{\\\"']{4,})"
)
CLI_SECRET = re.compile(
    r"(?i)(--(?:api-key|access-key|token|password|secret)\s+)([^\s\"']{4,})"
)
QUERY_SECRET = re.compile(
    r"(?i)([?&](?:access[_-]?token|api[_-]?key|secret|password|signature|"
    r"session[_-]?token|auth|code)=)([^&#\s]{4,})"
)
EMAIL = re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b")
INTERNAL_DOMAIN = re.compile(
    r"(?<![A-Za-z0-9.-])(?:[A-Za-z0-9-]+\.)*"
    r"(?:alibaba-inc\.com|antfin\.com|dingtalk\.com|aliyun-inc\.com|"
    r"ts\.net|[A-Za-z0-9-]+\.(?:internal|corp))(?![A-Za-z0-9.-])",
    re.I,
)
HOME_PATH = re.compile(r"(?<![A-Za-z0-9])/(?:home|Users)/[^/\s\"']+")
IPV4 = re.compile(
    r"(?<![A-Za-z0-9.])(?:[0-9]{1,3}\.){3}[0-9]{1,3}(?![A-Za-z0-9.])"
)
PHONE_CN = re.compile(r"(?<![0-9])1[3-9][0-9]{9}(?![0-9])")
LONG_BLOB = re.compile(r"(?<![A-Za-z0-9_])[A-Za-z0-9_+/=-]{100,}(?![A-Za-z0-9_])")


def entropy(value: str) -> float:
    counts = Counter(value)
    return -sum((n / len(value)) * math.log2(n / len(value)) for n in counts.values())


def redact_text(value: str, counts: Counter[str]) -> str:
    if PEM_MARKER.search(value):
        counts["private_key_content"] += 1
        return "[REDACTED_PRIVATE_KEY_CONTENT]"

    replacements = (
        (URL, "[REDACTED_URL]", "url"),
        (BEARER, "Bearer [REDACTED_CREDENTIAL]", "bearer"),
        (KNOWN_TOKEN, "[REDACTED_CREDENTIAL]", "known_token"),
        (JWT, "[REDACTED_CREDENTIAL]", "jwt"),
        (EMAIL, "[REDACTED_EMAIL]", "email"),
        (INTERNAL_DOMAIN, "[REDACTED_INTERNAL_DOMAIN]", "internal_domain"),
        (HOME_PATH, "[HOME]", "home_path"),
        (IPV4, "[REDACTED_IP]", "ip_address"),
        (PHONE_CN, "[REDACTED_PHONE]", "phone"),
    )
    for pattern, replacement, label in replacements:
        value, n = pattern.subn(replacement, value)
        counts[label] += n

    for pattern, label in (
        (ASSIGNMENT, "credential_assignment"),
        (CLI_SECRET, "cli_credential"),
        (QUERY_SECRET, "query_credential"),
    ):
        value, n = pattern.subn(lambda m: m.group(1) + "[REDACTED_CREDENTIAL]", value)
        counts[label] += n

    def redact_blob(match: re.Match[str]) -> str:
        blob = match.group()
        if entropy(blob) < 4.25:
            return blob
        counts["opaque_blob"] += 1
        return "[REDACTED_OPAQUE_BLOB]"

    return LONG_BLOB.sub(redact_blob, value)


def redact_all(value: object, counts: Counter[str]) -> object:
    if isinstance(value, str):
        return redact_text(value, counts)
    if isinstance(value, list):
        return [redact_all(item, counts) for item in value]
    if isinstance(value, dict):
        return {key: redact_all(item, counts) for key, item in value.items()}
    return value


def text_blocks(content: object, kinds: tuple[str, ...]) -> list[dict[str, str]]:
    if not isinstance(content, list):
        return []
    return [
        {"type": item["type"], "text": item["text"]}
        for item in content
        if isinstance(item, dict)
        and item.get("type") in kinds
        and isinstance(item.get("text"), str)
    ]


def numeric_tree(value: object) -> object:
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return value
    if isinstance(value, dict):
        result = {key: numeric_tree(item) for key, item in value.items()}
        return {key: item for key, item in result.items() if item is not None}
    if isinstance(value, list):
        return [item for x in value if (item := numeric_tree(x)) is not None]
    return None


def project(row: dict) -> dict | None:
    record_type = row.get("type")
    payload = row.get("payload")
    if not isinstance(payload, dict):
        return None

    if record_type == "response_item":
        kind = payload.get("type")
        if kind == "message":
            if payload.get("role") not in ("user", "assistant"):
                return None
            if payload.get("role") == "assistant" and payload.get("phase") not in (
                None,
                "commentary",
                "final_answer",
            ):
                return None
            visible = {
                "type": kind,
                "role": payload["role"],
                "content": text_blocks(payload.get("content"), ("input_text", "output_text")),
            }
            if "phase" in payload:
                visible["phase"] = payload["phase"]
        elif kind == "agent_message":
            visible = {
                "type": kind,
                "author": payload.get("author"),
                "recipient": payload.get("recipient"),
                "content": text_blocks(payload.get("content"), ("input_text",)),
            }
        elif kind in ("custom_tool_call", "function_call"):
            visible = {"type": kind}
            for key in ("name", "call_id", "status", "input", "arguments"):
                if key in payload:
                    visible[key] = payload[key]
        elif kind in ("custom_tool_call_output", "function_call_output"):
            visible = {"type": kind}
            if "call_id" in payload:
                visible["call_id"] = payload["call_id"]
            output = payload.get("output")
            visible["output"] = (
                text_blocks(output, ("input_text", "output_text"))
                if isinstance(output, list)
                else output
                if isinstance(output, str)
                else "[REDACTED_NON_TEXT_OUTPUT]"
            )
        else:
            return None
    elif record_type == "token_usage_record":
        visible = {}
        for key in ("response_id", "root_turn_id", "session_id", "thread_id", "turn_id"):
            if key in payload:
                visible[key] = payload[key]
        for key in ("usage", "turn_token_usage", "thread_token_usage"):
            if key in payload:
                visible[key] = numeric_tree(payload[key])
    else:
        return None

    return {
        "timestamp": row.get("timestamp"),
        "type": record_type,
        "payload": visible,
    }


SCAN_PATTERNS = {
    "private_key": PEM_MARKER,
    "url": URL,
    "bearer": BEARER,
    "known_token": KNOWN_TOKEN,
    "jwt": JWT,
    "credential_assignment": ASSIGNMENT,
    "cli_credential": CLI_SECRET,
    "query_credential": QUERY_SECRET,
    "email": EMAIL,
    "internal_domain": INTERNAL_DOMAIN,
    "home_path": HOME_PATH,
    "ip_address": IPV4,
    "phone": PHONE_CN,
}


def has_residual(pattern_name: str, pattern: re.Pattern[str], value: str) -> bool:
    for match in pattern.finditer(value):
        if pattern_name in (
            "credential_assignment",
            "cli_credential",
            "query_credential",
        ) and match.group(2) == "[REDACTED_CREDENTIAL]":
            continue
        return True
    return False


def visible_strings(value: object):
    if isinstance(value, str):
        yield value
    elif isinstance(value, list):
        for item in value:
            yield from visible_strings(item)
    elif isinstance(value, dict):
        for item in value.values():
            yield from visible_strings(item)


def validate_output(data: bytes) -> tuple[int, str | None, str | None]:
    count = 0
    first = last = None
    for line_index, line in enumerate(data.splitlines(), 1):
        row = json.loads(line)
        if row.get("type") not in ("response_item", "token_usage_record"):
            raise ValueError("unexpected event type in export")
        payload = row.get("payload")
        if not isinstance(payload, dict):
            raise ValueError("non-object payload in export")
        kind = payload.get("type")
        if row["type"] == "response_item" and kind not in (
            "message",
            "agent_message",
            "custom_tool_call",
            "custom_tool_call_output",
            "function_call",
            "function_call_output",
        ):
            raise ValueError("internal response item in export")
        if kind == "message" and payload.get("role") not in ("user", "assistant"):
            raise ValueError("system or developer message in export")
        if kind == "message" and payload.get("phase") not in (
            None,
            "commentary",
            "final_answer",
        ):
            raise ValueError("non-visible assistant phase in export")
        for forbidden in ("encrypted_content", "reasoning", "base_instructions", "summary"):
            if forbidden in payload:
                raise ValueError("internal field in export")
        for value in visible_strings(payload):
            for name, pattern in SCAN_PATTERNS.items():
                if has_residual(name, pattern, value) or has_residual(
                    name, pattern, value.replace('\\"', '"')
                ):
                    raise ValueError(f"sensitive pattern remains: {name} at export event {line_index}")
            for match in LONG_BLOB.finditer(value):
                if entropy(match.group()) >= 4.25:
                    raise ValueError("opaque high-entropy blob remains")
        count += 1
        timestamp = row.get("timestamp")
        if isinstance(timestamp, str):
            first = first or timestamp
            last = timestamp
    return count, first, last


def read_and_project(source: Path) -> tuple[bytes, dict, Counter[str]]:
    output = bytearray()
    redactions: Counter[str] = Counter()
    source_hash = hashlib.sha256()
    source_bytes = 0
    source_lines = 0
    selected = Counter()
    first_source = last_source = None
    with source.open("rb") as reader:
        for raw in reader:
            if not raw.endswith(b"\n"):
                break  # a live session may be appending a partial last line
            row = json.loads(raw)
            timestamp = row.get("timestamp")
            if not isinstance(timestamp, str):
                raise ValueError("source event lacks a timestamp")
            time = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
            if time > CUTOFF:
                break
            source_hash.update(raw)
            source_bytes += len(raw)
            source_lines += 1
            first_source = first_source or timestamp
            last_source = timestamp
            visible = project(row)
            if visible is None:
                continue
            visible = redact_all(visible, redactions)
            output.extend((json.dumps(visible, ensure_ascii=False, separators=(",", ":")) + "\n").encode())
            selected[visible["payload"].get("type", visible["type"])] += 1
    data = bytes(output)
    verified_count, first_output, last_output = validate_output(data)
    info = {
        "source_prefix_bytes": source_bytes,
        "source_prefix_sha256": source_hash.hexdigest(),
        "source_lines": source_lines,
        "source_first_timestamp": first_source,
        "source_last_timestamp": last_source,
        "output_bytes": len(data),
        "output_sha256": hashlib.sha256(data).hexdigest(),
        "output_events": verified_count,
        "output_first_timestamp": first_output,
        "output_last_timestamp": last_output,
        "selected_types": dict(selected),
    }
    return data, info, redactions


def main() -> None:
    if not OUTPUT_DIR.is_dir():
        raise ValueError("output directory does not exist")
    if any(OUTPUT_DIR.glob("*.redacted.jsonl")):
        raise ValueError("export files already exist; refusing to overwrite")

    pending = []
    for alias, relative in SOURCES:
        source = SESSION_ROOT / relative
        if not source.is_file():
            raise FileNotFoundError(source)
        data, info, redactions = read_and_project(source)
        pending.append((alias, relative, data, info, redactions))

    # Nothing is written until every selected source passes the structural and
    # credential-pattern scan above.
    for alias, _, data, _, _ in pending:
        target = OUTPUT_DIR / f"{alias}.redacted.jsonl"
        with target.open("xb") as writer:
            writer.write(data)
        if hashlib.sha256(target.read_bytes()).digest() != hashlib.sha256(data).digest():
            raise ValueError(f"written export differs: {alias}")
        validate_output(target.read_bytes())

    script_sha = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    lines = [
        "# Redacted native Codex event exports",
        "",
        "These JSONL files preserve selected original event objects and their order within each session.",
        "The source sessions were read only. This is a frozen prefix of live logs through",
        f"{CUTOFF.isoformat().replace('+00:00', 'Z')}; later messages and unavailable sessions are not represented.",
        "No raw session file is included here.",
        "",
        "## Selection and redaction",
        "",
        "Kept: visible user and assistant `response_item.message` content; text-only",
        "tool calls and outputs (`custom_tool_call`, `function_call` and corresponding outputs);",
        "agent collaboration messages with `input_text`; and existing numeric `token_usage_record` fields.",
        "Dropped: system/developer messages, reasoning, encrypted content, compaction summaries,",
        "world state, turn context, duplicated completion events, hidden metadata and non-text payloads.",
        "Text fields were recursively redacted for credential patterns, URLs, email addresses,",
        "internal domains, home paths, IP addresses, phone numbers and opaque high-entropy blobs.",
        "Redactions use placeholders; no record, counter or command was invented. The original",
        "native sessions should be retained locally for a full private audit.",
        "An automated structural and residual-pattern scan passed for every output file before",
        "writing and again after writing. This does not certify the absence of every possible",
        "unmarked private fact; review the exported text before external publication.",
        "",
        f"Exporter SHA256: `{script_sha}`.",
        "",
        "## Files and provenance",
        "",
        "The source paths below are relative to `~/.codex/sessions/`; each source SHA256 covers",
        "only the newline-terminated prefix at or before the cutoff. Source files may keep growing.",
        "Output SHA256 covers the complete exported JSONL file.",
        "",
        "| Export | Source | Source prefix bytes | Events | Output bytes | Source prefix SHA256 | Output SHA256 |",
        "| --- | --- | ---: | ---: | ---: | --- | --- |",
    ]
    total_bytes = 0
    for alias, relative, _, info, _ in pending:
        total_bytes += info["output_bytes"]
        lines.append(
            f"| `{alias}.redacted.jsonl` | `{relative}` | {info['source_prefix_bytes']} | "
            f"{info['output_events']} | {info['output_bytes']} | "
            f"`{info['source_prefix_sha256']}` | `{info['output_sha256']}` |"
        )
    lines += [
        "",
        f"Total exported JSONL: **{total_bytes} bytes** across {len(pending)} files.",
        "",
        "The root session covers the Phase Two search and follow-up verification. Three Oct 14",
        "search subagents cover decode dataflow, NoC modeling and prefill search; three later",
        "subagents cover score, model-gate and disk audits. Older Claude sessions and the unrelated",
        "short Codex Oct 13 session are omitted; their absence limits completeness for earlier work.",
        "Token counters are copied only where present and keep their original scope. Missing",
        "counters are not reported as zero.",
        "",
        "## Redaction counts",
        "",
        "Counts describe replacements in visible fields, never secret values.",
        "",
        "| Export | Categories and counts |",
        "| --- | --- |",
    ]
    for alias, _, _, _, redactions in pending:
        summary = ", ".join(f"{key}: {redactions[key]}" for key in sorted(redactions) if redactions[key])
        lines.append(f"| `{alias}.redacted.jsonl` | {summary or 'none'} |")
    lines.append("")
    (OUTPUT_DIR / "README.md").write_text("\n".join(lines), encoding="utf-8")
    print(f"Exported {len(pending)} redacted session files, {total_bytes} bytes; all scans passed.")


if __name__ == "__main__":
    main()
