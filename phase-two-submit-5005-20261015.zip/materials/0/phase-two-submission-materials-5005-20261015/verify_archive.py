#!/usr/bin/env python3
"""Verify the packaged five-case local score, model gate, and ZIP layout."""

import hashlib
import json
import math
import stat
import sys
import zipfile
from pathlib import Path, PurePosixPath


CASES = ("w-p", "a-p", "w-d1", "w-d16", "w-d4l")
MATERIALS = "materials/0/phase-two-submission-materials-5005-20261015/"
RUST_SOURCES = (
    "compact.rs", "explore.rs", "bin/vnext-explore.rs", "v09_hardware.rs",
    "v09_memory.rs", "v09_schedule.rs", "v09_submission.rs",
    "bin/vnext-concurrent.rs", "main.rs", "bin/vnext-release.rs", "lib.rs",
    "source.rs", "hardware.rs", "isa.rs", "machine.rs", "timing.rs",
    "shared.rs", "power.rs", "baseline.rs", "reference.rs", "submission.rs",
)


def read_json(archive, path):
    return json.loads(archive.read(path))


def digest(data):
    return hashlib.sha256(data).hexdigest()


def check(path):
    if Path(path).stat().st_size > 256 * 1024**2:
        raise ValueError("ZIP exceeds 256 MiB")
    with zipfile.ZipFile(path) as archive:
        entries = archive.infolist()
        names = [entry.filename for entry in entries]
        assert len(entries) <= 10000 and len(names) == len(set(names))
        assert sum(entry.file_size for entry in entries) <= 1024**3
        for entry in entries:
            parts = PurePosixPath(entry.filename).parts
            assert parts and all(part not in ("", ".", "..") for part in parts)
            assert not entry.filename.startswith("/")
            assert not (entry.flag_bits & 1)
            assert not stat.S_ISLNK(entry.external_attr >> 16)
        assert archive.testzip() is None

        grade = read_json(archive, "selftest/grade.json")
        contract = read_json(archive, "selftest/contract/result.json")
        summary = read_json(archive, "selftest/workers/summary.json")
        gate = read_json(archive, MATERIALS + "selection/screen/screen.json")
        gate_spec = read_json(archive, MATERIALS + "selection/screen-spec.json")
        base = read_json(archive, MATERIALS + "selection/base-solution.json")
        retarget = read_json(archive, MATERIALS + "selection/retarget-spec.json")
        manifest = read_json(archive, MATERIALS + "selection/materialized/manifest.json")
        direct = read_json(archive, MATERIALS + "selection/direct-grade/result.json")
        hardware = read_json(archive, MATERIALS + "hardware.json")
        archive.read(MATERIALS + "README.md")

        assert grade["status"] == summary["status"] == direct["status"] == "complete"
        assert summary["all_checked"] and summary["all_feasible"]
        assert grade["seed"] == direct["seed"] == contract["seed"] == 7
        assert grade["score"] >= 5000
        assert grade["hardware"] == hardware
        assert grade["contract"] == direct["contract"] == contract["contract"]
        assert grade["model"] == direct["model"] == contract["model"]
        assert grade["source_sha256"] == direct["source_sha256"] == contract["source_sha256"]
        assert set(grade["cases"]) == set(contract["evaluation"]["cases"]) == set(CASES)
        source_hash = hashlib.sha256()
        source_hash.update(b"phase-two-compact-v2")
        for name in RUST_SOURCES:
            source_hash.update(archive.read(MATERIALS + "phase-two-starter/source/src/" + name))
        for name in ("Cargo.toml", "Cargo.lock"):
            source_hash.update(archive.read(MATERIALS + "phase-two-starter/source/" + name))
        assert source_hash.hexdigest() == grade["source_sha256"]

        selection = gate["results"]
        assert len(selection) == 1
        choice = selection[0]
        assert gate["target_score"] == gate_spec["target_score"] == retarget["target_score"] == 5000
        assert choice["completed"] and choice["feasible"] and choice["meets_grade_gate"]
        assert choice["conditional_predicted_score"] >= 5000
        assert choice["name"] == gate_spec["hardware_options"][0]["name"]
        assert gate_spec["hardware_options"] == retarget["hardware_choices"]
        assert retarget["hardware_choices"][0]["hardware"] == hardware
        assert choice["area_au"] <= 100
        assert digest(archive.read(MATERIALS + "selection/screen-spec.json")) == gate["spec_sha256"]
        assert digest(archive.read(MATERIALS + "selection/base-solution.json")) == gate["base_solution_sha256"]
        assert digest(archive.read(MATERIALS + "phase-two-model/model/estimate.py")) == gate["estimator_sha256"]

        by_case = {row["case"]: row for row in manifest}
        assert len(manifest) == len(CASES) and set(by_case) == set(CASES)
        assert len(direct["evaluation"]["evaluations"]) == len(CASES)
        actual_log = predicted_log = 0.0
        for case, direct_case in zip(CASES, direct["evaluation"]["evaluations"]):
            program_path = f"programs/{case}.jsonl"
            program = archive.read(program_path)
            assert len(program) <= 128 * 1024**2
            source = archive.read(MATERIALS + f"selection/source-programs/{case}.jsonl")
            program_sha, source_sha = digest(program), digest(source)
            row = by_case[case]
            receipt = grade["cases"][case]
            result = read_json(archive, f"selftest/workers/{case}/evaluation/result.json")
            evaluation = result["evaluation"]
            reference = contract["evaluation"]["cases"][case]
            header = json.loads(program.split(b"\n", 1)[0])

            assert source_sha == gate["source_program_sha256"][case] == row["source_sha256"]
            assert source_sha == base["selected_programs"][case]["program_sha256"]
            assert program_sha == row["program_sha256"] == receipt["program_sha256"]
            assert program_sha == evaluation["program_sha256"] == direct_case["program_sha256"]
            assert result["status"] == "complete" and result["error"] is None
            assert result["seed"] == 7 and result["source_sha256"] == grade["source_sha256"]
            assert result["contract"] == grade["contract"] and result["model"] == grade["model"]
            assert header == evaluation["header"] == direct_case["header"]
            assert header["hardware"] == hardware
            assert all(header[key] == reference[key] for key in ("shape", "batch", "decode"))
            assert evaluation["comparison"]["max_scaled"] <= 1
            assert direct_case["comparison"]["max_scaled"] <= 1
            assert evaluation["report"]["power_pass"] and direct_case["report"]["power_pass"]
            assert evaluation["report"]["area_au"] <= 100
            cycles = evaluation["report"]["stats"]["cycles"]
            assert cycles == receipt["cycles"] == direct_case["report"]["stats"]["cycles"]
            assert cycles > 0 and choice["predicted_cycles"][case] > 0
            actual_log += reference["weight"] * math.log(reference["reference_cycles"] / cycles)
            predicted_log += reference["weight"] * math.log(
                reference["reference_cycles"] / choice["predicted_cycles"][case]
            )
        assert math.isclose(grade["score"], 1000 * math.exp(actual_log), rel_tol=1e-12)
        assert math.isclose(direct["official_score"], grade["score"], rel_tol=1e-12)
        assert math.isclose(choice["conditional_predicted_score"],
                            1000 * math.exp(predicted_log), rel_tol=1e-12)
        print(f"Verified {len(entries)} entries; local seed-7 score "
              f"{grade['score']:.9f}; model gate {choice['conditional_predicted_score']:.9f}")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: python3 verify_archive.py SUBMISSION.zip")
    check(sys.argv[1])
