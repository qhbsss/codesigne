#!/usr/bin/env python3
"""Screen the five archived source programs, then recreate the final JSONL files.

This script uses the included approximate model and never calls the evaluator.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import shutil
import sys
import zipfile
from pathlib import Path


CASES = ("w-p", "a-p", "w-d1", "w-d16", "w-d4l")
MATERIALS = Path(__file__).resolve().parent
SELECTION = MATERIALS / "selection"


def read_json(path: Path):
    return json.loads(path.read_text())


def sha256(path: Path) -> str:
    with path.open("rb") as source:
        return hashlib.file_digest(source, "sha256").hexdigest()


def check_archived_programs(location: Path, expected: dict[str, str]) -> None:
    """Optionally compare a ZIP or an extracted ZIP's root programs directory."""
    if location.is_file():
        with zipfile.ZipFile(location) as archive:
            names = archive.namelist()
            for case in CASES:
                member = f"programs/{case}.jsonl"
                if names.count(member) != 1:
                    raise ValueError(f"ZIP must contain one {member}")
                if hashlib.sha256(archive.read(member)).hexdigest() != expected[case]:
                    raise ValueError(f"ZIP program SHA differs: {case}")
    else:
        directory = location / "programs" if (location / "programs").is_dir() else location
        for case in CASES:
            if sha256(directory / f"{case}.jsonl") != expected[case]:
                raise ValueError(f"extracted program SHA differs: {case}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output_dir", type=Path, help="new directory for five final JSONL files")
    parser.add_argument("--zip-programs", type=Path,
                        help="optional submission ZIP, extracted ZIP root, or programs directory")
    args = parser.parse_args()
    output = args.output_dir
    if output.exists() or output.is_symlink():
        raise ValueError(f"output directory already exists: {output}")

    hardware = read_json(MATERIALS / "hardware.json")
    base_path = SELECTION / "base-solution.json"
    screen_spec_path = SELECTION / "screen-spec.json"
    screen = read_json(SELECTION / "screen/screen.json")
    base = read_json(base_path)
    screen_spec = read_json(screen_spec_path)
    retarget_spec = read_json(SELECTION / "retarget-spec.json")
    rows = read_json(SELECTION / "materialized/manifest.json")
    manifest = {row["case"]: row for row in rows}
    if len(rows) != len(CASES) or set(manifest) != set(CASES):
        raise ValueError("retarget manifest must contain exactly five distinct cases")
    if set(base["selected_programs"]) != set(CASES) or set(screen["source_program_sha256"]) != set(CASES):
        raise ValueError("screen inputs must contain exactly five cases")
    if (len(screen_spec["hardware_options"]) != 1 or len(retarget_spec["hardware_choices"]) != 1 or
            screen_spec["hardware_options"][0]["hardware"] != hardware or
            retarget_spec["hardware_choices"][0]["hardware"] != hardware):
        raise ValueError("shared hardware differs across screen, retarget and final header")
    option = screen_spec["hardware_options"][0]["name"]
    if (retarget_spec["hardware_choices"][0]["name"] != option or
            any(row["hardware"] != option for row in rows)):
        raise ValueError("hardware option identity differs")
    if (screen["spec_sha256"] != sha256(screen_spec_path) or
            screen["base_solution_sha256"] != sha256(base_path)):
        raise ValueError("screen specification or base solution changed")
    estimator = MATERIALS / "phase-two-model/model/estimate.py"
    if screen["estimator_sha256"] != sha256(estimator):
        raise ValueError("included estimator differs from screened version")
    target = max(5000, screen_spec["target_score"], retarget_spec["target_score"])
    if len(screen["results"]) != 1 or screen["results"][0]["name"] != option:
        raise ValueError("screen does not contain the selected hardware option")

    sources = {}
    for case in CASES:
        source = SELECTION / "source-programs" / f"{case}.jsonl"
        digest = sha256(source)
        if (digest != screen["source_program_sha256"][case] or
                digest != base["selected_programs"][case]["program_sha256"] or
                digest != manifest[case]["source_sha256"]):
            raise ValueError(f"source program SHA differs: {case}")
        sources[case] = source

    # No target program is written until all five independent model estimates pass.
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(MATERIALS / "phase-two-model"))
    from model.estimate import estimate_program
    from model.tool import SCORE_CASES

    if set(SCORE_CASES) != set(CASES):
        raise ValueError("included score contract differs from the five cases")
    cycles = {}
    for case in CASES:
        cycles[case] = estimate_program(sources[case], hardware_override=hardware)["cycles"]
        print(f"modeled {case}: {cycles[case]} cycles", file=sys.stderr, flush=True)
    score = 1000 * math.exp(sum(weight * math.log(reference / cycles[case])
                                for case, (reference, weight) in SCORE_CASES.items()))
    screened = screen["results"][0]
    if (not math.isfinite(score) or score < target or not screened["meets_grade_gate"] or
            cycles != screened["predicted_cycles"] or
            not math.isclose(score, screened["conditional_predicted_score"],
                             rel_tol=1e-12, abs_tol=1e-9)):
        raise ValueError("five-case model gate or original screen comparison failed")

    headers = {}
    expected = {}
    for case in CASES:
        with sources[case].open("rb") as reader:
            original = json.loads(reader.readline())
            header = dict(original, hardware=hardware)
            header_bytes = json.dumps(header, separators=(",", ":")).encode() + b"\n"
            digest = hashlib.sha256(header_bytes)
            while chunk := reader.read(1024 * 1024):
                digest.update(chunk)
        expected[case] = manifest[case]["program_sha256"]
        if digest.hexdigest() != expected[case]:
            raise ValueError(f"retargeted program differs from original manifest: {case}")
        headers[case] = header_bytes

    if args.zip_programs is not None:
        check_archived_programs(args.zip_programs, expected)

    # The output directory is created only after the full model and SHA checks.
    output.mkdir(parents=True, exist_ok=False)
    for case in CASES:
        with sources[case].open("rb") as reader, (output / f"{case}.jsonl").open("xb") as writer:
            reader.readline()
            writer.write(headers[case])
            shutil.copyfileobj(reader, writer)
        if sha256(output / f"{case}.jsonl") != expected[case]:
            raise ValueError(f"written program SHA differs: {case}")
    print(json.dumps({"model_score": score, "model_cycles": cycles,
                      "program_sha256": expected, "output_dir": str(output),
                      "zip_programs_verified": args.zip_programs is not None}, indent=2))


if __name__ == "__main__":
    main()
